public class PrintHelloWorld
    {
    public static void main(String[] args)
        { System.out.println("Hello world, as they say!".length()); }
    }