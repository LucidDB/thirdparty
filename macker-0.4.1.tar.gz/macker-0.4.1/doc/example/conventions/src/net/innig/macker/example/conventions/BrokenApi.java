package net.innig.macker.example.conventions;

public interface BrokenApi
    {
    public void foo(AlphaTree tree);
    }