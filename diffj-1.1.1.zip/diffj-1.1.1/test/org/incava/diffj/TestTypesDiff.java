package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestTypesDiff extends TestItemDiff
{
    protected final static String[] TYPES_MSGS = new String[] {
        TypesDiff.TYPE_DECLARATION_REMOVED,
        null,
        TypesDiff.TYPE_DECLARATION_ADDED,
    };
    
    public TestTypesDiff(String name)
    {
        super(name);
    }

    public void testAllTypesAdded()
    {
        evaluate("\n",
                 "class Test {\n" +
                 "}\n" +
                 "interface Test2 {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "Test",  TYPES_MSGS, new Point(1, 1), new Point(1, 1), new Point(1, 1), new Point(2, 1)),
                     makeRef(null, "Test2", TYPES_MSGS, new Point(1, 1), new Point(1, 1), new Point(3, 1), new Point(4, 1)),
                 });

        evaluate("import foo.Bar;\n",
                 "import foo.Bar;\n" +
                 "class Test {\n" +
                 "}\n" +
                 "interface Test2 {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "Test",  TYPES_MSGS,  new Point(1, 1), new Point(1, 6), new Point(2, 1), new Point(3, 1)),
                     makeRef(null, "Test2", TYPES_MSGS,  new Point(1, 1), new Point(1, 6), new Point(4, 1), new Point(5, 1)),
                 });

        evaluate("package foo;\n" +
                 "\n",
                 "package foo;\n" +
                 "class Test {\n" +
                 "}\n" +
                 "interface Test2 {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "Test",  TYPES_MSGS, new Point(1, 1), new Point(1, 7), new Point(2, 1), new Point(3, 1)),
                     makeRef(null, "Test2", TYPES_MSGS, new Point(1, 1), new Point(1, 7), new Point(4, 1), new Point(5, 1)),
                 });
    }

    public void testAllTypesRemoved()
    {
        evaluate("class Test {\n" +
                 "}\n" +
                 "interface Test2 {\n" +
                 "}\n",
                 "\n",
                 new CodeReference[] { 
                     makeRef("Test",  null, TYPES_MSGS, new Point(1, 1), new Point(2, 1), new Point(1, 1), new Point(1, 1)),
                     makeRef("Test2", null, TYPES_MSGS, new Point(3, 1), new Point(4, 1), new Point(1, 1), new Point(1, 1)),
                 });
    }

    protected String typeDeclMsg(String from, String to)
    {
        return getMessage(TypesDiff.TYPE_DECLARATION_REMOVED,
                          TypesDiff.TYPE_DECLARATION_ADDED,
                          null, // no changed message
                          from, to);
    }

}
