package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestInnerClassDiff extends TestItemDiff
{
    protected final static String[] METHOD_MSGS = new String[] {
        TypeDiff.METHOD_REMOVED,
        TypeDiff.METHOD_CHANGED, 
        TypeDiff.METHOD_ADDED,
    };

    protected final static String[] CLASS_MSGS = new String[] {
        TypeDiff.INNER_CLASS_REMOVED,
        null,
        TypeDiff.INNER_CLASS_ADDED,
    };
    
    public TestInnerClassDiff(String name)
    {
        super(name);
    }

    public void testMethodAdded()
    {
        evaluate("class Test {\n" +
                 "    class ITest {\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    class ITest {\n" +
                 "        void foo() {}\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(2, 5), new Point(3, 5), new Point(4, 9), new Point(4, 21)),
                 });
    }

    public void testMethodRemoved()
    {
        evaluate("class Test {\n" +
                 "    class ITest {\n" +
                 "        void foo() {}\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    class ITest {\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("foo()", null, METHOD_MSGS, new Point(3, 9), new Point(3, 21), new Point(3, 5), new Point(4, 5)),
                 });
    }

    public void testInnerClassAdded()
    {
        evaluate("class Test {\n" +
                 "    class ITest {\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    class ITest {\n" +
                 "        class I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "I2Test", CLASS_MSGS, new Point(2, 5), new Point(3, 5), new Point(4, 9), new Point(5, 9)),
                 });
    }

    public void testInnerClassRemoved()
    {
        evaluate("class Test {\n" +
                 "    class ITest {\n" +
                 "        class I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    class ITest {\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("I2Test", null, CLASS_MSGS, new Point(3, 9), new Point(4, 9), new Point(2, 5), new Point(3, 5)),
                 });
    }

    public void testInnerClassMethodAdded()
    {
        // all hail recursion!
        evaluate("class Test {\n" +
                 "    class ITest {\n" +
                 "        class I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    class ITest {\n" +
                 "        class I2Test {\n" +
                 "            void foo() {}\n" +
                 "        }\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(3, 9), new Point(4, 9), new Point(5, 13), new Point(5, 25)),
                 });
    }

    public void testInnerClassMethodRemoved()
    {
        evaluate("class Test {\n" +
                 "    class ITest {\n" +
                 "        class I2Test {\n" +
                 "            void foo(  String s) {}\n" +
                 "        }\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    class ITest {\n" +
                 "        class I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("foo(String)", null, METHOD_MSGS, new Point(4, 13), new Point(4, 35), new Point(4, 9), new Point(5, 9)),
                 });
    }

}
