package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestCtorDiff extends TestItemDiff
{
    protected final static String[] PARAMETER_MSGS = new String[] {
        CtorDiff.PARAMETER_REMOVED,
        null,
        CtorDiff.PARAMETER_ADDED,
    };

    protected final static String[] THROWS_MSGS = new String[] {
        CtorDiff.THROWS_REMOVED,
        null,
        CtorDiff.THROWS_ADDED,
    };

    public TestCtorDiff(String name)
    {
        super(name);
    }

    public void testAccessAdded()
    {
        evaluate("class Test {\n" +
                 "    Test() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    public Test() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeAccessRef(null, "public", 2, 5, 2, 8, 3, 5, 3, 10),
                 });
    }

    public void testAccessRemoved()
    {
        evaluate("class Test {\n" +
                 "    public Test() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeAccessRef("public", null, 2, 5, 2, 10, 3, 5, 3, 8),
                 });
    }

    public void testAccessChanged()
    {
        evaluate("class Test {\n" +
                 "    private Test() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    public Test() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeAccessRef("private", "public", 2, 5, 2, 11, 3, 5, 3, 10),
                 });
    }

    public void testParameterAddedNoneToOne()
    {
        evaluate("class Test {\n" +
                 "    Test() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "i", PARAMETER_MSGS, new Point(2, 9), new Point(2, 10), new Point(3, 18), new Point(3, 18)),
                 });
    }

    public void testParameterAddedOneToTwo()
    {
        evaluate("class Test {\n" +
                 "    Test(String s) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(String s, Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "i", PARAMETER_MSGS, new Point(2, 9), new Point(2, 18), new Point(3, 20), new Point(3, 28)),
                 });
    }

    public void testParameterAddedOneToThree()
    {
        evaluate("class Test {\n" +
                 "    Test(String s) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(List[] ary, String s, Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "ary", PARAMETER_MSGS,   new Point(2,  9), new Point(2, 18), new Point(3, 10), new Point(3, 19)),
                     makeRef(CodeReference.CHANGED, null, "i", PARAMETER_MSGS,     new Point(2,  9), new Point(2, 18), new Point(3, 32), new Point(3, 40)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("s", 0, 1), new Point(2, 17), new Point(2, 17), new Point(3, 29), new Point(3, 29)),
                 });
    }

    public void testParameterRemovedOneToNone()
    {
        evaluate("class Test {\n" +
                 "    Test(Integer i[][][][]) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "i", null, PARAMETER_MSGS, new Point(2, 18), new Point(2, 18), new Point(3, 9), new Point(3, 10)),
                 });
    }

    public void testParameterRemovedTwoToOne()
    {
        evaluate("class Test {\n" +
                 "    Test(String s, Integer i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    Test(String s) {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "i", null, PARAMETER_MSGS, new Point(2, 20), new Point(2, 28), new Point(2, 9), new Point(2, 18)),
                 });
    }

    public void testParameterRemovedThreeToOne()
    {
        evaluate("class Test {\n" +
                 "    Test(List[] ary, String s, Integer i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    Test(String s) {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "ary", null, PARAMETER_MSGS,   new Point(2, 10), new Point(2, 19), new Point(2,  9), new Point(2, 18)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("s", 1, 0), new Point(2, 29), new Point(2, 29), new Point(2, 17), new Point(2, 17)),
                     makeRef(CodeReference.CHANGED, "i", null, PARAMETER_MSGS,     new Point(2, 32), new Point(2, 40), new Point(2,  9), new Point(2, 18)),
                 });
    }

    public void testParameterChangedType()
    {
        evaluate("class Test {\n" +
                 "    Test(int i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, 
                                       getMessage(null, null, CtorDiff.PARAMETER_TYPE_CHANGED, "int", "Integer"), 
                                       new Point(2, 10), new Point(2, 14), new Point(3, 10), new Point(3, 18)),
                 });
    }

    public void testParameterChangedName()
    {
        evaluate("class Test {\n" +
                 "    Test(int i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(int x) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, 
                                       getMessage(null, null, CtorDiff.PARAMETER_NAME_CHANGED, "i", "x"),
                                       new Point(2, 14), new Point(2, 14), new Point(3, 14), new Point(3, 14)),
                 });
    }

    public void testParameterReordered()
    {
        evaluate("class Test {\n" +
                 "    Test(int i, double d) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(double d, int i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("i", 0, 1), new Point(2, 14), new Point(2, 14), new Point(3, 24), new Point(3, 24)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("d", 1, 0), new Point(2, 24), new Point(2, 24), new Point(3, 17), new Point(3, 17)),
                 });
    }

    public void testParameterReorderedAndRenamed()
    {
        evaluate("class Test {\n" +
                 "    Test(int i, double d) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(double dbl, int i2) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, paramReordRenamedMsg("i", 0, "i2",  1), new Point(2, 14), new Point(2, 14), new Point(3, 26), new Point(3, 27)),
                     new CodeReference(CodeReference.CHANGED, paramReordRenamedMsg("d", 1, "dbl", 0), new Point(2, 24), new Point(2, 24), new Point(3, 17), new Point(3, 19)),
                 });
    }

    public void testParameterOneAddedOneReordered()
    {
        evaluate("class Test {\n" +
                 "    Test(int i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(int i2, int i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "i2", PARAMETER_MSGS, new Point(2,  9), new Point(2, 15), new Point(3, 10), new Point(3, 15)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("i", 0, 1), new Point(2, 14), new Point(2, 14), new Point(3, 22), new Point(3, 22)),
                 });
    }

    public void testThrowsAddedNoneToOne()
    {
        evaluate("class Test {\n" +
                 "    Test() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() throws Exception {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "Exception", THROWS_MSGS, new Point(2, 5), new Point(2, 13), new Point(3, 19), new Point(3, 27)),
                 });
    }

    public void testThrowsAddedOneToTwo()
    {
        evaluate("class Test {\n" +
                 "    Test() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() throws IOException, NullPointerException {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "NullPointerException", THROWS_MSGS, new Point(2, 19), new Point(2, 29), new Point(3, 32), new Point(3, 51)),
                 });
    }

    public void testThrowsAddedOneToThree()
    {
        evaluate("class Test {\n" +
                 "    Test() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() throws ArrayIndexOutOfBoundsException, IOException, NullPointerException {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "ArrayIndexOutOfBoundsException", THROWS_MSGS, new Point(2, 19), new Point(2, 29), new Point(3, 19), new Point(3, 48)),
                     new CodeReference(CodeReference.CHANGED, throwsReordMsg("IOException", 0, 1), new Point(2, 19), new Point(2, 29), new Point(3, 51), new Point(3, 61)),
                     makeRef(CodeReference.CHANGED, null, "NullPointerException", THROWS_MSGS, new Point(2, 19), new Point(2, 29), new Point(3, 64), new Point(3, 83)),
                 });
    }

    public void testThrowsRemovedOneToNone()
    {
        evaluate("class Test {\n" +
                 "    Test() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "IOException", null, THROWS_MSGS, new Point(2, 19), new Point(2, 29), new Point(3, 5), new Point(3, 13)),
                 });
    }

    public void testThrowsRemovedTwoToOne()
    {
        evaluate("class Test {\n" +
                 "    Test() throws IOException, NullPointerException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    Test() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "NullPointerException", null, THROWS_MSGS, new Point(2, 32), new Point(2, 51), new Point(2, 19), new Point(2, 29)),
                 });
    }

    public void testThrowsRemovedThreeToOne()
    {
        evaluate("class Test {\n" +
                 "    Test() throws ArrayIndexOutOfBoundsException, IOException, NullPointerException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    Test() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "ArrayIndexOutOfBoundsException", null, THROWS_MSGS, new Point(2, 19), new Point(2, 48), new Point(2, 19), new Point(2, 29)),
                     new CodeReference(CodeReference.CHANGED, throwsReordMsg("IOException", 1, 0),  new Point(2, 51), new Point(2, 61), new Point(2, 19), new Point(2, 29)),
                     makeRef(CodeReference.CHANGED, "NullPointerException", null, THROWS_MSGS,           new Point(2, 64), new Point(2, 83), new Point(2, 19), new Point(2, 29)),
                 });
    }

    public void testThrowsReordered()
    {
        evaluate("class Test {\n" +
                 "    Test() throws ArrayIndexOutOfBoundsException, IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    Test() throws IOException, ArrayIndexOutOfBoundsException {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, throwsReordMsg("ArrayIndexOutOfBoundsException", 0, 1), new Point(2, 19), new Point(2, 48), new Point(2, 32), new Point(2, 61)),
                     new CodeReference(CodeReference.CHANGED, throwsReordMsg("IOException",                    1, 0), new Point(2, 51), new Point(2, 61), new Point(2, 19), new Point(2, 29)),
                 });
    }

    public void testCodeNotChanged()
    {
        evaluate("class Test {\n" +
                 "    Test() { i = -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() { \n" +
                 "        i = -1;\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testCodeChanged()
    {
        evaluate("class Test {\n" +
                 "    Test() { int i = -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() { \n" +
                 "        int i = -2;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(CtorDiff.CODE_CHANGED, "Test()", new Point(2, 23), new Point(2, 23), new Point(4, 18), new Point(4, 18)),
                 });
    }
    
    public void testCodeInserted()
    {
        evaluate("class Test {\n" +
                 "    Test() { int i = -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() { \n" +
                 "        int j = 0;\n" +
                 "        int i = -1;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(CtorDiff.CODE_ADDED, "Test()", new Point(2, 18), new Point(2, 18), new Point(4, 13), new Point(5, 11)),
                 });
    }

    public void testCodeDeleted()
    {
        evaluate("class Test {\n" +
                 "    Test() { \n" +
                 "        int j = 0;\n" +
                 "        int i = -1;\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test() { int i = -1; }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(CtorDiff.CODE_REMOVED, "Test()", new Point(3, 13), new Point(4, 11), new Point(3, 18), new Point(3, 18)),
                 });
    }

    public void testCodeInsertedAndChanged()
    {
        evaluate("class Test {\n" +
                 "    Test(int i) { i = 1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(int i) { \n" +
                 "        int j = 0;\n" +
                 "        i = 2;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(CtorDiff.CODE_CHANGED, "Test(int)", new Point(2, 19), new Point(2, 23), new Point(4,  9), new Point(5, 13)),
                 });
    }

    protected String paramReordMsg(String paramName, int oldPosition, int newPosition)
    {
        return MessageFormat.format(CtorDiff.PARAMETER_REORDERED, new Object[] { paramName, new Integer(oldPosition), new Integer(newPosition) });
    }

    protected String paramReordRenamedMsg(String oldName, int oldPosition, String newName, int newPosition)
    {
        return MessageFormat.format(CtorDiff.PARAMETER_REORDERED_AND_RENAMED, new Object[] { oldName, new Integer(oldPosition), new Integer(newPosition), newName });
    }

    protected String throwsReordMsg(String throwsName, int oldPosition, int newPosition)
    {
        return MessageFormat.format(CtorDiff.THROWS_REORDERED, new Object[] { throwsName, new Integer(oldPosition), new Integer(newPosition) });
    }

}
