package org.incava.diffj;

import java.awt.Point;
import java.io.StringWriter;
import java.text.MessageFormat;
import org.incava.analysis.*;
import org.incava.analysis.CodeReference;


public class TestOutput extends TestItemDiff
{
    private StringWriter output_ = null;
    
    public TestOutput(String name)
    {
        super(name);
    }

    public void testImportAdded()
    {
        evaluate("package org.incava.util;\n" +
                 "\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "}\n" +
                 "\n" +
                 "\n",

                 "package org.incava.util;\n" +
                 "\n" +
                 "import org.incava.log.Log;\n" +
                 "\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "}\n",
                 null);
    }

    public void testImportRemoved()
    {
        evaluate("package org.incava.util;\n" +
                 "\n" +
                 "import org.incava.qualog.Qualog;\n" +
                 "\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "}\n" +
                 "\n" +
                 "\n",

                 "package org.incava.util;\n" +
                 "\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "}\n",
                 null);
    }

    public void testImportAddedAndRemoved()
    {
        evaluate("package org.incava.util;\n" +
                 "\n" +
                 "import org.incava.qualog.Qualog;\n" +
                 "\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "}\n" +
                 "\n" +
                 "\n",

                 "package org.incava.util;\n" +
                 "\n" +
                 "import org.incava.log.Log;\n" +
                 "\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "}\n",
                 null);
    }

    public void testCodeChanged()
    {
        evaluate("package org.incava.util;\n" +
                 "\n" +
                 "/**\n" +
                 " * Times an event, from when the object is created, until when the\n" +
                 " * <code>end</code> method is invoked.\n" +
                 " */\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "    public void end()\n" +
                 "    {\n" +
                 // 234567890123456789012345678901234567890123456789
                 "        duration = System.currentTimeMillis() - startTime;\n" +
                 "        set.add(duration);\n" +
                 "    }\n" +
                 "}\n" +
                 "\n" +
                 "\n",

                 "package org.incava.util;\n" +
                 "\n" +
                 "/**\n" +
                 " * Times an event, from when the object is created, until when the\n" +
                 " * <code>end</code> method is invoked.\n" +
                 " */\n" +
                 "public class TimedEvent\n" +
                 "{\n" +
                 "    public void end()\n" +
                 "    {\n" +
                 "        Log.log(\"ending\");\n" +
                 //         1         2         3         4         5         6         
                 //23456789012345678901234567890123456789012345678901234567890123456789
                 "        duration = System.currentTimeMillis() - startTime;\n" +
                 "        set.add(duration);\n" +
                 "        Log.log(\"ended\");\n" +
                 "    }\n" +
                 "}\n",
                 null);
    }

    public Report makeReport(StringWriter output)
    {
        output_ = output;
        return new DetailedReport(output_);
        // return new BriefReport(output);
    }    

}
