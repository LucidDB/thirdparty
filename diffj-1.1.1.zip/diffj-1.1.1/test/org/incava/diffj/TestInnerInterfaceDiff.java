package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestInnerInterfaceDiff extends TestItemDiff
{
    protected final static String[] METHOD_MSGS = new String[] {
        TypeDiff.METHOD_REMOVED,
        TypeDiff.METHOD_CHANGED, 
        TypeDiff.METHOD_ADDED,
    };

    protected final static String[] INTERFACE_MSGS = new String[] {
        TypeDiff.INNER_INTERFACE_REMOVED,
        null,
        TypeDiff.INNER_INTERFACE_ADDED,
    };
    
    public TestInnerInterfaceDiff(String name)
    {
        super(name);
    }

    public void testMethodAdded()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {\n" +
                 "        void foo();\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(2, 5), new Point(3, 5), new Point(4, 9), new Point(4, 19)),
                 });
    }

    public void testMethodRemoved()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {\n" +
                 "        void foo();\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("foo()", null, METHOD_MSGS, new Point(3, 9), new Point(3, 19), new Point(3, 5), new Point(4, 5)),
                 });
    }

    public void testInnerInterfaceAdded()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {\n" +
                 "        interface I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "I2Test", INTERFACE_MSGS, new Point(2, 5), new Point(3, 5), new Point(4, 9), new Point(5, 9)),
                 });
    }

    public void testInnerInterfaceRemoved()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {\n" +
                 "        interface I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    interface ITest {\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("I2Test", null, INTERFACE_MSGS, new Point(3, 9), new Point(4, 9), new Point(2, 5), new Point(3, 5)),
                 });
    }

    public void testInnerInterfaceMethodAdded()
    {
        // all hail recursion!
        evaluate("class Test {\n" +
                 "    interface ITest {\n" +
                 "        interface I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {\n" +
                 "        interface I2Test {\n" +
                 "            void foo();\n" +
                 "        }\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(3, 9), new Point(4, 9), new Point(5, 13), new Point(5, 23)),
                 });
    }

    public void testInnerInterfaceMethodRemoved()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {\n" +
                 "        interface I2Test {\n" +
                 "            void foo();\n" +
                 "        }\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {\n" +
                 "        interface I2Test {\n" +
                 "        }\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("foo()", null, METHOD_MSGS, new Point(4, 13), new Point(4, 23), new Point(4, 9), new Point(5, 9)),
                 });
    }

}
