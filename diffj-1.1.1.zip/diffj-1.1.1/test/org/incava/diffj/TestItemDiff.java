package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.*;


public class TestItemDiff extends Tester
{
    protected final static String[] MODIFIER_MSGS = new String[] {
        ItemDiff.MODIFIER_REMOVED,
        ItemDiff.MODIFIER_CHANGED,
        ItemDiff.MODIFIER_ADDED,
    };

    protected final static String[] ACCESS_MSGS = new String[] {
        ItemDiff.ACCESS_REMOVED,
        ItemDiff.ACCESS_CHANGED, 
        ItemDiff.ACCESS_ADDED,
    };

    public TestItemDiff(String name)
    {
        super(name);
    }

    /**
     * Just to keep JUnit from complaining and bailing.
     */
    public void test()
    {
    }

    protected CodeReference makeRef(String from, String to, String[] msgs, Point a0, Point a1, Point b0, Point b1)
    {
        String msg  = null;
        String type = null;
        if (to == null) {
            msg  = MessageFormat.format(msgs[0], new Object[] { from });
            type = CodeReference.DELETED;
        }
        else if (from == null) {
            msg  = MessageFormat.format(msgs[2], new Object[] { to });
            type = CodeReference.ADDED;
        }
        else {
            msg  = MessageFormat.format(msgs[1], new Object[] { from, to });
            type = CodeReference.CHANGED;
        }
        return new CodeReference(type, msg, a0, a1, b0, b1);
    }

    protected String getMessage(String removedMsg, String addedMsg, String changedMsg, String from, String to)
    {
        String msg = null;
        if (to == null) {
            msg = MessageFormat.format(removedMsg, new Object[] { from });
        }
        else if (from == null) {
            msg = MessageFormat.format(addedMsg, new Object[] { to });
        }
        else {
            msg = MessageFormat.format(changedMsg, new Object[] { from, to });
        }
        return msg;
    }

    protected CodeReference makeRef(String type, String from, String to, String[] msgs, Point a0, Point a1, Point b0, Point b1)
    {
        String msg = null;
        if (to == null) {
            msg = MessageFormat.format(msgs[0], new Object[] { from });
        }
        else if (from == null) {
            msg = MessageFormat.format(msgs[2], new Object[] { to });
        }
        else {
            msg = MessageFormat.format(msgs[1], new Object[] { from, to });
        }
        return new CodeReference(type, msg, a0, a1, b0, b1);
    }

    protected CodeReference makeRef(String from, String to,
                                    String[] msgs,
                                    int aFromLine, int aFromColumn, int aToLine, int aToColumn,
                                    int bFromLine, int bFromColumn, int bToLine, int bToColumn)
    {
        return makeRef(from, to, msgs, 
                       new Point(aFromLine, aFromColumn), new Point(aToLine, aToColumn),
                       new Point(bFromLine, bFromColumn), new Point(bToLine, bToColumn));
    }

    protected CodeReference makeRef(String type,
                                    String from, String to,
                                    String[] msgs,
                                    int aFromLine, int aFromColumn, int aToLine, int aToColumn,
                                    int bFromLine, int bFromColumn, int bToLine, int bToColumn)
    {
        return makeRef(type, from, to, msgs, 
                       new Point(aFromLine, aFromColumn), new Point(aToLine, aToColumn),
                       new Point(bFromLine, bFromColumn), new Point(bToLine, bToColumn));
    }

    protected CodeReference makeAccessRef(String from, String to,
                                          int aFromLine, int aFromColumn, int aToLine, int aToColumn,
                                          int bFromLine, int bFromColumn, int bToLine, int bToColumn)
    {
        return makeRef(CodeReference.CHANGED,
                       from, to, ACCESS_MSGS, 
                       aFromLine, aFromColumn, aToLine, aToColumn,
                       bFromLine, bFromColumn, bToLine, bToColumn);
    }

    protected CodeReference makeModifierRef(String from, String to,
                                            int aFromLine, int aFromColumn, int aToLine, int aToColumn,
                                            int bFromLine, int bFromColumn, int bToLine, int bToColumn)
    {
        return makeRef(CodeReference.CHANGED,
                       from, to, MODIFIER_MSGS, 
                       aFromLine, aFromColumn, aToLine, aToColumn,
                       bFromLine, bFromColumn, bToLine, bToColumn);
    }

    protected CodeReference makeCodeChangedRef(String codeChgMsg, String where, Point a0, Point a1, Point b0, Point b1)
    {
        String str = MessageFormat.format(codeChgMsg, new Object[] { where });
        return new CodeReference(CodeReference.CHANGED, str, a0, a1, b0, b1);
    }

}
