package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestTypeDiff extends TestItemDiff
{
    protected final static String[] METHOD_MSGS = new String[] {
        TypeDiff.METHOD_REMOVED,
        TypeDiff.METHOD_CHANGED, 
        TypeDiff.METHOD_ADDED,
    };

    protected final static String[] FIELD_MSGS = new String[] {
        TypeDiff.FIELD_REMOVED,
        null,
        TypeDiff.FIELD_ADDED,
    };

    protected final static String[] CLASS_MSGS = new String[] {
        TypeDiff.INNER_CLASS_REMOVED,
        null,
        TypeDiff.INNER_CLASS_ADDED,
    };

    protected final static String[] INTERFACE_MSGS = new String[] {
        TypeDiff.INNER_INTERFACE_REMOVED,
        null,
        TypeDiff.INNER_INTERFACE_ADDED,
    };

    protected final static String[] CONSTRUCTOR_MSGS = new String[] {
        TypeDiff.CONSTRUCTOR_REMOVED,
        null,
        TypeDiff.CONSTRUCTOR_ADDED,
    };

//     protected final static String[] CONSTRUCTOR_MSGS = new String[] {
//         TypeDiff.CONSTRUCTOR_REMOVED,
//         null,
//         TypeDiff.CONSTRUCTOR_ADDED,
//     };

    public TestTypeDiff(String name)
    {
        super(name);
    }

    public void testClassToInterface()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "interface Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, TypesDiff.TYPE_CHANGED_FROM_CLASS_TO_INTERFACE, new Point(1, 1), new Point(2, 1), new Point(1, 1), new Point(2, 1)),
                 });
    }

    public void testInterfaceToClass()
    {
        evaluate("interface Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, TypesDiff.TYPE_CHANGED_FROM_INTERFACE_TO_CLASS, new Point(1, 1), new Point(2, 1), new Point(1, 1), new Point(2, 1)),
                 });
    }

    public void testClassAccessChanged()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "public", ACCESS_MSGS, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 6)),
                 });
        
        evaluate("public class Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "public", null, ACCESS_MSGS, new Point(1, 1), new Point(1, 6), new Point(1, 1), new Point(1, 5)),
                 });
    }

    public void testClassModifierAdded()
    {
        evaluate("public class Test {\n" +
                 "}\n",
                 "abstract public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "abstract", MODIFIER_MSGS, new Point(1, 1), new Point(1, 6), new Point(1, 1), new Point(1, 8)),
                 });

        evaluate("public class Test {\n" +
                 "}\n",
                 "final public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "final", MODIFIER_MSGS, new Point(1, 1), new Point(1, 6), new Point(1, 1), new Point(1, 5)),
                 });

        evaluate("class Test {\n" +
                 "}\n",
                 "strictfp class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "strictfp", MODIFIER_MSGS, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 8)),
                 });
    }

    public void testClassModifierRemoved()
    {
        evaluate("abstract public class Test {\n" +
                 "}\n",
                 "public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "abstract", null, MODIFIER_MSGS, new Point(1, 1), new Point(1, 8), new Point(1, 1), new Point(1, 6)),
                 });

        evaluate("final public class Test {\n" +
                 "}\n",
                 "public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "final", null, MODIFIER_MSGS, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 6)),
                 });

        evaluate("strictfp class Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "strictfp", null, MODIFIER_MSGS, new Point(1, 1), new Point(1, 8), new Point(1, 1), new Point(1, 5)),
                 });
    }

    public void testClassAllMethodsAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 17)),
                 });
    }

    public void testClassOneMethodAdded()
    {
        evaluate("class Test {\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { return -1; }\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(1, 1), new Point(4, 1), new Point(4, 5), new Point(4, 17)),
                 });
    }

    public void testClassAllMethodsRemoved()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("foo()", null, METHOD_MSGS, new Point(3, 5), new Point(3, 17), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void testClassNoMethodsChanged()
    {
        evaluate("class Test {\n" +
                 "    void foo() {}\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { \n" +
                 "        return -1;\n" +
                 "    }\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testClassOneFieldAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "i", FIELD_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 10)),
                 });
    }

    public void testClassOneFieldRemoved()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("i", null, FIELD_MSGS, new Point(2, 5), new Point(2, 10), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void testClassOneFieldRemovedOneFieldAdded()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    String j;\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "j",  FIELD_MSGS, new Point(1, 1), new Point(4,  1), new Point(2, 5), new Point(2, 13)),
                     makeRef("i",  null, FIELD_MSGS, new Point(2, 5), new Point(2, 10), new Point(1, 1), new Point(4,  1)),
                 });
    }

    public void testClassInnerInterfaceUnchanged()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {}\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testClassInnerInterfaceAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "ITest", INTERFACE_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 22)),
                 });
    }

    public void testClassInnerInterfaceRemoved()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "    interface ITest {}\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("ITest", null, INTERFACE_MSGS, new Point(3, 5), new Point(3, 22), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void testClassConstructorAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(String s) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "Test(String)", CONSTRUCTOR_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 21)),
                 });
    }

    public void testClassConstructorRemoved()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "    public Test(int i, double d, float f) {}\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("Test(int, double, float)", null, CONSTRUCTOR_MSGS, new Point(3, 12), new Point(3, 44), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void testSemicolonDeclarationRemoved()
    {
        // Is this really a change? I don't think so.
        evaluate("class Test {\n" +
                 "    ;\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

}
