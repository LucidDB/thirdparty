package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestMethodDiff extends TestItemDiff
{
    protected final static String[] THROWS_MSGS = new String[] {
        MethodDiff.THROWS_REMOVED,
        null,
        MethodDiff.THROWS_ADDED,
    };

    protected final static String[] PARAM_MSGS = new String[] {
        MethodDiff.PARAMETER_REMOVED,
        null,
        MethodDiff.PARAMETER_ADDED,
    };

    public TestMethodDiff(String name)
    {
        super(name);
    }

    public void testAccessAdded()
    {
        evaluate("class Test {\n" +
                 "    void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    public void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "public", ACCESS_MSGS, new Point(2, 5), new Point(2, 8), new Point(3, 5), new Point(3, 10)),
                 });
    }

    public void testAccessRemoved()
    {
        evaluate("class Test {\n" +
                 "    public void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "public", null, ACCESS_MSGS, new Point(2, 5), new Point(2, 10), new Point(3, 5), new Point(3, 8)),
                 });
    }

    public void testAccessChanged()
    {
        evaluate("class Test {\n" +
                 "    private void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    public void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "private", "public", ACCESS_MSGS, new Point(2, 5), new Point(2, 11), new Point(3, 5), new Point(3, 10)),
                 });
    }

    public void testModifierAdded()
    {
        evaluate("class Test {\n" +
                 "    void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    static void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "static", MODIFIER_MSGS, new Point(2, 5), new Point(2, 8), new Point(3, 5), new Point(3, 10)),
                 });
    }

    public void testModifierRemoved()
    {
        evaluate("class Test {\n" +
                 "    final void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "final", null, MODIFIER_MSGS, new Point(2, 5), new Point(2, 9), new Point(3, 5), new Point(3, 8)),
                 });
    }

    public void testReturnTypeChanged()
    {
        evaluate("class Test {\n" +
                 "    Object foo() { return null; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Integer foo() { return null; }\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED,
                                       getMessage(null, null, MethodDiff.RETURN_TYPE_CHANGED, "Object", "Integer"),
                                       new Point(2, 5), new Point(2, 10), new Point(3, 5), new Point(3, 11)),
                 });
    }

    public void testParameterAddedNoneToOne()
    {
        evaluate("class Test {\n" +
                 "    void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "i", PARAM_MSGS, new Point(2, 13), new Point(2, 14), new Point(3, 22), new Point(3, 22)),
                 });
    }

    public void testParameterAddedOneToTwo()
    {
        evaluate("class Test {\n" +
                 "    void foo(String s) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(String s, Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "i", PARAM_MSGS, new Point(2, 13), new Point(2, 22), new Point(3, 24), new Point(3, 32)),
                 });
    }

    public void testParameterAddedOneToThree()
    {
        evaluate("class Test {\n" +
                 "    void foo(String s) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(List[] ary, String s, Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "ary", PARAM_MSGS, new Point(2, 13), new Point(2, 22), new Point(3, 14), new Point(3, 23)),
                     makeRef(CodeReference.CHANGED, null, "i",   PARAM_MSGS, new Point(2, 13), new Point(2, 22), new Point(3, 36), new Point(3, 44)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("s", 0, 1), new Point(2, 21), new Point(2, 21), new Point(3, 33), new Point(3, 33)),
                 });
    }

    public void testParameterRemovedOneToNone()
    {
        evaluate("class Test {\n" +
                 "    void foo(Integer i[][][][]) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "i", null, PARAM_MSGS, new Point(2, 22), new Point(2, 22), new Point(3, 13), new Point(3, 14)),
                 });
    }

    public void testParameterRemovedTwoToOne()
    {
        evaluate("class Test {\n" +
                 "    void foo(String s, Integer i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    void foo(String s) {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "i", null, PARAM_MSGS, new Point(2, 24), new Point(2, 32), new Point(2, 13), new Point(2, 22)),
                 });
    }

    public void testParameterRemovedThreeToOne()
    {
        evaluate("class Test {\n" +
                 "    void foo(List[] ary, String s, Integer i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    void foo(String s) {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "ary", null, PARAM_MSGS, new Point(2, 14), new Point(2, 23), new Point(2, 13), new Point(2, 22)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("s", 1, 0), new Point(2, 33), new Point(2, 33), new Point(2, 21), new Point(2, 21)),
                     makeRef(CodeReference.CHANGED, "i", null,   PARAM_MSGS, new Point(2, 36), new Point(2, 44), new Point(2, 13), new Point(2, 22)),
                 });
    }

    public void testParameterChangedType()
    {
        evaluate("class Test {\n" +
                 "    void foo(int i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(Integer i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED,
                                       getMessage(null, null, MethodDiff.PARAMETER_TYPE_CHANGED, "int", "Integer"), 
                                       new Point(2, 14), new Point(2, 18), new Point(3, 14), new Point(3, 22)),
                 });
    }

    public void testParameterChangedName()
    {
        evaluate("class Test {\n" +
                 "    void foo(int i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(int x) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED,
                                       getMessage(null, null, MethodDiff.PARAMETER_NAME_CHANGED, "i", "x"),
                                       new Point(2, 18), new Point(2, 18), new Point(3, 18), new Point(3, 18)),
                 });
    }

    public void testParameterReordered()
    {
        evaluate("class Test {\n" +
                 "    void foo(int i, double d) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(double d, int i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("i", 0, 1), new Point(2, 18), new Point(2, 18), new Point(3, 28), new Point(3, 28)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("d", 1, 0), new Point(2, 28), new Point(2, 28), new Point(3, 21), new Point(3, 21)),
                 });
    }

    public void testParameterReorderedAndRenamed()
    {
        evaluate("class Test {\n" +
                 "    void foo(int i, double d) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(double dbl, int i2) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, paramReordRenamedMsg("i", 0, "i2",  1), new Point(2, 18), new Point(2, 18), new Point(3, 30), new Point(3, 31)),
                     new CodeReference(CodeReference.CHANGED, paramReordRenamedMsg("d", 1, "dbl", 0), new Point(2, 28), new Point(2, 28), new Point(3, 21), new Point(3, 23)),
                 });
    }

    public void testParameterOneAddedOneReordered()
    {
        evaluate("class Test {\n" +
                 "    void foo(int i) {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo(int i2, int i) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "i2", PARAM_MSGS, new Point(2, 13), new Point(2, 19), new Point(3, 14), new Point(3, 19)),
                     new CodeReference(CodeReference.CHANGED, paramReordMsg("i", 0, 1), new Point(2, 18), new Point(2, 18), new Point(3, 26), new Point(3, 26)),
                 });
    }

    public void testThrowsAddedNoneToOne()
    {
        evaluate("class Test {\n" +
                 "    void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() throws Exception {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "Exception", THROWS_MSGS, new Point(2, 5), new Point(2, 17), new Point(3, 23), new Point(3, 31)),
                 });
    }

    public void testThrowsAddedOneToTwo()
    {
        evaluate("class Test {\n" +
                 "    void foo() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() throws IOException, NullPointerException {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "NullPointerException", THROWS_MSGS, new Point(2, 23), new Point(2, 33), new Point(3, 36), new Point(3, 55)),
                 });
    }

    public void testThrowsAddedOneToThree()
    {
        evaluate("class Test {\n" +
                 "    void foo() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() throws ArrayIndexOutOfBoundsException, IOException, NullPointerException {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "ArrayIndexOutOfBoundsException", THROWS_MSGS, new Point(2, 23), new Point(2, 33), new Point(3, 23), new Point(3, 52)),
                     new CodeReference(CodeReference.CHANGED, throwsReordMsg("IOException", 0, 1), new Point(2, 23), new Point(2, 33), new Point(3, 55), new Point(3, 65)),
                     makeRef(CodeReference.CHANGED, null, "NullPointerException", THROWS_MSGS, new Point(2, 23), new Point(2, 33), new Point(3, 68), new Point(3, 87)),
                 });
    }

    public void testThrowsRemovedOneToNone()
    {
        evaluate("class Test {\n" +
                 "    void foo() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "IOException", null, THROWS_MSGS, new Point(2, 23), new Point(2, 33), new Point(3, 5), new Point(3, 17)),
                 });
    }

    public void testThrowsRemovedTwoToOne()
    {
        evaluate("class Test {\n" +
                 "    void foo() throws IOException, NullPointerException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    void foo() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "NullPointerException", null, THROWS_MSGS, new Point(2, 36), new Point(2, 55), new Point(2, 23), new Point(2, 33)),
                 });
    }

    public void testThrowsRemovedThreeToOne()
    {
        evaluate("class Test {\n" +
                 "    void foo() throws ArrayIndexOutOfBoundsException, IOException, NullPointerException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    void foo() throws IOException {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "ArrayIndexOutOfBoundsException", null, THROWS_MSGS, new Point(2, 23), new Point(2, 52), new Point(2, 23), new Point(2, 33)),
                     new CodeReference(CodeReference.CHANGED, throwsReordMsg("IOException", 1, 0), new Point(2, 55), new Point(2, 65), new Point(2, 23), new Point(2, 33)),
                     makeRef(CodeReference.CHANGED, "NullPointerException", null, THROWS_MSGS, new Point(2, 68), new Point(2, 87), new Point(2, 23), new Point(2, 33)),
                 });
    }

    public void testThrowsReordered()
    {
        evaluate("class Test {\n" +
                 "    void foo() throws ArrayIndexOutOfBoundsException, IOException {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    void foo() throws IOException, ArrayIndexOutOfBoundsException {}\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, 
                                       throwsReordMsg("ArrayIndexOutOfBoundsException", 0, 1),
                                       new Point(2, 23), new Point(2, 52), new Point(2, 36), new Point(2, 65)),
                     new CodeReference(CodeReference.CHANGED,
                                       throwsReordMsg("IOException", 1, 0),
                                       new Point(2, 55), new Point(2, 65), new Point(2, 23), new Point(2, 33)),
                 });
    }

    public void testAbstractToImplementedMethod()
    {
        evaluate("abstract class Test {\n" +
                 "    abstract void foo();\n" +
                 "\n" +
                 "}\n",
                 "abstract class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "abstract", null, MODIFIER_MSGS, new Point(2, 5), new Point(2, 12), new Point(3, 5), new Point(3, 8)),
                     new CodeReference(CodeReference.CHANGED, MethodDiff.METHOD_BLOCK_ADDED, new Point(2, 14), new Point(2, 24), new Point(3, 5), new Point(3, 17)),
                 });
    }

    public void testImplementedToAbstractMethod()
    {
        evaluate("abstract class Test {\n" +
                 "    void foo() {}\n" +
                 "\n" +
                 "}\n",
                 "abstract class Test {\n" +
                 "\n" +
                 "    abstract void foo();\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "abstract", MODIFIER_MSGS, new Point(2, 5), new Point(2,  8), new Point(3, 5), new Point(3, 12)),
                     new CodeReference(CodeReference.CHANGED, MethodDiff.METHOD_BLOCK_REMOVED, new Point(2, 5), new Point(2, 17), new Point(3, 14), new Point(3, 24)),
                 });
    }

    public void testCodeNotChanged()
    {
        evaluate("class Test {\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { \n" +
                 "        return -1;\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testCodeChanged()
    {
        evaluate("class Test {\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { \n" +
                 "        return -2;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(MethodDiff.CODE_CHANGED, "bar()", new Point(2, 25), new Point(2, 25), new Point(4, 17), new Point(4, 17)),
                 });
    }
    
    public void testCodeInserted()
    {
        evaluate("class Test {\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { \n" +
                 "        int i = 0;\n" +
                 "        return -1;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(MethodDiff.CODE_ADDED, "bar()", new Point(2, 17), new Point(2, 22), new Point(4, 9), new Point(4, 18)),
                 });
    }

    public void testCodeDeleted()
    {
        evaluate("class Test {\n" +
                 "    int bar() { \n" +
                 "        int i = 0;\n" +
                 "        return -1;\n" +
                 "    }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { return -1; }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(MethodDiff.CODE_REMOVED, "bar()", new Point(3, 9), new Point(3, 18), new Point(3, 17), new Point(3, 22)),
                 });
    }

    public void testCodeInsertedAndChanged()
    {
        evaluate("class Test {\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { \n" +
                 "        int i = 0;\n" +
                 "        return -2;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(MethodDiff.CODE_CHANGED, "bar()", new Point(2, 17), new Point(2, 25), new Point(4, 9), new Point(5, 17)),
                 });
    }

    public void testMethodNativeToImplemented()
    {
        evaluate("class Test {\n" +
                 "    native void foo();\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() { \n" +
                 "        int i = 0;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "native", null, MODIFIER_MSGS, new Point(2, 5), new Point(2, 10), new Point(3, 5), new Point(3, 8)),
                     new CodeReference(CodeReference.CHANGED, MethodDiff.METHOD_BLOCK_ADDED, new Point(2, 12), new Point(2, 22), new Point(3, 5), new Point(5, 5)),
                 });
    }

    public void testMethoImplementedToNative()
    {
        evaluate("class Test {\n" +
                 "    void foo() { \n" +
                 "        int i = 0;\n" +
                 "    }\n" +
                 "}\n",
                 "class Test {\n" +
                 "    native void foo();\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "native", MODIFIER_MSGS, new Point(2, 5), new Point(2, 8), new Point(2, 5), new Point(2, 10)),
                     new CodeReference(CodeReference.CHANGED, MethodDiff.METHOD_BLOCK_REMOVED, new Point(2, 5), new Point(4, 5), new Point(2, 12), new Point(2, 22)),
                 });
    }

    // See comment in TestDiff.java, with regard to misleading LCSes.

    public void misleading_diffs_testZipDiff()
    {
        evaluate("/**\n" +
                 " * This class implements an output stream filter for writing files in the\n" +
                 " * ZIP file format. Includes support for both compressed and uncompressed\n" +
                 " * entries.\n" +
                 " *\n" +
                 " * @author	David Connelly\n" +
                 " * @version	1.27, 02/07/03\n" +
                 " */\n" +
                 "    public\n" +
                 "    class ZipOutputStream extends DeflaterOutputStream implements ZipConstants {\n" +
                 "\n" +
                 "        /**\n" +
                 "         * Closes the current ZIP entry and positions the stream for writing\n" +
                 "         * the next entry.\n" +
                 "         * @exception ZipException if a ZIP format error has occurred\n" +
                 "         * @exception IOException if an I/O error has occurred\n" +
                 "         */\n" +
                 "        public void closeEntry() throws IOException {\n" +
                 "            ZipEntry e = entry;\n" +
                 "            if (e != null) {\n" +
                 "                switch (e.method) {\n" +
                 "                    case DEFLATED:\n" +
                 "                        if ((e.flag & 8) == 0) {\n" +
                 "                            // verify size, compressed size, and crc-32 settings\n" +
                 "                            if (e.size != def.getTotalIn()) {\n" +
                 "                                throw new ZipException(\n" +
                 "                                    \"invalid entry size (expected \" + e.size +\n" +
                 "                                    \" but got \" + def.getTotalIn() + \" bytes)\");\n" +
                 "                            }\n" +
                 "                            if (e.csize != def.getTotalOut()) {\n" +
                 "                                throw new ZipException(\n" +
                 "                                    \"invalid entry compressed size (expected \" +\n" +
                 "                                    e.csize + \" but got \" + def.getTotalOut() +\n" +
                 "                                    \" bytes)\");\n" +
                 "                            }\n" +
                 "                            if (e.crc != crc.getValue()) {\n" +
                 "                                throw new ZipException(\n" +
                 "                                    \"invalid entry CRC-32 (expected 0x\" +\n" +
                 "                                    Long.toHexString(e.crc) + \" but got 0x\" +\n" +
                 "                                    Long.toHexString(crc.getValue()) + \")\");\n" +
                 "                            }\n" +
                 "                        } else {\n" +
                 "                            e.size = def.getTotalIn();\n" +
                 "                            e.csize = def.getTotalOut();\n" +
                 "                            e.crc = crc.getValue();\n" +
                 "                            writeEXT(e);\n" +
                 "                        }\n" +
                 "                        def.reset();\n" +
                 "                        written += e.csize;\n" +
                 "                        break;\n" +
                 "                }\n" +
                 "            }\n" +
                 "        }\n" +
                 "\n" +
                 "    }\n",
                 "    /**\n" +
                 "     * This class implements an output stream filter for writing files in the\n" +
                 "     * ZIP file format. Includes support for both compressed and uncompressed\n" +
                 "     * entries.\n" +
                 "     *\n" +
                 "     * @author	David Connelly\n" +
                 "     * @version	1.31, 12/19/03\n" +
                 "     */\n" +
                 "    public\n" +
                 "        class ZipOutputStream extends DeflaterOutputStream implements ZipConstants {\n" +
                 "\n" +
                 "            /**\n" +
                 "             * Closes the current ZIP entry and positions the stream for writing\n" +
                 "             * the next entry.\n" +
                 "             * @exception ZipException if a ZIP format error has occurred\n" +
                 "             * @exception IOException if an I/O error has occurred\n" +
                 "             */\n" +
                 "            public void closeEntry() throws IOException {\n" +
                 "                ZipEntry e = entry;\n" +
                 "                if (e != null) {\n" +
                 "                    switch (e.method) {\n" +
                 "                        case DEFLATED:\n" +
                 "                            if ((e.flag & 8) == 0) {\n" +
                 "                                // verify size, compressed size, and crc-32 settings\n" +
                 "                                if (e.size != def.getBytesRead()) {\n" +
                 "                                    throw new ZipException(\n" +
                 "                                        \"invalid entry size (expected \" + e.size +\n" +
                 "                                        \" but got \" + def.getBytesRead() + \" bytes)\");\n" +
                 "                                }\n" +
                 "                                if (e.csize != def.getBytesWritten()) {\n" +
                 "                                    throw new ZipException(\n" +
                 "                                        \"invalid entry compressed size (expected \" +\n" +
                 "                                        e.csize + \" but got \" + def.getBytesWritten() + \" bytes)\");\n" +
                 "                                }\n" +
                 "                                if (e.crc != crc.getValue()) {\n" +
                 "                                    throw new ZipException(\n" +
                 "                                        \"invalid entry CRC-32 (expected 0x\" +\n" +
                 "                                        Long.toHexString(e.crc) + \" but got 0x\" +\n" +
                 "                                        Long.toHexString(crc.getValue()) + \")\");\n" +
                 "                                }\n" +
                 "                            } else {\n" +
                 "                                e.size  = def.getBytesRead();\n" +
                 "                                e.csize = def.getBytesWritten();\n" +
                 "                                e.crc = crc.getValue();\n" +
                 "                                writeEXT(e);\n" +
                 "                            }\n" +
                 "                            def.reset();\n" +
                 "                            written += e.csize;\n" +
                 "                            break;\n" +
                 "                    }\n" +
                 "                }\n" +
                 "            }\n" +
                 "        }\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(MethodDiff.CODE_CHANGED, "bar()", new Point(2, 17), new Point(2, 25), new Point(4, 9), new Point(5, 17)),
                 });
    }

    protected String paramMsg(String from, String to)
    {
        return getMessage(MethodDiff.PARAMETER_REMOVED,
                          MethodDiff.PARAMETER_ADDED,
                          null, 
                          from, to);
    }

    protected String paramReordMsg(String paramName, int oldPosition, int newPosition)
    {
        return MessageFormat.format(MethodDiff.PARAMETER_REORDERED, new Object[] { paramName, new Integer(oldPosition), new Integer(newPosition) });
    }

    protected String paramReordRenamedMsg(String oldName, int oldPosition, String newName, int newPosition)
    {
        return MessageFormat.format(MethodDiff.PARAMETER_REORDERED_AND_RENAMED, new Object[] { oldName, new Integer(oldPosition), new Integer(newPosition), newName });
    }

    protected String throwsMsg(String from, String to)
    {
        return getMessage(MethodDiff.THROWS_REMOVED,
                          MethodDiff.THROWS_ADDED,
                          null, 
                          from, to);
    }

    protected String throwsReordMsg(String throwsName, int oldPosition, int newPosition)
    {
        return MessageFormat.format(MethodDiff.THROWS_REORDERED, new Object[] { throwsName, new Integer(oldPosition), new Integer(newPosition) });
    }

}
