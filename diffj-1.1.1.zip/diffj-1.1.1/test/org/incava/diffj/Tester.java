package org.incava.diffj;

import java.awt.Point;
import java.io.*;
import java.util.*;
import junit.framework.TestCase;
import net.sourceforge.pmd.ast.*;
import org.incava.analysis.*;
import org.incava.java.*;
import org.incava.qualog.Qualog;


public class Tester extends TestCase
{
    private Report _report;
    
    public Tester(String name)
    {
        super(name);
    }

    public void evaluate(String from, String to, CodeReference[] expectations)
    {
        evaluate(from, to, expectations, "1.3");
    }

    public void evaluate(String from, String to, CodeReference[] expectations, String src)
    {
        StringWriter reportOutput = new StringWriter();
        _report = makeReport(reportOutput);
        
        Collection diffs = _report.getDifferences();

        _report.reset(from, to);

        try {
            StringReader fromRdr = new StringReader(from);
            StringReader toRdr = new StringReader(to);

            JavaCharStream jcsFrom = new JavaCharStream(fromRdr);
            JavaCharStream jcsTo = new JavaCharStream(toRdr);

            JavaParser fromParser = new JavaParser(jcsFrom);
            JavaParser toParser = new JavaParser(jcsTo);

            if (src.equals("1.3")) {
                fromParser.setJDK13();
                toParser.setJDK13();
            }
            else if (src.equals("1.4")) {
                // nothing.
            }
            else if (src.equals("1.5")) {
                fromParser.setJDK15();
                toParser.setJDK15();
            }
            else {
                fail("ERROR: source version '" + src + "' not recognized");
            }

            ASTCompilationUnit fromCu = fromParser.CompilationUnit();
            ASTCompilationUnit toCu   = toParser.CompilationUnit();
            
            CompilationUnitDiff cud = new CompilationUnitDiff(_report, false);
            cud.compare(fromCu, toCu);
            
            if (expectations == null) {
                // skipping expectations check
            }
            else {
                assertEquals("number of differences", expectations.length, diffs.size());

                Iterator dit = diffs.iterator();
                for (int di = 0; dit.hasNext(); ++di) {
                    CodeReference ref = (CodeReference)dit.next();
                    CodeReference exp = expectations[di];

                    assertNotNull("reference not null", ref);

                    assertEquals("expectations[" + di + "].type",    exp.type,    ref.type);
                    assertEquals("expectations[" + di + "].message", exp.message, ref.message);

                    Point[][] pts = new Point[][] {
                        { exp.firstStart,  ref.firstStart  },
                        { exp.secondStart, ref.secondStart },
                        { exp.firstEnd,    ref.firstEnd    },
                        { exp.secondEnd,   ref.secondEnd   },
                    };
                    for (int pi = 0; pi < pts.length; ++pi) {
                        assertEquals("expectations[" + di + "][" + pi + "]", pts[pi][0], pts[pi][1]);
                    }
                }
            }

            _report.flush();
        }
        catch (ParseException e) {
            fail(e.getMessage());
        }
    }

    public Report makeReport(StringWriter output)
    {
        return new BriefReport(output);
    }

    public Report getReport()
    {
        return _report;
    }
    
}
