package org.incava.jagol;

import java.io.*;
import java.util.*;

public class ValueExpectedException extends OptionException
{
    public ValueExpectedException(String msg)
    {
        super(msg);
    }

}
