package org.incava.java;

import java.util.*;


/**
 * A criterion (some criteria) for matching nodes.
 */
public class MatchCriteria
{
    public double compare(MatchCriteria other)
    {
        return 0.0;
    }

}
