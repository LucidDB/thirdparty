package tr;

import org.incava.qualog.Qualog;


/**
 * Short method and field names.
 *
 * Allows name of tr.Ace.XXX("...").
 */
public class Ace extends Qualog
{
}
