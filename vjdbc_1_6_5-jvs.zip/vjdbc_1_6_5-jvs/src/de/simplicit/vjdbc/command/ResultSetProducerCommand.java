// VJDBC - Virtual JDBC
// Written by Michael Link
// Website: http://vjdbc.sourceforge.net

package de.simplicit.vjdbc.command;

public interface ResultSetProducerCommand {
    int getResultSetType();
}
