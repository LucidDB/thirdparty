/* $Id: Bug_1032563.java,v 1.2 2004/11/09 21:12:56 Arno Exp $ */

import java.io.StringReader;
import java.net.URL;
import java.net.URLClassLoader;

import net.janino.ClassLoaderIClassLoader;
import net.janino.DebuggingInformation;
import net.janino.IClassLoader;
import net.janino.Parser;
import net.janino.Scanner;
import net.janino.Java.CompilationUnit;


/**
 * JaninoTest
 *
 * @author Eugene Kuleshov
 */
public class Bug_1032563 {

  public static void main( String[] args) throws Exception {
    String code = "package asm.com.sun.imageio.plugins.jpeg;\r\n" + 
        "import org.objectweb.asm.*;\r\n" + 
        "import org.objectweb.asm.attrs.*;\r\n" + 
        "import java.util.*;\r\n" + 
        "\r\n" + 
        "public class JPEGImageWriterDump implements Constants {\r\n" + 
        "\r\n" + 
        "public static byte[] dump () throws Exception {\r\n" + 
        "\r\n" + 
        "ClassWriter cw = new ClassWriter(false);\r\n" + 
        "CodeVisitor cv;\r\n" + 
        "\r\n" + 
        "cw.visit(V1_4, ACC_PUBLIC + ACC_SUPER, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"javax/imageio/ImageWriter\", null, \"JPEGImageWriter.java\");\r\n" + 
        "\r\n" + 
        "cw.visitInnerClass(\"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\", \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment\", \"Htable\", 0);\r\n" + 
        "\r\n" + 
        "cw.visitInnerClass(\"com/sun/imageio/plugins/jpeg/DQTMarkerSegment$Qtable\", \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment\", \"Qtable\", 0);\r\n" + 
        "\r\n" + 
        "cw.visitInnerClass(\"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"ComponentSpec\", 0);\r\n" + 
        "\r\n" + 
        "cw.visitInnerClass(\"com/sun/imageio/plugins/jpeg/SOSMarkerSegment$ScanComponentSpec\", \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"ScanComponentSpec\", 0);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"debug\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"structPointer\", \"J\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"srcRas\", \"Ljava/awt/image/Raster;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"raster\", \"Ljava/awt/image/WritableRaster;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"indexed\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"indexCM\", \"Ljava/awt/image/IndexColorModel;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"convertTosRGB\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"converted\", \"Ljava/awt/image/WritableRaster;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"thumbnails\", \"Ljava/util/List;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"sourceXOffset\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"sourceYOffset\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"sourceWidth\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"srcBands\", \"[I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"sourceHeight\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"currentImage\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"convertOp\", \"Ljava/awt/image/ColorConvertOp;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"ignoreJFIF\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"forceJFIF\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"ignoreAdobe\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"newAdobeTransform\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"writeDefaultJFIF\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"writeAdobe\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"sequencePrepared\", \"Z\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE, \"numScans\", \"I\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_DEST_IGNORED\", \"I\", new Integer(0), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_STREAM_METADATA_IGNORED\", \"I\", new Integer(1), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_DEST_METADATA_COMP_MISMATCH\", \"I\", new Integer(2), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_DEST_METADATA_JFIF_MISMATCH\", \"I\", new Integer(3), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_DEST_METADATA_ADOBE_MISMATCH\", \"I\", new Integer(4), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_IMAGE_METADATA_JFIF_MISMATCH\", \"I\", new Integer(5), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_IMAGE_METADATA_ADOBE_MISMATCH\", \"I\", new Integer(6), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_METADATA_NOT_JPEG_FOR_RASTER\", \"I\", new Integer(7), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_NO_BANDS_ON_INDEXED\", \"I\", new Integer(8), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_ILLEGAL_THUMBNAIL\", \"I\", new Integer(9), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_IGNORING_THUMBS\", \"I\", new Integer(10), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_FORCING_JFIF\", \"I\", new Integer(11), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_THUMB_CLIPPED\", \"I\", new Integer(12), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_METADATA_ADJUSTED_FOR_THUMB\", \"I\", new Integer(13), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_NO_RGB_THUMB_AS_INDEXED\", \"I\", new Integer(14), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PROTECTED + ACC_FINAL + ACC_STATIC, \"WARNING_NO_GRAY_THUMB_AS_INDEXED\", \"I\", new Integer(15), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_PRIVATE + ACC_FINAL + ACC_STATIC, \"MAX_WARNING\", \"I\", new Integer(15), null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_FINAL + ACC_STATIC, \"preferredThumbSizes\", \"[Ljava/awt/Dimension;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$javax$imageio$stream$ImageOutputStream\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$javax$imageio$plugins$jpeg$JPEGQTable\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$javax$imageio$plugins$jpeg$JPEGHuffmanTable\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$com$sun$imageio$plugins$jpeg$AdobeMarkerSegment\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$com$sun$imageio$plugins$jpeg$DQTMarkerSegment\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$com$sun$imageio$plugins$jpeg$DHTMarkerSegment\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "cw.visitField(ACC_STATIC + ACC_SYNTHETIC, \"class$com$sun$imageio$plugins$jpeg$DRIMarkerSegment\", \"Ljava/lang/Class;\", null, null);\r\n" + 
        "\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"initJPEGImageWriter\", \"()J\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_STATIC, \"<clinit>\", \"()V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"sun/security/action/LoadLibraryAction\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"jpeg\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"sun/security/action/LoadLibraryAction\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"java/security/AccessController\", \"doPrivileged\", \"(Ljava/security/PrivilegedAction;)Ljava/lang/Object;\");\r\n" + 
        "cv.visitInsn(POP);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$stream$ImageOutputStream\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l2);\r\n" + 
        "cv.visitLdcInsn(\"javax.imageio.stream.ImageOutputStream\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$stream$ImageOutputStream\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$stream$ImageOutputStream\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$plugins$jpeg$JPEGQTable\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l4);\r\n" + 
        "cv.visitLdcInsn(\"javax.imageio.plugins.jpeg.JPEGQTable\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$plugins$jpeg$JPEGQTable\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l5);\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$plugins$jpeg$JPEGQTable\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$plugins$jpeg$JPEGHuffmanTable\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l6);\r\n" + 
        "cv.visitLdcInsn(\"javax.imageio.plugins.jpeg.JPEGHuffmanTable\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$plugins$jpeg$JPEGHuffmanTable\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l7);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$javax$imageio$plugins$jpeg$JPEGHuffmanTable\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"initWriterIDs\", \"(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/Class;)V\");\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitTypeInsn(ANEWARRAY, \"java/awt/Dimension\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/awt/Dimension\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/awt/Dimension\", \"<init>\", \"(II)V\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/awt/Dimension\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitIntInsn(SIPUSH, 255);\r\n" + 
        "cv.visitIntInsn(SIPUSH, 255);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/awt/Dimension\", \"<init>\", \"(II)V\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"preferredThumbSizes\", \"[Ljava/awt/Dimension;\");\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(149, l0);\r\n" + 
        "cv.visitLineNumber(151, l1);\r\n" + 
        "cv.visitLineNumber(253, l8);\r\n" + 
        "cv.visitMaxs(7, 0);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC + ACC_SYNCHRONIZED, \"abort\", \"()V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageWriter\", \"abort\", \"()V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"abortWrite\", \"(J)V\");\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1067, l0);\r\n" + 
        "cv.visitLineNumber(1068, l1);\r\n" + 
        "cv.visitLineNumber(1069, l2);\r\n" + 
        "cv.visitMaxs(3, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"dispose\", \"()V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitInsn(LCONST_0);\r\n" + 
        "cv.visitInsn(LCMP);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"disposeWriter\", \"(J)V\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(LCONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1086, l0);\r\n" + 
        "cv.visitLineNumber(1087, l2);\r\n" + 
        "cv.visitLineNumber(1088, l3);\r\n" + 
        "cv.visitLineNumber(1090, l1);\r\n" + 
        "cv.visitMaxs(4, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"endWriteSequence\", \"()V\", new String[] { \"java/io/IOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sequencePrepared\", \"Z\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/IllegalStateException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"sequencePrepared not called!\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/IllegalStateException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sequencePrepared\", \"Z\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1060, l0);\r\n" + 
        "cv.visitLineNumber(1061, l2);\r\n" + 
        "cv.visitLineNumber(1063, l1);\r\n" + 
        "cv.visitLineNumber(1064, l3);\r\n" + 
        "cv.visitMaxs(3, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"finalize\", \"()V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"dispose\", \"()V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1093, l0);\r\n" + 
        "cv.visitLineNumber(1094, l1);\r\n" + 
        "cv.visitMaxs(1, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"reset\", \"()V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"resetWriter\", \"(J)V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageWriter\", \"reset\", \"()V\");\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"raster\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertTosRGB\", \"Z\");\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"java/lang/System\", \"gc\", \"()V\");\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1073, l0);\r\n" + 
        "cv.visitLineNumber(1075, l1);\r\n" + 
        "cv.visitLineNumber(1076, l2);\r\n" + 
        "cv.visitLineNumber(1077, l3);\r\n" + 
        "cv.visitLineNumber(1078, l4);\r\n" + 
        "cv.visitLineNumber(1079, l5);\r\n" + 
        "cv.visitLineNumber(1080, l6);\r\n" + 
        "cv.visitLineNumber(1081, l7);\r\n" + 
        "cv.visitLineNumber(1082, l8);\r\n" + 
        "cv.visitLineNumber(1083, l9);\r\n" + 
        "cv.visitMaxs(3, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(0, \"thumbnailComplete\", \"()V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processThumbnailComplete\", \"()V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1143, l0);\r\n" + 
        "cv.visitLineNumber(1144, l1);\r\n" + 
        "cv.visitMaxs(1, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"writeMetadata\", \"()V\", new String[] { \"java/io/IOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeDefaultJFIF\", \"Z\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JFIFMarkerSegment\", \"writeDefaultJFIF\", \"(Ljavax/imageio/stream/ImageOutputStream;Ljava/util/List;Ljava/awt/color/ICC_Profile;Lcom/sun/imageio/plugins/jpeg/JPEGImageWriter;)V\");\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeAdobe\", \"Z\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"writeAdobeSegment\", \"(Ljavax/imageio/stream/ImageOutputStream;I)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l5);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"forceJFIF\", \"Z\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreAdobe\", \"Z\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"writeToStream\", \"(Ljavax/imageio/stream/ImageOutputStream;ZZLjava/util/List;Ljava/awt/color/ICC_Profile;ZILcom/sun/imageio/plugins/jpeg/JPEGImageWriter;)V\");\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1502, l0);\r\n" + 
        "cv.visitLineNumber(1503, l2);\r\n" + 
        "cv.visitLineNumber(1504, l4);\r\n" + 
        "cv.visitLineNumber(1509, l3);\r\n" + 
        "cv.visitLineNumber(1510, l6);\r\n" + 
        "cv.visitLineNumber(1513, l1);\r\n" + 
        "cv.visitLineNumber(1522, l5);\r\n" + 
        "cv.visitMaxs(9, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"canWriteRasters\", \"()Z\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(294, l0);\r\n" + 
        "cv.visitMaxs(1, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(0, \"thumbnailProgress\", \"(F)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(FLOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processThumbnailProgress\", \"(F)V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1138, l0);\r\n" + 
        "cv.visitLineNumber(1139, l1);\r\n" + 
        "cv.visitMaxs(2, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"grabPixels\", \"(I)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l2);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"createChild\", \"(IIIIII[I)Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexCM\", \"Ljava/awt/image/IndexColorModel;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/IndexColorModel\", \"getTransparency\", \"()I\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l5);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ISTORE, 3);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexCM\", \"Ljava/awt/image/IndexColorModel;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/IndexColorModel\", \"convertToIntDiscrete\", \"(Ljava/awt/image/Raster;Z)Ljava/awt/image/BufferedImage;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/BufferedImage\", \"getRaster\", \"()Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l9);\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcBands\", \"[I\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"createChild\", \"(IIIIII[I)Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertTosRGB\", \"Z\");\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l10);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"debug\", \"Z\");\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l12);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitLdcInsn(\"Converting to sRGB\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertOp\", \"Ljava/awt/image/ColorConvertOp;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"converted\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorConvertOp\", \"filter\", \"(Ljava/awt/image/Raster;Ljava/awt/image/WritableRaster;)Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"converted\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"converted\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"raster\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/WritableRaster\", \"setRect\", \"(Ljava/awt/image/Raster;)V\");\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPLE, l16);\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 8);\r\n" + 
        "cv.visitInsn(IREM);\r\n" + 
        "cv.visitJumpInsn(IFNE, l16);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitInsn(I2F);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "cv.visitInsn(I2F);\r\n" + 
        "cv.visitInsn(FDIV);\r\n" + 
        "cv.visitLdcInsn(new Float(\"100.0\"));\r\n" + 
        "cv.visitInsn(FMUL);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processImageProgress\", \"(F)V\");\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1541, l0);\r\n" + 
        "cv.visitLineNumber(1542, l1);\r\n" + 
        "cv.visitLineNumber(1543, l3);\r\n" + 
        "cv.visitLineNumber(1551, l4);\r\n" + 
        "cv.visitLineNumber(1553, l7);\r\n" + 
        "cv.visitLineNumber(1555, l8);\r\n" + 
        "cv.visitLineNumber(1557, l2);\r\n" + 
        "cv.visitLineNumber(1563, l9);\r\n" + 
        "cv.visitLineNumber(1564, l11);\r\n" + 
        "cv.visitLineNumber(1565, l13);\r\n" + 
        "cv.visitLineNumber(1570, l12);\r\n" + 
        "cv.visitLineNumber(1571, l14);\r\n" + 
        "cv.visitLineNumber(1573, l10);\r\n" + 
        "cv.visitLineNumber(1574, l15);\r\n" + 
        "cv.visitLineNumber(1575, l17);\r\n" + 
        "cv.visitLineNumber(1577, l16);\r\n" + 
        "cv.visitMaxs(11, 5);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(0, \"thumbnailStarted\", \"(I)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processThumbnailStarted\", \"(II)V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1133, l0);\r\n" + 
        "cv.visitLineNumber(1134, l1);\r\n" + 
        "cv.visitMaxs(3, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(0, \"warningOccurred\", \"(I)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFLT, l1);\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 15);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPLE, l2);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/InternalError\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Invalid warning index\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/InternalError\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.JPEGImageWriterResources\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"java/lang/Integer\", \"toString\", \"(I)Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processWarningOccurred\", \"(ILjava/lang/String;Ljava/lang/String;)V\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1106, l0);\r\n" + 
        "cv.visitLineNumber(1107, l1);\r\n" + 
        "cv.visitLineNumber(1109, l2);\r\n" + 
        "cv.visitLineNumber(1113, l3);\r\n" + 
        "cv.visitMaxs(4, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"abortWrite\", \"(J)V\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"disposeWriter\", \"(J)V\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"resetWriter\", \"(J)V\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"checkSOFBands\", \"(Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment;I)V\", new String[] { \"javax/imageio/IIOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "cv.visitVarInsn(ILOAD, 2);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l1);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Metadata components != number of destination bands\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1155, l0);\r\n" + 
        "cv.visitLineNumber(1156, l2);\r\n" + 
        "cv.visitLineNumber(1157, l3);\r\n" + 
        "cv.visitLineNumber(1161, l1);\r\n" + 
        "cv.visitMaxs(3, 3);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"isSubsampled\", \"([Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;)Z\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"HsamplingFactor\", \"I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"VsamplingFactor\", \"I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 3);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 4);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l4);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"HsamplingFactor\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 2);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"HsamplingFactor\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 2);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l7);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitIincInsn(4, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(1441, l0);\r\n" + 
        "cv.visitLineNumber(1442, l1);\r\n" + 
        "cv.visitLineNumber(1443, l2);\r\n" + 
        "cv.visitLineNumber(1444, l5);\r\n" + 
        "cv.visitLineNumber(1446, l6);\r\n" + 
        "cv.visitLineNumber(1443, l7);\r\n" + 
        "cv.visitLineNumber(1448, l4);\r\n" + 
        "cv.visitMaxs(2, 5);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"getDefaultDestCSType\", \"(Ljava/awt/image/RenderedImage;)I\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/awt/image/RenderedImage\", \"getColorModel\", \"()Ljava/awt/image/ColorModel;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 3);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"hasAlpha\", \"()Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 4);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getColorSpace\", \"()Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ColorSpace\", \"getType\", \"()I\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitTableSwitchInsn(3, 13, l3, new Label[] { l7, l3, l8, l9, l3, l3, l10, l3, l3, l3, l11 });\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l13);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l16);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"YCC\", \"Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitJumpInsn(IF_ACMPNE, l10);\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l20);\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitJumpInsn(GOTO, l10);\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 11);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ILOAD, 2);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(1401, l0);\r\n" + 
        "cv.visitLineNumber(1402, l1);\r\n" + 
        "cv.visitLineNumber(1403, l2);\r\n" + 
        "cv.visitLineNumber(1404, l4);\r\n" + 
        "cv.visitLineNumber(1405, l5);\r\n" + 
        "cv.visitLineNumber(1406, l6);\r\n" + 
        "cv.visitLineNumber(1408, l9);\r\n" + 
        "cv.visitLineNumber(1409, l12);\r\n" + 
        "cv.visitLineNumber(1411, l8);\r\n" + 
        "cv.visitLineNumber(1412, l14);\r\n" + 
        "cv.visitLineNumber(1414, l13);\r\n" + 
        "cv.visitLineNumber(1416, l15);\r\n" + 
        "cv.visitLineNumber(1418, l7);\r\n" + 
        "cv.visitLineNumber(1419, l17);\r\n" + 
        "cv.visitLineNumber(1421, l16);\r\n" + 
        "cv.visitLineNumber(1423, l18);\r\n" + 
        "cv.visitLineNumber(1425, l11);\r\n" + 
        "cv.visitLineNumber(1426, l19);\r\n" + 
        "cv.visitLineNumber(1427, l21);\r\n" + 
        "cv.visitLineNumber(1429, l20);\r\n" + 
        "cv.visitLineNumber(1433, l10);\r\n" + 
        "cv.visitLineNumber(1437, l3);\r\n" + 
        "cv.visitMaxs(2, 6);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"getSrcCSType\", \"(Ljava/awt/image/RenderedImage;)I\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/awt/image/RenderedImage\", \"getColorModel\", \"()Ljava/awt/image/ColorModel;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 3);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"hasAlpha\", \"()Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 4);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getColorSpace\", \"()Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ColorSpace\", \"getType\", \"()I\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitTableSwitchInsn(3, 13, l3, new Label[] { l7, l3, l8, l9, l3, l3, l10, l3, l3, l3, l11 });\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l13);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l16);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"YCC\", \"Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitJumpInsn(IF_ACMPNE, l10);\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l20);\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitJumpInsn(GOTO, l10);\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitInsn(ICONST_4);\r\n" + 
        "cv.visitVarInsn(ISTORE, 2);\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ILOAD, 2);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(1323, l0);\r\n" + 
        "cv.visitLineNumber(1324, l1);\r\n" + 
        "cv.visitLineNumber(1325, l2);\r\n" + 
        "cv.visitLineNumber(1326, l4);\r\n" + 
        "cv.visitLineNumber(1327, l5);\r\n" + 
        "cv.visitLineNumber(1328, l6);\r\n" + 
        "cv.visitLineNumber(1330, l9);\r\n" + 
        "cv.visitLineNumber(1331, l12);\r\n" + 
        "cv.visitLineNumber(1333, l8);\r\n" + 
        "cv.visitLineNumber(1334, l14);\r\n" + 
        "cv.visitLineNumber(1336, l13);\r\n" + 
        "cv.visitLineNumber(1338, l15);\r\n" + 
        "cv.visitLineNumber(1340, l7);\r\n" + 
        "cv.visitLineNumber(1341, l17);\r\n" + 
        "cv.visitLineNumber(1343, l16);\r\n" + 
        "cv.visitLineNumber(1345, l18);\r\n" + 
        "cv.visitLineNumber(1347, l11);\r\n" + 
        "cv.visitLineNumber(1348, l19);\r\n" + 
        "cv.visitLineNumber(1349, l21);\r\n" + 
        "cv.visitLineNumber(1351, l20);\r\n" + 
        "cv.visitLineNumber(1355, l10);\r\n" + 
        "cv.visitLineNumber(1359, l3);\r\n" + 
        "cv.visitMaxs(2, 6);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"setOutput\", \"(Ljava/lang/Object;)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageWriter\", \"setOutput\", \"(Ljava/lang/Object;)V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"javax/imageio/stream/ImageOutputStream\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"setDest\", \"(JLjavax/imageio/stream/ImageOutputStream;)V\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"raster\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"java/lang/System\", \"gc\", \"()V\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(165, l0);\r\n" + 
        "cv.visitLineNumber(166, l1);\r\n" + 
        "cv.visitLineNumber(168, l2);\r\n" + 
        "cv.visitLineNumber(169, l3);\r\n" + 
        "cv.visitLineNumber(170, l4);\r\n" + 
        "cv.visitLineNumber(171, l5);\r\n" + 
        "cv.visitLineNumber(172, l6);\r\n" + 
        "cv.visitLineNumber(173, l7);\r\n" + 
        "cv.visitMaxs(4, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(0, \"warningWithMessage\", \"(Ljava/lang/String;)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processWarningOccurred\", \"(ILjava/lang/String;)V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1129, l0);\r\n" + 
        "cv.visitLineNumber(1130, l1);\r\n" + 
        "cv.visitMaxs(3, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"getDestCSType\", \"(Ljavax/imageio/ImageTypeSpecifier;)I\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageTypeSpecifier\", \"getColorModel\", \"()Ljava/awt/image/ColorModel;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"hasAlpha\", \"()Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 3);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getColorSpace\", \"()Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ColorSpace\", \"getType\", \"()I\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitTableSwitchInsn(3, 13, l6, new Label[] { l5, l6, l7, l8, l6, l6, l9, l6, l6, l6, l10 });\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l12);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l15);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"YCC\", \"Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitJumpInsn(IF_ACMPNE, l9);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l19);\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "cv.visitJumpInsn(GOTO, l9);\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitInsn(ICONST_4);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 5);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(1363, l0);\r\n" + 
        "cv.visitLineNumber(1364, l1);\r\n" + 
        "cv.visitLineNumber(1365, l2);\r\n" + 
        "cv.visitLineNumber(1366, l3);\r\n" + 
        "cv.visitLineNumber(1367, l4);\r\n" + 
        "cv.visitLineNumber(1369, l8);\r\n" + 
        "cv.visitLineNumber(1370, l11);\r\n" + 
        "cv.visitLineNumber(1372, l7);\r\n" + 
        "cv.visitLineNumber(1373, l13);\r\n" + 
        "cv.visitLineNumber(1375, l12);\r\n" + 
        "cv.visitLineNumber(1377, l14);\r\n" + 
        "cv.visitLineNumber(1379, l5);\r\n" + 
        "cv.visitLineNumber(1380, l16);\r\n" + 
        "cv.visitLineNumber(1382, l15);\r\n" + 
        "cv.visitLineNumber(1384, l17);\r\n" + 
        "cv.visitLineNumber(1386, l10);\r\n" + 
        "cv.visitLineNumber(1387, l18);\r\n" + 
        "cv.visitLineNumber(1388, l20);\r\n" + 
        "cv.visitLineNumber(1390, l19);\r\n" + 
        "cv.visitLineNumber(1394, l9);\r\n" + 
        "cv.visitLineNumber(1397, l6);\r\n" + 
        "cv.visitMaxs(2, 6);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"getDefaultWriteParam\", \"()Ljavax/imageio/ImageWriteParam;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"<init>\", \"(Ljava/util/Locale;)V\");\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(176, l0);\r\n" + 
        "cv.visitMaxs(3, 1);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"prepareWriteSequence\", \"(Ljavax/imageio/metadata/IIOMetadata;)V\", new String[] { \"java/io/IOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/IllegalStateException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Output has not been set!\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/IllegalStateException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"isStream\", \"Z\");\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l8);\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/IllegalArgumentException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Invalid stream metadata object.\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/IllegalArgumentException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l10);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"JPEG Stream metadata must precede all images\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sequencePrepared\", \"Z\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l12);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Stream metadata already written!\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectQTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;)[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"debug\", \"Z\");\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l15);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"after collecting from stream metadata, streamQTables.length is \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(I)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l17);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"getDefaultQTables\", \"()[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectHTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l20);\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"getDefaultHuffmanTables\", \"(Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectHTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l22 = new Label();\r\n" + 
        "cv.visitLabel(l22);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l23 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l23);\r\n" + 
        "Label l24 = new Label();\r\n" + 
        "cv.visitLabel(l24);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"getDefaultHuffmanTables\", \"(Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitLabel(l23);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeTables\", \"(J[Ljavax/imageio/plugins/jpeg/JPEGQTable;[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l3);\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Stream metadata must be JPEG metadata\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sequencePrepared\", \"Z\");\r\n" + 
        "Label l25 = new Label();\r\n" + 
        "cv.visitLabel(l25);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(983, l0);\r\n" + 
        "cv.visitLineNumber(984, l2);\r\n" + 
        "cv.visitLineNumber(996, l1);\r\n" + 
        "cv.visitLineNumber(997, l4);\r\n" + 
        "cv.visitLineNumber(1000, l6);\r\n" + 
        "cv.visitLineNumber(1001, l7);\r\n" + 
        "cv.visitLineNumber(1002, l9);\r\n" + 
        "cv.visitLineNumber(1008, l8);\r\n" + 
        "cv.visitLineNumber(1009, l11);\r\n" + 
        "cv.visitLineNumber(1012, l10);\r\n" + 
        "cv.visitLineNumber(1013, l13);\r\n" + 
        "cv.visitLineNumber(1018, l12);\r\n" + 
        "cv.visitLineNumber(1019, l14);\r\n" + 
        "cv.visitLineNumber(1020, l16);\r\n" + 
        "cv.visitLineNumber(1024, l15);\r\n" + 
        "cv.visitLineNumber(1025, l18);\r\n" + 
        "cv.visitLineNumber(1027, l17);\r\n" + 
        "cv.visitLineNumber(1029, l19);\r\n" + 
        "cv.visitLineNumber(1030, l21);\r\n" + 
        "cv.visitLineNumber(1032, l20);\r\n" + 
        "cv.visitLineNumber(1034, l22);\r\n" + 
        "cv.visitLineNumber(1035, l24);\r\n" + 
        "cv.visitLineNumber(1039, l23);\r\n" + 
        "cv.visitLineNumber(1044, l5);\r\n" + 
        "cv.visitLineNumber(1047, l3);\r\n" + 
        "cv.visitLineNumber(1048, l25);\r\n" + 
        "cv.visitMaxs(6, 3);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"<init>\", \"(Ljavax/imageio/spi/ImageWriterSpi;)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageWriter\", \"<init>\", \"(Ljavax/imageio/spi/ImageWriterSpi;)V\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"debug\", \"Z\");\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(LCONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"raster\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexCM\", \"Ljava/awt/image/IndexColorModel;\");\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertTosRGB\", \"Z\");\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"converted\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcBands\", \"[I\");\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertOp\", \"Ljava/awt/image/ColorConvertOp;\");\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l22 = new Label();\r\n" + 
        "cv.visitLabel(l22);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "Label l23 = new Label();\r\n" + 
        "cv.visitLabel(l23);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"forceJFIF\", \"Z\");\r\n" + 
        "Label l24 = new Label();\r\n" + 
        "cv.visitLabel(l24);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreAdobe\", \"Z\");\r\n" + 
        "Label l25 = new Label();\r\n" + 
        "cv.visitLabel(l25);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_M1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l26 = new Label();\r\n" + 
        "cv.visitLabel(l26);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeDefaultJFIF\", \"Z\");\r\n" + 
        "Label l27 = new Label();\r\n" + 
        "cv.visitLabel(l27);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeAdobe\", \"Z\");\r\n" + 
        "Label l28 = new Label();\r\n" + 
        "cv.visitLabel(l28);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l29 = new Label();\r\n" + 
        "cv.visitLabel(l29);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sequencePrepared\", \"Z\");\r\n" + 
        "Label l30 = new Label();\r\n" + 
        "cv.visitLabel(l30);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "Label l31 = new Label();\r\n" + 
        "cv.visitLabel(l31);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"initJPEGImageWriter\", \"()J\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "Label l32 = new Label();\r\n" + 
        "cv.visitLabel(l32);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(159, l0);\r\n" + 
        "cv.visitLineNumber(53, l1);\r\n" + 
        "cv.visitLineNumber(61, l2);\r\n" + 
        "cv.visitLineNumber(65, l3);\r\n" + 
        "cv.visitLineNumber(68, l4);\r\n" + 
        "cv.visitLineNumber(71, l5);\r\n" + 
        "cv.visitLineNumber(77, l6);\r\n" + 
        "cv.visitLineNumber(78, l7);\r\n" + 
        "cv.visitLineNumber(80, l8);\r\n" + 
        "cv.visitLineNumber(81, l9);\r\n" + 
        "cv.visitLineNumber(86, l10);\r\n" + 
        "cv.visitLineNumber(91, l11);\r\n" + 
        "cv.visitLineNumber(93, l12);\r\n" + 
        "cv.visitLineNumber(94, l13);\r\n" + 
        "cv.visitLineNumber(95, l14);\r\n" + 
        "cv.visitLineNumber(96, l15);\r\n" + 
        "cv.visitLineNumber(97, l16);\r\n" + 
        "cv.visitLineNumber(100, l17);\r\n" + 
        "cv.visitLineNumber(102, l18);\r\n" + 
        "cv.visitLineNumber(104, l19);\r\n" + 
        "cv.visitLineNumber(105, l20);\r\n" + 
        "cv.visitLineNumber(106, l21);\r\n" + 
        "cv.visitLineNumber(109, l22);\r\n" + 
        "cv.visitLineNumber(110, l23);\r\n" + 
        "cv.visitLineNumber(111, l24);\r\n" + 
        "cv.visitLineNumber(112, l25);\r\n" + 
        "cv.visitLineNumber(113, l26);\r\n" + 
        "cv.visitLineNumber(114, l27);\r\n" + 
        "cv.visitLineNumber(115, l28);\r\n" + 
        "cv.visitLineNumber(117, l29);\r\n" + 
        "cv.visitLineNumber(119, l30);\r\n" + 
        "cv.visitLineNumber(160, l31);\r\n" + 
        "cv.visitLineNumber(161, l32);\r\n" + 
        "cv.visitMaxs(3, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"setDest\", \"(JLjavax/imageio/stream/ImageOutputStream;)V\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"collectScans\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment;)[I\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/util/ArrayList\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/util/ArrayList\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 3);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 9);\r\n" + 
        "cv.visitVarInsn(ISTORE, 4);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitInsn(ICONST_4);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"markerSequence\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"iterator\", \"()Ljava/util/Iterator;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 6);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/Iterator\", \"hasNext\", \"()Z\");\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/Iterator\", \"next\", \"()Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/MarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 7);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l4);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"add\", \"(Ljava/lang/Object;)Z\");\r\n" + 
        "cv.visitInsn(POP);\r\n" + 
        "cv.visitJumpInsn(GOTO, l4);\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 6);\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"isEmpty\", \"()Z\");\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l11);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"size\", \"()I\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitInsn(IMUL);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 6);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 7);\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 8);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitVarInsn(ILOAD, 8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l11);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ILOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"get\", \"(I)Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 9);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOSMarkerSegment$ScanComponentSpec;\");\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 10);\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitVarInsn(ILOAD, 10);\r\n" + 
        "cv.visitVarInsn(ILOAD, 5);\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l21);\r\n" + 
        "Label l22 = new Label();\r\n" + 
        "cv.visitLabel(l22);\r\n" + 
        "cv.visitVarInsn(ILOAD, 10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOSMarkerSegment$ScanComponentSpec;\");\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "Label l23 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l23);\r\n" + 
        "Label l24 = new Label();\r\n" + 
        "cv.visitLabel(l24);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOSMarkerSegment$ScanComponentSpec;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 10);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment$ScanComponentSpec\", \"componentSelector\", \"I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 11);\r\n" + 
        "Label l25 = new Label();\r\n" + 
        "cv.visitLabel(l25);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 12);\r\n" + 
        "Label l26 = new Label();\r\n" + 
        "cv.visitLabel(l26);\r\n" + 
        "cv.visitVarInsn(ILOAD, 12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "Label l27 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l27);\r\n" + 
        "Label l28 = new Label();\r\n" + 
        "cv.visitLabel(l28);\r\n" + 
        "cv.visitVarInsn(ILOAD, 11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 12);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"componentId\", \"I\");\r\n" + 
        "Label l29 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l29);\r\n" + 
        "Label l30 = new Label();\r\n" + 
        "cv.visitLabel(l30);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitVarInsn(ILOAD, 12);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l31 = new Label();\r\n" + 
        "cv.visitLabel(l31);\r\n" + 
        "cv.visitJumpInsn(GOTO, l27);\r\n" + 
        "cv.visitLabel(l29);\r\n" + 
        "cv.visitIincInsn(12, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l26);\r\n" + 
        "cv.visitLabel(l23);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "cv.visitLabel(l27);\r\n" + 
        "cv.visitIincInsn(10, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l20);\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"startSpectralSelection\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l32 = new Label();\r\n" + 
        "cv.visitLabel(l32);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"endSpectralSelection\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l33 = new Label();\r\n" + 
        "cv.visitLabel(l33);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"approxHigh\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l34 = new Label();\r\n" + 
        "cv.visitLabel(l34);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 9);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOSMarkerSegment\", \"approxLow\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l35 = new Label();\r\n" + 
        "cv.visitLabel(l35);\r\n" + 
        "cv.visitIincInsn(8, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l16);\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(1202, l0);\r\n" + 
        "cv.visitLineNumber(1203, l1);\r\n" + 
        "cv.visitLineNumber(1204, l2);\r\n" + 
        "cv.visitLineNumber(1205, l3);\r\n" + 
        "cv.visitLineNumber(1206, l4);\r\n" + 
        "cv.visitLineNumber(1207, l6);\r\n" + 
        "cv.visitLineNumber(1208, l7);\r\n" + 
        "cv.visitLineNumber(1209, l8);\r\n" + 
        "cv.visitLineNumber(1212, l5);\r\n" + 
        "cv.visitLineNumber(1213, l9);\r\n" + 
        "cv.visitLineNumber(1214, l10);\r\n" + 
        "cv.visitLineNumber(1215, l12);\r\n" + 
        "cv.visitLineNumber(1216, l13);\r\n" + 
        "cv.visitLineNumber(1217, l14);\r\n" + 
        "cv.visitLineNumber(1218, l15);\r\n" + 
        "cv.visitLineNumber(1219, l17);\r\n" + 
        "cv.visitLineNumber(1220, l18);\r\n" + 
        "cv.visitLineNumber(1221, l19);\r\n" + 
        "cv.visitLineNumber(1222, l22);\r\n" + 
        "cv.visitLineNumber(1223, l24);\r\n" + 
        "cv.visitLineNumber(1224, l25);\r\n" + 
        "cv.visitLineNumber(1225, l28);\r\n" + 
        "cv.visitLineNumber(1226, l30);\r\n" + 
        "cv.visitLineNumber(1227, l31);\r\n" + 
        "cv.visitLineNumber(1224, l29);\r\n" + 
        "cv.visitLineNumber(1231, l23);\r\n" + 
        "cv.visitLineNumber(1221, l27);\r\n" + 
        "cv.visitLineNumber(1234, l21);\r\n" + 
        "cv.visitLineNumber(1235, l32);\r\n" + 
        "cv.visitLineNumber(1236, l33);\r\n" + 
        "cv.visitLineNumber(1237, l34);\r\n" + 
        "cv.visitLineNumber(1218, l35);\r\n" + 
        "cv.visitLineNumber(1240, l11);\r\n" + 
        "cv.visitMaxs(3, 13);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_STATIC + ACC_SYNTHETIC, \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"java/lang/Class\", \"forName\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ASTORE, 1);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/NoClassDefFoundError\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/NoClassDefFoundError\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/NoClassDefFoundError\", \"initCause\", \"(Ljava/lang/Throwable;)Ljava/lang/Throwable;\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitTryCatchBlock(l0, l1, l2, \"java/lang/ClassNotFoundException\");\r\n" + 
        "cv.visitLineNumber(151, l0);\r\n" + 
        "cv.visitMaxs(2, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"checkAdobe\", \"(Lcom/sun/imageio/plugins/jpeg/AdobeMarkerSegment;Ljavax/imageio/ImageTypeSpecifier;Z)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"transformForType\", \"(Ljavax/imageio/ImageTypeSpecifier;Z)I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 4);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"transform\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l1);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l5);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitInsn(ICONST_4);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitInsn(ICONST_M1);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l8);\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreAdobe\", \"Z\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l1);\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1179, l0);\r\n" + 
        "cv.visitLineNumber(1180, l2);\r\n" + 
        "cv.visitLineNumber(1181, l3);\r\n" + 
        "cv.visitLineNumber(1182, l4);\r\n" + 
        "cv.visitLineNumber(1185, l7);\r\n" + 
        "cv.visitLineNumber(1186, l9);\r\n" + 
        "cv.visitLineNumber(1188, l8);\r\n" + 
        "cv.visitLineNumber(1192, l1);\r\n" + 
        "cv.visitMaxs(2, 5);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"checkJFIF\", \"(Lcom/sun/imageio/plugins/jpeg/JFIFMarkerSegment;Ljavax/imageio/ImageTypeSpecifier;Z)V\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isJFIFcompliant\", \"(Ljavax/imageio/ImageTypeSpecifier;Z)Z\");\r\n" + 
        "cv.visitJumpInsn(IFNE, l1);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 3);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l5);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l6);\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1166, l0);\r\n" + 
        "cv.visitLineNumber(1167, l2);\r\n" + 
        "cv.visitLineNumber(1168, l3);\r\n" + 
        "cv.visitLineNumber(1169, l4);\r\n" + 
        "cv.visitLineNumber(1174, l1);\r\n" + 
        "cv.visitMaxs(2, 4);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"writeToSequence\", \"(Ljavax/imageio/IIOImage;Ljavax/imageio/ImageWriteParam;)V\", new String[] { \"java/io/IOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sequencePrepared\", \"Z\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/IllegalStateException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"sequencePrepared not called!\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/IllegalStateException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"write\", \"(Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/IIOImage;Ljavax/imageio/ImageWriteParam;)V\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(1052, l0);\r\n" + 
        "cv.visitLineNumber(1053, l2);\r\n" + 
        "cv.visitLineNumber(1056, l1);\r\n" + 
        "cv.visitLineNumber(1057, l3);\r\n" + 
        "cv.visitMaxs(4, 3);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"getDefaultStreamMetadata\", \"(Ljavax/imageio/ImageWriteParam;)Ljavax/imageio/metadata/IIOMetadata;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"<init>\", \"(Ljavax/imageio/ImageWriteParam;Lcom/sun/imageio/plugins/jpeg/JPEGImageWriter;)V\");\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(180, l0);\r\n" + 
        "cv.visitMaxs(4, 2);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"collectHTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\", new String[] { \"javax/imageio/IIOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/util/ArrayList\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/util/ArrayList\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 3);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"markerSequence\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"iterator\", \"()Ljava/util/Iterator;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/Iterator\", \"hasNext\", \"()Z\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/Iterator\", \"next\", \"()Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/MarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l2);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 6);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 7);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment\", \"tables\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"size\", \"()I\");\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l2);\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment\", \"tables\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"get\", \"(I)Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 8);\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\", \"tableClass\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 2);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l11);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l12);\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l13);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"add\", \"(Ljava/lang/Object;)Z\");\r\n" + 
        "cv.visitInsn(POP);\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l8);\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"size\", \"()I\");\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l16);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"size\", \"()I\");\r\n" + 
        "cv.visitTypeInsn(ANEWARRAY, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 6);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"toArray\", \"([Ljava/lang/Object;)[Ljava/lang/Object;\");\r\n" + 
        "cv.visitInsn(POP);\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"size\", \"()I\");\r\n" + 
        "cv.visitTypeInsn(ANEWARRAY, \"javax/imageio/plugins/jpeg/JPEGHuffmanTable\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 7);\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l16);\r\n" + 
        "Label l22 = new Label();\r\n" + 
        "cv.visitLabel(l22);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "Label l23 = new Label();\r\n" + 
        "cv.visitLabel(l23);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 8);\r\n" + 
        "Label l24 = new Label();\r\n" + 
        "cv.visitLabel(l24);\r\n" + 
        "cv.visitVarInsn(ILOAD, 8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"size\", \"()I\");\r\n" + 
        "Label l25 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l25);\r\n" + 
        "Label l26 = new Label();\r\n" + 
        "cv.visitLabel(l26);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 8);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\", \"tableID\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "Label l27 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l27);\r\n" + 
        "Label l28 = new Label();\r\n" + 
        "cv.visitLabel(l28);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "Label l29 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l29);\r\n" + 
        "Label l30 = new Label();\r\n" + 
        "cv.visitLabel(l30);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Metadata has duplicate Htables!\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l29);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitVarInsn(ILOAD, 7);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/plugins/jpeg/JPEGHuffmanTable\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 8);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\", \"numCodes\", \"[S\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 8);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment$Htable\", \"values\", \"[S\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/plugins/jpeg/JPEGHuffmanTable\", \"<init>\", \"([S[S)V\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "cv.visitLabel(l27);\r\n" + 
        "cv.visitIincInsn(8, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l24);\r\n" + 
        "cv.visitLabel(l25);\r\n" + 
        "cv.visitIincInsn(7, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l21);\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(1279, l0);\r\n" + 
        "cv.visitLineNumber(1280, l1);\r\n" + 
        "cv.visitLineNumber(1281, l2);\r\n" + 
        "cv.visitLineNumber(1282, l4);\r\n" + 
        "cv.visitLineNumber(1283, l5);\r\n" + 
        "cv.visitLineNumber(1284, l6);\r\n" + 
        "cv.visitLineNumber(1286, l7);\r\n" + 
        "cv.visitLineNumber(1287, l9);\r\n" + 
        "cv.visitLineNumber(1289, l10);\r\n" + 
        "cv.visitLineNumber(1290, l14);\r\n" + 
        "cv.visitLineNumber(1286, l13);\r\n" + 
        "cv.visitLineNumber(1295, l3);\r\n" + 
        "cv.visitLineNumber(1296, l15);\r\n" + 
        "cv.visitLineNumber(1297, l17);\r\n" + 
        "cv.visitLineNumber(1299, l18);\r\n" + 
        "cv.visitLineNumber(1300, l19);\r\n" + 
        "cv.visitLineNumber(1301, l20);\r\n" + 
        "cv.visitLineNumber(1302, l22);\r\n" + 
        "cv.visitLineNumber(1303, l23);\r\n" + 
        "cv.visitLineNumber(1304, l26);\r\n" + 
        "cv.visitLineNumber(1305, l28);\r\n" + 
        "cv.visitLineNumber(1306, l30);\r\n" + 
        "cv.visitLineNumber(1308, l29);\r\n" + 
        "cv.visitLineNumber(1303, l27);\r\n" + 
        "cv.visitLineNumber(1301, l25);\r\n" + 
        "cv.visitLineNumber(1315, l16);\r\n" + 
        "cv.visitMaxs(7, 9);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"collectQTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;)[Ljavax/imageio/plugins/jpeg/JPEGQTable;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/util/ArrayList\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/util/ArrayList\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 2);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"markerSequence\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/List\", \"iterator\", \"()Ljava/util/Iterator;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 3);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/Iterator\", \"hasNext\", \"()Z\");\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/util/Iterator\", \"next\", \"()Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/MarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l2);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment\", \"tables\", \"Ljava/util/List;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"addAll\", \"(Ljava/util/Collection;)Z\");\r\n" + 
        "cv.visitInsn(POP);\r\n" + 
        "cv.visitJumpInsn(GOTO, l2);\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"size\", \"()I\");\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l9);\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"size\", \"()I\");\r\n" + 
        "cv.visitTypeInsn(ANEWARRAY, \"javax/imageio/plugins/jpeg/JPEGQTable\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 5);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitVarInsn(ILOAD, 5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l9);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitVarInsn(ILOAD, 5);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/plugins/jpeg/JPEGQTable\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ILOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/util/ArrayList\", \"get\", \"(I)Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment$Qtable\");\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment$Qtable\", \"data\", \"[I\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"<init>\", \"([I)V\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitIincInsn(5, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l12);\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(1249, l0);\r\n" + 
        "cv.visitLineNumber(1250, l1);\r\n" + 
        "cv.visitLineNumber(1251, l2);\r\n" + 
        "cv.visitLineNumber(1252, l4);\r\n" + 
        "cv.visitLineNumber(1253, l5);\r\n" + 
        "cv.visitLineNumber(1254, l6);\r\n" + 
        "cv.visitLineNumber(1256, l7);\r\n" + 
        "cv.visitLineNumber(1259, l3);\r\n" + 
        "cv.visitLineNumber(1260, l8);\r\n" + 
        "cv.visitLineNumber(1261, l10);\r\n" + 
        "cv.visitLineNumber(1262, l11);\r\n" + 
        "cv.visitLineNumber(1263, l13);\r\n" + 
        "cv.visitLineNumber(1262, l14);\r\n" + 
        "cv.visitLineNumber(1267, l9);\r\n" + 
        "cv.visitMaxs(6, 6);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_STATIC + ACC_NATIVE, \"initWriterIDs\", \"(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/Class;)V\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"write\", \"(Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/IIOImage;Ljavax/imageio/ImageWriteParam;)V\", new String[] { \"java/io/IOException\" }, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/IllegalStateException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Output has not been set!\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/IllegalStateException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/IIOImage\", \"hasRaster\", \"()Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 4);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l7);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/IIOImage\", \"getRaster\", \"()Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l9);\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/IIOImage\", \"getRenderedImage\", \"()Ljava/awt/image/RenderedImage;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"java/awt/image/BufferedImage\");\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l11);\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"java/awt/image/BufferedImage\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/BufferedImage\", \"getRaster\", \"()Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l9);\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/awt/image/RenderedImage\", \"getData\", \"()Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"getNumBands\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 6);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexCM\", \"Ljava/awt/image/IndexColorModel;\");\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 7);\r\n" + 
        "Label l16 = new Label();\r\n" + 
        "cv.visitLabel(l16);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 8);\r\n" + 
        "Label l17 = new Label();\r\n" + 
        "cv.visitLabel(l17);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l18 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l18);\r\n" + 
        "Label l19 = new Label();\r\n" + 
        "cv.visitLabel(l19);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/awt/image/RenderedImage\", \"getColorModel\", \"()Ljava/awt/image/ColorModel;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 7);\r\n" + 
        "Label l20 = new Label();\r\n" + 
        "cv.visitLabel(l20);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l18);\r\n" + 
        "Label l21 = new Label();\r\n" + 
        "cv.visitLabel(l21);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getColorSpace\", \"()Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 8);\r\n" + 
        "Label l22 = new Label();\r\n" + 
        "cv.visitLabel(l22);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"java/awt/image/IndexColorModel\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l18);\r\n" + 
        "Label l23 = new Label();\r\n" + 
        "cv.visitLabel(l23);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l24 = new Label();\r\n" + 
        "cv.visitLabel(l24);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"java/awt/image/IndexColorModel\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexCM\", \"Ljava/awt/image/IndexColorModel;\");\r\n" + 
        "Label l25 = new Label();\r\n" + 
        "cv.visitLabel(l25);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getNumComponents\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 6);\r\n" + 
        "cv.visitLabel(l18);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"bandOffsets\", \"[[I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcBands\", \"[I\");\r\n" + 
        "Label l26 = new Label();\r\n" + 
        "cv.visitLabel(l26);\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "cv.visitVarInsn(ISTORE, 9);\r\n" + 
        "Label l27 = new Label();\r\n" + 
        "cv.visitLabel(l27);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "Label l28 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l28);\r\n" + 
        "Label l29 = new Label();\r\n" + 
        "cv.visitLabel(l29);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getSourceBands\", \"()[I\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 10);\r\n" + 
        "Label l30 = new Label();\r\n" + 
        "cv.visitLabel(l30);\r\n" + 
        "cv.visitVarInsn(ALOAD, 10);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l28);\r\n" + 
        "Label l31 = new Label();\r\n" + 
        "cv.visitLabel(l31);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l32 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l32);\r\n" + 
        "Label l33 = new Label();\r\n" + 
        "cv.visitLabel(l33);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l28);\r\n" + 
        "cv.visitLabel(l32);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 10);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcBands\", \"[I\");\r\n" + 
        "Label l34 = new Label();\r\n" + 
        "cv.visitLabel(l34);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcBands\", \"[I\");\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "cv.visitVarInsn(ISTORE, 9);\r\n" + 
        "Label l35 = new Label();\r\n" + 
        "cv.visitLabel(l35);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPLE, l28);\r\n" + 
        "Label l36 = new Label();\r\n" + 
        "cv.visitLabel(l36);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"ImageWriteParam specifies too many source bands\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l28);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "Label l37 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l37);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l38 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l38);\r\n" + 
        "cv.visitLabel(l37);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitLabel(l38);\r\n" + 
        "cv.visitVarInsn(ISTORE, 10);\r\n" + 
        "Label l39 = new Label();\r\n" + 
        "cv.visitLabel(l39);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l40 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l40);\r\n" + 
        "cv.visitVarInsn(ILOAD, 10);\r\n" + 
        "cv.visitJumpInsn(IFNE, l40);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l41 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l41);\r\n" + 
        "cv.visitLabel(l40);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitLabel(l41);\r\n" + 
        "cv.visitVarInsn(ISTORE, 11);\r\n" + 
        "Label l42 = new Label();\r\n" + 
        "cv.visitLabel(l42);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 12);\r\n" + 
        "Label l43 = new Label();\r\n" + 
        "cv.visitLabel(l43);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l44 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l44);\r\n" + 
        "Label l45 = new Label();\r\n" + 
        "cv.visitLabel(l45);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"getSampleModel\", \"()Ljava/awt/image/SampleModel;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/SampleModel\", \"getSampleSize\", \"()[I\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 12);\r\n" + 
        "Label l46 = new Label();\r\n" + 
        "cv.visitLabel(l46);\r\n" + 
        "cv.visitVarInsn(ILOAD, 10);\r\n" + 
        "Label l47 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l47);\r\n" + 
        "Label l48 = new Label();\r\n" + 
        "cv.visitLabel(l48);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 13);\r\n" + 
        "Label l49 = new Label();\r\n" + 
        "cv.visitLabel(l49);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 14);\r\n" + 
        "Label l50 = new Label();\r\n" + 
        "cv.visitLabel(l50);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "Label l51 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l51);\r\n" + 
        "Label l52 = new Label();\r\n" + 
        "cv.visitLabel(l52);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcBands\", \"[I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitInsn(IALOAD);\r\n" + 
        "cv.visitInsn(IALOAD);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l53 = new Label();\r\n" + 
        "cv.visitLabel(l53);\r\n" + 
        "cv.visitIincInsn(14, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l50);\r\n" + 
        "cv.visitLabel(l51);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitVarInsn(ASTORE, 12);\r\n" + 
        "cv.visitJumpInsn(GOTO, l47);\r\n" + 
        "cv.visitLabel(l44);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"getSampleModel\", \"()Ljava/awt/image/SampleModel;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/SampleModel\", \"getSampleSize\", \"()[I\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 13);\r\n" + 
        "Label l54 = new Label();\r\n" + 
        "cv.visitLabel(l54);\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 12);\r\n" + 
        "Label l55 = new Label();\r\n" + 
        "cv.visitLabel(l55);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 14);\r\n" + 
        "Label l56 = new Label();\r\n" + 
        "cv.visitLabel(l56);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l47);\r\n" + 
        "Label l57 = new Label();\r\n" + 
        "cv.visitLabel(l57);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IALOAD);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l58 = new Label();\r\n" + 
        "cv.visitLabel(l58);\r\n" + 
        "cv.visitIincInsn(14, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l56);\r\n" + 
        "cv.visitLabel(l47);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 13);\r\n" + 
        "Label l59 = new Label();\r\n" + 
        "cv.visitLabel(l59);\r\n" + 
        "cv.visitVarInsn(ILOAD, 13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "Label l60 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l60);\r\n" + 
        "Label l61 = new Label();\r\n" + 
        "cv.visitLabel(l61);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitVarInsn(ILOAD, 13);\r\n" + 
        "cv.visitInsn(IALOAD);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 8);\r\n" + 
        "Label l62 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPLE, l62);\r\n" + 
        "Label l63 = new Label();\r\n" + 
        "cv.visitLabel(l63);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Sample size must be <= 8\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l62);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"indexed\", \"Z\");\r\n" + 
        "Label l64 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l64);\r\n" + 
        "Label l65 = new Label();\r\n" + 
        "cv.visitLabel(l65);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitVarInsn(ILOAD, 13);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 8);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "cv.visitLabel(l64);\r\n" + 
        "cv.visitIincInsn(13, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l59);\r\n" + 
        "cv.visitLabel(l60);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"debug\", \"Z\");\r\n" + 
        "Label l66 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l66);\r\n" + 
        "Label l67 = new Label();\r\n" + 
        "cv.visitLabel(l67);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"numSrcBands is \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(I)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l68 = new Label();\r\n" + 
        "cv.visitLabel(l68);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"numBandsUsed is \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(I)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l69 = new Label();\r\n" + 
        "cv.visitLabel(l69);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"usingBandSubset is \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 10);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Z)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l70 = new Label();\r\n" + 
        "cv.visitLabel(l70);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"fullImage is \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 11);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Z)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l71 = new Label();\r\n" + 
        "cv.visitLabel(l71);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitLdcInsn(\"Band sizes:\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"print\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l72 = new Label();\r\n" + 
        "cv.visitLabel(l72);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 13);\r\n" + 
        "Label l73 = new Label();\r\n" + 
        "cv.visitLabel(l73);\r\n" + 
        "cv.visitVarInsn(ILOAD, 13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitInsn(ARRAYLENGTH);\r\n" + 
        "Label l74 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l74);\r\n" + 
        "Label l75 = new Label();\r\n" + 
        "cv.visitLabel(l75);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\" \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitVarInsn(ILOAD, 13);\r\n" + 
        "cv.visitInsn(IALOAD);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(I)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"print\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l76 = new Label();\r\n" + 
        "cv.visitLabel(l76);\r\n" + 
        "cv.visitIincInsn(13, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l73);\r\n" + 
        "cv.visitLabel(l74);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"()V\");\r\n" + 
        "cv.visitLabel(l66);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 13);\r\n" + 
        "Label l77 = new Label();\r\n" + 
        "cv.visitLabel(l77);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "Label l78 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l78);\r\n" + 
        "Label l79 = new Label();\r\n" + 
        "cv.visitLabel(l79);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getDestinationType\", \"()Ljavax/imageio/ImageTypeSpecifier;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 13);\r\n" + 
        "Label l80 = new Label();\r\n" + 
        "cv.visitLabel(l80);\r\n" + 
        "cv.visitVarInsn(ILOAD, 11);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l78);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l78);\r\n" + 
        "Label l81 = new Label();\r\n" + 
        "cv.visitLabel(l81);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "Label l82 = new Label();\r\n" + 
        "cv.visitLabel(l82);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 13);\r\n" + 
        "cv.visitLabel(l78);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "Label l83 = new Label();\r\n" + 
        "cv.visitLabel(l83);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "Label l84 = new Label();\r\n" + 
        "cv.visitLabel(l84);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"getWidth\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 14);\r\n" + 
        "Label l85 = new Label();\r\n" + 
        "cv.visitLabel(l85);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"srcRas\", \"Ljava/awt/image/Raster;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/Raster\", \"getHeight\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 15);\r\n" + 
        "Label l86 = new Label();\r\n" + 
        "cv.visitLabel(l86);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "Label l87 = new Label();\r\n" + 
        "cv.visitLabel(l87);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 15);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "Label l88 = new Label();\r\n" + 
        "cv.visitLabel(l88);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 16);\r\n" + 
        "Label l89 = new Label();\r\n" + 
        "cv.visitLabel(l89);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 17);\r\n" + 
        "Label l90 = new Label();\r\n" + 
        "cv.visitLabel(l90);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 18);\r\n" + 
        "Label l91 = new Label();\r\n" + 
        "cv.visitLabel(l91);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 19);\r\n" + 
        "Label l92 = new Label();\r\n" + 
        "cv.visitLabel(l92);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "Label l93 = new Label();\r\n" + 
        "cv.visitLabel(l93);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 21);\r\n" + 
        "Label l94 = new Label();\r\n" + 
        "cv.visitLabel(l94);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 22);\r\n" + 
        "Label l95 = new Label();\r\n" + 
        "cv.visitLabel(l95);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 23);\r\n" + 
        "Label l96 = new Label();\r\n" + 
        "cv.visitLabel(l96);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 24);\r\n" + 
        "Label l97 = new Label();\r\n" + 
        "cv.visitLabel(l97);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 25);\r\n" + 
        "Label l98 = new Label();\r\n" + 
        "cv.visitLabel(l98);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "Label l99 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l99);\r\n" + 
        "Label l100 = new Label();\r\n" + 
        "cv.visitLabel(l100);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getSourceRegion\", \"()Ljava/awt/Rectangle;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 26);\r\n" + 
        "Label l101 = new Label();\r\n" + 
        "cv.visitLabel(l101);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "Label l102 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l102);\r\n" + 
        "Label l103 = new Label();\r\n" + 
        "cv.visitLabel(l103);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"java/awt/Rectangle\", \"x\", \"I\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "Label l104 = new Label();\r\n" + 
        "cv.visitLabel(l104);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"java/awt/Rectangle\", \"y\", \"I\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "Label l105 = new Label();\r\n" + 
        "cv.visitLabel(l105);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"java/awt/Rectangle\", \"width\", \"I\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "Label l106 = new Label();\r\n" + 
        "cv.visitLabel(l106);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"java/awt/Rectangle\", \"height\", \"I\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "cv.visitLabel(l102);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "Label l107 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPLE, l107);\r\n" + 
        "Label l108 = new Label();\r\n" + 
        "cv.visitLabel(l108);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 14);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitLabel(l107);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitVarInsn(ILOAD, 15);\r\n" + 
        "Label l109 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPLE, l109);\r\n" + 
        "Label l110 = new Label();\r\n" + 
        "cv.visitLabel(l110);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 15);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "cv.visitLabel(l109);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getSourceXSubsampling\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 16);\r\n" + 
        "Label l111 = new Label();\r\n" + 
        "cv.visitLabel(l111);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getSourceYSubsampling\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 17);\r\n" + 
        "Label l112 = new Label();\r\n" + 
        "cv.visitLabel(l112);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getSubsamplingXOffset\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 18);\r\n" + 
        "Label l113 = new Label();\r\n" + 
        "cv.visitLabel(l113);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getSubsamplingYOffset\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 19);\r\n" + 
        "Label l114 = new Label();\r\n" + 
        "cv.visitLabel(l114);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getCompressionMode\", \"()I\");\r\n" + 
        "Label l115 = new Label();\r\n" + 
        "Label l116 = new Label();\r\n" + 
        "Label l117 = new Label();\r\n" + 
        "Label l118 = new Label();\r\n" + 
        "cv.visitTableSwitchInsn(0, 2, l118, new Label[] { l115, l116, l117 });\r\n" + 
        "cv.visitLabel(l115);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"JPEG compression cannot be disabled\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l117);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getCompressionQuality\", \"()F\");\r\n" + 
        "cv.visitVarInsn(FSTORE, 27);\r\n" + 
        "Label l119 = new Label();\r\n" + 
        "cv.visitLabel(l119);\r\n" + 
        "cv.visitVarInsn(FLOAD, 27);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"convertToLinearQuality\", \"(F)F\");\r\n" + 
        "cv.visitVarInsn(FSTORE, 27);\r\n" + 
        "Label l120 = new Label();\r\n" + 
        "cv.visitLabel(l120);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitTypeInsn(ANEWARRAY, \"javax/imageio/plugins/jpeg/JPEGQTable\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "Label l121 = new Label();\r\n" + 
        "cv.visitLabel(l121);\r\n" + 
        "cv.visitVarInsn(ALOAD, 20);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"K1Luminance\", \"Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(FLOAD, 27);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"getScaledInstance\", \"(FZ)Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "Label l122 = new Label();\r\n" + 
        "cv.visitLabel(l122);\r\n" + 
        "cv.visitVarInsn(ALOAD, 20);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"K2Chrominance\", \"Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(FLOAD, 27);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"getScaledInstance\", \"(FZ)Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "Label l123 = new Label();\r\n" + 
        "cv.visitLabel(l123);\r\n" + 
        "cv.visitJumpInsn(GOTO, l118);\r\n" + 
        "cv.visitLabel(l116);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitTypeInsn(ANEWARRAY, \"javax/imageio/plugins/jpeg/JPEGQTable\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "Label l124 = new Label();\r\n" + 
        "cv.visitLabel(l124);\r\n" + 
        "cv.visitVarInsn(ALOAD, 20);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"K1Div2Luminance\", \"Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "Label l125 = new Label();\r\n" + 
        "cv.visitLabel(l125);\r\n" + 
        "cv.visitVarInsn(ALOAD, 20);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"javax/imageio/plugins/jpeg/JPEGQTable\", \"K2Div2Chrominance\", \"Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitInsn(AASTORE);\r\n" + 
        "cv.visitLabel(l118);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageWriteParam\", \"getProgressiveMode\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 25);\r\n" + 
        "Label l126 = new Label();\r\n" + 
        "cv.visitLabel(l126);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l99);\r\n" + 
        "Label l127 = new Label();\r\n" + 
        "cv.visitLabel(l127);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 24);\r\n" + 
        "Label l128 = new Label();\r\n" + 
        "cv.visitLabel(l128);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"getOptimizeHuffmanTables\", \"()Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 23);\r\n" + 
        "cv.visitLabel(l99);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/IIOImage\", \"getMetadata\", \"()Ljavax/imageio/metadata/IIOMetadata;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 26);\r\n" + 
        "Label l129 = new Label();\r\n" + 
        "cv.visitLabel(l129);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "Label l130 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l130);\r\n" + 
        "Label l131 = new Label();\r\n" + 
        "cv.visitLabel(l131);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "Label l132 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l132);\r\n" + 
        "Label l133 = new Label();\r\n" + 
        "cv.visitLabel(l133);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l134 = new Label();\r\n" + 
        "cv.visitLabel(l134);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"debug\", \"Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l130);\r\n" + 
        "Label l135 = new Label();\r\n" + 
        "cv.visitLabel(l135);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitLdcInsn(\"We have metadata, and it\'s JPEG metadata\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l130);\r\n" + 
        "cv.visitLabel(l132);\r\n" + 
        "cv.visitVarInsn(ILOAD, 4);\r\n" + 
        "Label l136 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l136);\r\n" + 
        "Label l137 = new Label();\r\n" + 
        "cv.visitLabel(l137);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitVarInsn(ASTORE, 27);\r\n" + 
        "Label l138 = new Label();\r\n" + 
        "cv.visitLabel(l138);\r\n" + 
        "cv.visitVarInsn(ALOAD, 27);\r\n" + 
        "Label l139 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l139);\r\n" + 
        "Label l140 = new Label();\r\n" + 
        "cv.visitLabel(l140);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/ImageTypeSpecifier\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageTypeSpecifier\", \"<init>\", \"(Ljava/awt/image/RenderedImage;)V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 27);\r\n" + 
        "cv.visitLabel(l139);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 26);\r\n" + 
        "cv.visitVarInsn(ALOAD, 27);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertImageMetadata\", \"(Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;)Ljavax/imageio/metadata/IIOMetadata;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l130);\r\n" + 
        "cv.visitLabel(l136);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l130);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "Label l141 = new Label();\r\n" + 
        "cv.visitLabel(l141);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreAdobe\", \"Z\");\r\n" + 
        "Label l142 = new Label();\r\n" + 
        "cv.visitLabel(l142);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_M1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l143 = new Label();\r\n" + 
        "cv.visitLabel(l143);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeDefaultJFIF\", \"Z\");\r\n" + 
        "Label l144 = new Label();\r\n" + 
        "cv.visitLabel(l144);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeAdobe\", \"Z\");\r\n" + 
        "Label l145 = new Label();\r\n" + 
        "cv.visitLabel(l145);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 27);\r\n" + 
        "Label l146 = new Label();\r\n" + 
        "cv.visitLabel(l146);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l147 = new Label();\r\n" + 
        "cv.visitLabel(l147);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 29);\r\n" + 
        "Label l148 = new Label();\r\n" + 
        "cv.visitLabel(l148);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 30);\r\n" + 
        "Label l149 = new Label();\r\n" + 
        "cv.visitLabel(l149);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 31);\r\n" + 
        "Label l150 = new Label();\r\n" + 
        "cv.visitLabel(l150);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l151 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l151);\r\n" + 
        "Label l152 = new Label();\r\n" + 
        "cv.visitLabel(l152);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l153 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l153);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.JFIFMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l154 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l154);\r\n" + 
        "cv.visitLabel(l153);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l154);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JFIFMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 29);\r\n" + 
        "Label l155 = new Label();\r\n" + 
        "cv.visitLabel(l155);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$AdobeMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l156 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l156);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.AdobeMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$AdobeMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l157 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l157);\r\n" + 
        "cv.visitLabel(l156);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$AdobeMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l157);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 30);\r\n" + 
        "Label l158 = new Label();\r\n" + 
        "cv.visitLabel(l158);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l159 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l159);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.SOFMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l160 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l160);\r\n" + 
        "cv.visitLabel(l159);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l160);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 31);\r\n" + 
        "cv.visitLabel(l151);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "Label l161 = new Label();\r\n" + 
        "cv.visitLabel(l161);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertTosRGB\", \"Z\");\r\n" + 
        "Label l162 = new Label();\r\n" + 
        "cv.visitLabel(l162);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"converted\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l163 = new Label();\r\n" + 
        "cv.visitLabel(l163);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "Label l164 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l164);\r\n" + 
        "Label l165 = new Label();\r\n" + 
        "cv.visitLabel(l165);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageTypeSpecifier\", \"getNumBands\", \"()I\");\r\n" + 
        "Label l166 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l166);\r\n" + 
        "Label l167 = new Label();\r\n" + 
        "cv.visitLabel(l167);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/IIOException\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitLdcInsn(\"Number of source bands != number of destination bands\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/IIOException\", \"<init>\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitInsn(ATHROW);\r\n" + 
        "cv.visitLabel(l166);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/ImageTypeSpecifier\", \"getColorModel\", \"()Ljava/awt/image/ColorModel;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getColorSpace\", \"()Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 8);\r\n" + 
        "Label l168 = new Label();\r\n" + 
        "cv.visitLabel(l168);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l169 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l169);\r\n" + 
        "Label l170 = new Label();\r\n" + 
        "cv.visitLabel(l170);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"checkSOFBands\", \"(Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment;I)V\");\r\n" + 
        "Label l171 = new Label();\r\n" + 
        "cv.visitLabel(l171);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"checkJFIF\", \"(Lcom/sun/imageio/plugins/jpeg/JFIFMarkerSegment;Ljavax/imageio/ImageTypeSpecifier;Z)V\");\r\n" + 
        "Label l172 = new Label();\r\n" + 
        "cv.visitLabel(l172);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "Label l173 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l173);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "cv.visitJumpInsn(IFNE, l173);\r\n" + 
        "Label l174 = new Label();\r\n" + 
        "cv.visitLabel(l174);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isNonStandardICC\", \"(Ljava/awt/color/ColorSpace;)Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l173);\r\n" + 
        "Label l175 = new Label();\r\n" + 
        "cv.visitLabel(l175);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"java/awt/color/ICC_ColorSpace\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ICC_ColorSpace\", \"getProfile\", \"()Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitLabel(l173);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"checkAdobe\", \"(Lcom/sun/imageio/plugins/jpeg/AdobeMarkerSegment;Ljavax/imageio/ImageTypeSpecifier;Z)V\");\r\n" + 
        "Label l176 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l169);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isJFIFcompliant\", \"(Ljavax/imageio/ImageTypeSpecifier;Z)Z\");\r\n" + 
        "Label l177 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l177);\r\n" + 
        "Label l178 = new Label();\r\n" + 
        "cv.visitLabel(l178);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeDefaultJFIF\", \"Z\");\r\n" + 
        "Label l179 = new Label();\r\n" + 
        "cv.visitLabel(l179);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isNonStandardICC\", \"(Ljava/awt/color/ColorSpace;)Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l176);\r\n" + 
        "Label l180 = new Label();\r\n" + 
        "cv.visitLabel(l180);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"java/awt/color/ICC_ColorSpace\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ICC_ColorSpace\", \"getProfile\", \"()Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l177);\r\n" + 
        "cv.visitVarInsn(ALOAD, 13);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"transformForType\", \"(Ljavax/imageio/ImageTypeSpecifier;Z)I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 32);\r\n" + 
        "Label l181 = new Label();\r\n" + 
        "cv.visitLabel(l181);\r\n" + 
        "cv.visitVarInsn(ILOAD, 32);\r\n" + 
        "cv.visitInsn(ICONST_M1);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l176);\r\n" + 
        "Label l182 = new Label();\r\n" + 
        "cv.visitLabel(l182);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeAdobe\", \"Z\");\r\n" + 
        "Label l183 = new Label();\r\n" + 
        "cv.visitLabel(l183);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ILOAD, 32);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l164);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l184 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l184);\r\n" + 
        "Label l185 = new Label();\r\n" + 
        "cv.visitLabel(l185);\r\n" + 
        "cv.visitVarInsn(ILOAD, 11);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l176);\r\n" + 
        "Label l186 = new Label();\r\n" + 
        "cv.visitLabel(l186);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/ImageTypeSpecifier\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageTypeSpecifier\", \"<init>\", \"(Ljava/awt/image/RenderedImage;)V\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"<init>\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Lcom/sun/imageio/plugins/jpeg/JPEGImageWriter;)V\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l187 = new Label();\r\n" + 
        "cv.visitLabel(l187);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l188 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l188);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.JFIFMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l189 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l189);\r\n" + 
        "cv.visitLabel(l188);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l189);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "Label l190 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l190);\r\n" + 
        "Label l191 = new Label();\r\n" + 
        "cv.visitLabel(l191);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"java/awt/image/RenderedImage\", \"getColorModel\", \"()Ljava/awt/image/ColorModel;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"getColorSpace\", \"()Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 8);\r\n" + 
        "Label l192 = new Label();\r\n" + 
        "cv.visitLabel(l192);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isNonStandardICC\", \"(Ljava/awt/color/ColorSpace;)Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l190);\r\n" + 
        "Label l193 = new Label();\r\n" + 
        "cv.visitLabel(l193);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"java/awt/color/ICC_ColorSpace\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ICC_ColorSpace\", \"getProfile\", \"()Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitLabel(l190);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"getSrcCSType\", \"(Ljava/awt/image/RenderedImage;)I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 27);\r\n" + 
        "Label l194 = new Label();\r\n" + 
        "cv.visitLabel(l194);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"getDefaultDestCSType\", \"(Ljava/awt/image/RenderedImage;)I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l184);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"checkSOFBands\", \"(Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment;I)V\");\r\n" + 
        "Label l195 = new Label();\r\n" + 
        "cv.visitLabel(l195);\r\n" + 
        "cv.visitVarInsn(ILOAD, 11);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l176);\r\n" + 
        "Label l196 = new Label();\r\n" + 
        "cv.visitLabel(l196);\r\n" + 
        "cv.visitTypeInsn(NEW, \"javax/imageio/ImageTypeSpecifier\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"javax/imageio/ImageTypeSpecifier\", \"<init>\", \"(Ljava/awt/image/RenderedImage;)V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 32);\r\n" + 
        "Label l197 = new Label();\r\n" + 
        "cv.visitLabel(l197);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"getSrcCSType\", \"(Ljava/awt/image/RenderedImage;)I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 27);\r\n" + 
        "Label l198 = new Label();\r\n" + 
        "cv.visitLabel(l198);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l176);\r\n" + 
        "Label l199 = new Label();\r\n" + 
        "cv.visitLabel(l199);\r\n" + 
        "cv.visitVarInsn(ALOAD, 7);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/ColorModel\", \"hasAlpha\", \"()Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 33);\r\n" + 
        "Label l200 = new Label();\r\n" + 
        "cv.visitLabel(l200);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ColorSpace\", \"getType\", \"()I\");\r\n" + 
        "Label l201 = new Label();\r\n" + 
        "Label l202 = new Label();\r\n" + 
        "Label l203 = new Label();\r\n" + 
        "cv.visitLookupSwitchInsn(l176, new int[] { 5, 6, 13 }, new Label[] { l201, l202, l203 });\r\n" + 
        "cv.visitLabel(l202);\r\n" + 
        "cv.visitVarInsn(ILOAD, 33);\r\n" + 
        "Label l204 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l204);\r\n" + 
        "Label l205 = new Label();\r\n" + 
        "cv.visitLabel(l205);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l206 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l206);\r\n" + 
        "cv.visitLabel(l204);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l206);\r\n" + 
        "Label l207 = new Label();\r\n" + 
        "cv.visitLabel(l207);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "Label l208 = new Label();\r\n" + 
        "cv.visitLabel(l208);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l206);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l176);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"transform\", \"I\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l176);\r\n" + 
        "Label l209 = new Label();\r\n" + 
        "cv.visitLabel(l209);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l210 = new Label();\r\n" + 
        "cv.visitLabel(l210);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l201);\r\n" + 
        "cv.visitVarInsn(ILOAD, 33);\r\n" + 
        "Label l211 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l211);\r\n" + 
        "Label l212 = new Label();\r\n" + 
        "cv.visitLabel(l212);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "Label l213 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l213);\r\n" + 
        "Label l214 = new Label();\r\n" + 
        "cv.visitLabel(l214);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l215 = new Label();\r\n" + 
        "cv.visitLabel(l215);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isNonStandardICC\", \"(Ljava/awt/color/ColorSpace;)Z\");\r\n" + 
        "Label l216 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l216);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"java/awt/color/ICC_ColorSpace\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l176);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JFIFMarkerSegment\", \"iccSegment\", \"Lcom/sun/imageio/plugins/jpeg/JFIFMarkerSegment$ICCMarkerSegment;\");\r\n" + 
        "cv.visitJumpInsn(IFNULL, l176);\r\n" + 
        "cv.visitLabel(l216);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"java/awt/color/ICC_ColorSpace\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/color/ICC_ColorSpace\", \"getProfile\", \"()Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"iccProfile\", \"Ljava/awt/color/ICC_Profile;\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l213);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "Label l217 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l217);\r\n" + 
        "Label l218 = new Label();\r\n" + 
        "cv.visitLabel(l218);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"transform\", \"I\");\r\n" + 
        "Label l219 = new Label();\r\n" + 
        "Label l220 = new Label();\r\n" + 
        "Label l221 = new Label();\r\n" + 
        "cv.visitLookupSwitchInsn(l221, new int[] { 0, 1 }, new Label[] { l219, l220 });\r\n" + 
        "cv.visitLabel(l219);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l222 = new Label();\r\n" + 
        "cv.visitLabel(l222);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l220);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l223 = new Label();\r\n" + 
        "cv.visitLabel(l223);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l221);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "Label l224 = new Label();\r\n" + 
        "cv.visitLabel(l224);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l225 = new Label();\r\n" + 
        "cv.visitLabel(l225);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l226 = new Label();\r\n" + 
        "cv.visitLabel(l226);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l217);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"getIDencodedCSType\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 34);\r\n" + 
        "Label l227 = new Label();\r\n" + 
        "cv.visitLabel(l227);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "Label l228 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l228);\r\n" + 
        "Label l229 = new Label();\r\n" + 
        "cv.visitLabel(l229);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l228);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"isSubsampled\", \"([Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;)Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 35);\r\n" + 
        "Label l230 = new Label();\r\n" + 
        "cv.visitLabel(l230);\r\n" + 
        "cv.visitVarInsn(ILOAD, 35);\r\n" + 
        "Label l231 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l231);\r\n" + 
        "Label l232 = new Label();\r\n" + 
        "cv.visitLabel(l232);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l231);\r\n" + 
        "cv.visitInsn(ICONST_2);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l211);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "Label l233 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l233);\r\n" + 
        "Label l234 = new Label();\r\n" + 
        "cv.visitLabel(l234);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "Label l235 = new Label();\r\n" + 
        "cv.visitLabel(l235);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l233);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "Label l236 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l236);\r\n" + 
        "Label l237 = new Label();\r\n" + 
        "cv.visitLabel(l237);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"transform\", \"I\");\r\n" + 
        "Label l238 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l238);\r\n" + 
        "Label l239 = new Label();\r\n" + 
        "cv.visitLabel(l239);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l240 = new Label();\r\n" + 
        "cv.visitLabel(l240);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l238);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l236);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"getIDencodedCSType\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 34);\r\n" + 
        "Label l241 = new Label();\r\n" + 
        "cv.visitLabel(l241);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "Label l242 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l242);\r\n" + 
        "Label l243 = new Label();\r\n" + 
        "cv.visitLabel(l243);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l242);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"isSubsampled\", \"([Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;)Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 35);\r\n" + 
        "Label l244 = new Label();\r\n" + 
        "cv.visitLabel(l244);\r\n" + 
        "cv.visitVarInsn(ILOAD, 35);\r\n" + 
        "Label l245 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l245);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 7);\r\n" + 
        "Label l246 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l246);\r\n" + 
        "cv.visitLabel(l245);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitLabel(l246);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "Label l247 = new Label();\r\n" + 
        "cv.visitLabel(l247);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l203);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"YCC\", \"Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitJumpInsn(IF_ACMPNE, l176);\r\n" + 
        "Label l248 = new Label();\r\n" + 
        "cv.visitLabel(l248);\r\n" + 
        "cv.visitVarInsn(ILOAD, 33);\r\n" + 
        "Label l249 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l249);\r\n" + 
        "Label l250 = new Label();\r\n" + 
        "cv.visitLabel(l250);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "Label l251 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l251);\r\n" + 
        "Label l252 = new Label();\r\n" + 
        "cv.visitLabel(l252);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertTosRGB\", \"Z\");\r\n" + 
        "Label l253 = new Label();\r\n" + 
        "cv.visitLabel(l253);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/awt/image/ColorConvertOp\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 8);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"sRGB\", \"Ljava/awt/color/ColorSpace;\");\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/awt/image/ColorConvertOp\", \"<init>\", \"(Ljava/awt/color/ColorSpace;Ljava/awt/color/ColorSpace;Ljava/awt/RenderingHints;)V\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertOp\", \"Ljava/awt/image/ColorConvertOp;\");\r\n" + 
        "Label l254 = new Label();\r\n" + 
        "cv.visitLabel(l254);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l251);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "Label l255 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l255);\r\n" + 
        "Label l256 = new Label();\r\n" + 
        "cv.visitLabel(l256);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"transform\", \"I\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l257 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l257);\r\n" + 
        "Label l258 = new Label();\r\n" + 
        "cv.visitLabel(l258);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l259 = new Label();\r\n" + 
        "cv.visitLabel(l259);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l257);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l255);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitJumpInsn(GOTO, l176);\r\n" + 
        "cv.visitLabel(l249);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "Label l260 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l260);\r\n" + 
        "Label l261 = new Label();\r\n" + 
        "cv.visitLabel(l261);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ignoreJFIF\", \"Z\");\r\n" + 
        "Label l262 = new Label();\r\n" + 
        "cv.visitLabel(l262);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "Label l263 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l263);\r\n" + 
        "cv.visitLabel(l260);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l263);\r\n" + 
        "Label l264 = new Label();\r\n" + 
        "cv.visitLabel(l264);\r\n" + 
        "cv.visitVarInsn(ALOAD, 30);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/AdobeMarkerSegment\", \"transform\", \"I\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l263);\r\n" + 
        "Label l265 = new Label();\r\n" + 
        "cv.visitLabel(l265);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"newAdobeTransform\", \"I\");\r\n" + 
        "Label l266 = new Label();\r\n" + 
        "cv.visitLabel(l266);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 6);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l263);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitVarInsn(ISTORE, 28);\r\n" + 
        "cv.visitLabel(l176);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 32);\r\n" + 
        "Label l267 = new Label();\r\n" + 
        "cv.visitLabel(l267);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 33);\r\n" + 
        "Label l268 = new Label();\r\n" + 
        "cv.visitLabel(l268);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l269 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l269);\r\n" + 
        "Label l270 = new Label();\r\n" + 
        "cv.visitLabel(l270);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "Label l271 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l271);\r\n" + 
        "Label l272 = new Label();\r\n" + 
        "cv.visitLabel(l272);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l273 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l273);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.SOFMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l274 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l274);\r\n" + 
        "cv.visitLabel(l273);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$SOFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l274);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 31);\r\n" + 
        "cv.visitLabel(l271);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "Label l275 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l275);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"tag\", \"I\");\r\n" + 
        "cv.visitIntInsn(SIPUSH, 194);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l275);\r\n" + 
        "Label l276 = new Label();\r\n" + 
        "cv.visitLabel(l276);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 32);\r\n" + 
        "Label l277 = new Label();\r\n" + 
        "cv.visitLabel(l277);\r\n" + 
        "cv.visitVarInsn(ILOAD, 25);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "Label l278 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l278);\r\n" + 
        "Label l279 = new Label();\r\n" + 
        "cv.visitLabel(l279);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectScans\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment;)[I\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 33);\r\n" + 
        "cv.visitJumpInsn(GOTO, l275);\r\n" + 
        "cv.visitLabel(l278);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "cv.visitLabel(l275);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l269);\r\n" + 
        "Label l280 = new Label();\r\n" + 
        "cv.visitLabel(l280);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l281 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l281);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.JFIFMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l282 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l282);\r\n" + 
        "cv.visitLabel(l281);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l282);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JFIFMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 29);\r\n" + 
        "cv.visitLabel(l269);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/IIOImage\", \"getThumbnails\", \"()Ljava/util/List;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "Label l283 = new Label();\r\n" + 
        "cv.visitLabel(l283);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/IIOImage\", \"getNumThumbnails\", \"()I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 34);\r\n" + 
        "Label l284 = new Label();\r\n" + 
        "cv.visitLabel(l284);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"forceJFIF\", \"Z\");\r\n" + 
        "Label l285 = new Label();\r\n" + 
        "cv.visitLabel(l285);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeDefaultJFIF\", \"Z\");\r\n" + 
        "Label l286 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l286);\r\n" + 
        "Label l287 = new Label();\r\n" + 
        "cv.visitLabel(l287);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l288 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l288);\r\n" + 
        "Label l289 = new Label();\r\n" + 
        "cv.visitLabel(l289);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "Label l290 = new Label();\r\n" + 
        "cv.visitLabel(l290);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l286);\r\n" + 
        "Label l291 = new Label();\r\n" + 
        "cv.visitLabel(l291);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l286);\r\n" + 
        "cv.visitLabel(l288);\r\n" + 
        "cv.visitVarInsn(ILOAD, 11);\r\n" + 
        "Label l292 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l292);\r\n" + 
        "Label l293 = new Label();\r\n" + 
        "cv.visitLabel(l293);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l286);\r\n" + 
        "Label l294 = new Label();\r\n" + 
        "cv.visitLabel(l294);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "Label l295 = new Label();\r\n" + 
        "cv.visitLabel(l295);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l286);\r\n" + 
        "Label l296 = new Label();\r\n" + 
        "cv.visitLabel(l296);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l286);\r\n" + 
        "cv.visitLabel(l292);\r\n" + 
        "cv.visitVarInsn(ALOAD, 29);\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l286);\r\n" + 
        "Label l297 = new Label();\r\n" + 
        "cv.visitLabel(l297);\r\n" + 
        "cv.visitVarInsn(ILOAD, 28);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l298 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPEQ, l298);\r\n" + 
        "cv.visitVarInsn(ILOAD, 28);\r\n" + 
        "cv.visitInsn(ICONST_3);\r\n" + 
        "Label l299 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPNE, l299);\r\n" + 
        "cv.visitLabel(l298);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l286);\r\n" + 
        "Label l300 = new Label();\r\n" + 
        "cv.visitLabel(l300);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"forceJFIF\", \"Z\");\r\n" + 
        "Label l301 = new Label();\r\n" + 
        "cv.visitLabel(l301);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 11);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitJumpInsn(GOTO, l286);\r\n" + 
        "cv.visitLabel(l299);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"thumbnails\", \"Ljava/util/List;\");\r\n" + 
        "Label l302 = new Label();\r\n" + 
        "cv.visitLabel(l302);\r\n" + 
        "cv.visitVarInsn(ILOAD, 34);\r\n" + 
        "cv.visitJumpInsn(IFEQ, l286);\r\n" + 
        "Label l303 = new Label();\r\n" + 
        "cv.visitLabel(l303);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitIntInsn(BIPUSH, 10);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"warningOccurred\", \"(I)V\");\r\n" + 
        "cv.visitLabel(l286);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l304 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l304);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeDefaultJFIF\", \"Z\");\r\n" + 
        "cv.visitJumpInsn(IFNE, l304);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeAdobe\", \"Z\");\r\n" + 
        "Label l305 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l305);\r\n" + 
        "cv.visitLabel(l304);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l306 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l306);\r\n" + 
        "cv.visitLabel(l305);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitLabel(l306);\r\n" + 
        "cv.visitVarInsn(ISTORE, 35);\r\n" + 
        "Label l307 = new Label();\r\n" + 
        "cv.visitLabel(l307);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 36);\r\n" + 
        "Label l308 = new Label();\r\n" + 
        "cv.visitLabel(l308);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ISTORE, 37);\r\n" + 
        "Label l309 = new Label();\r\n" + 
        "cv.visitLabel(l309);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 38);\r\n" + 
        "Label l310 = new Label();\r\n" + 
        "cv.visitLabel(l310);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 39);\r\n" + 
        "Label l311 = new Label();\r\n" + 
        "cv.visitLabel(l311);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 40);\r\n" + 
        "Label l312 = new Label();\r\n" + 
        "cv.visitLabel(l312);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "Label l313 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l313);\r\n" + 
        "Label l314 = new Label();\r\n" + 
        "cv.visitLabel(l314);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DQTMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l315 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l315);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.DQTMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DQTMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l316 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l316);\r\n" + 
        "cv.visitLabel(l315);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DQTMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l316);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DQTMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 38);\r\n" + 
        "Label l317 = new Label();\r\n" + 
        "cv.visitLabel(l317);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DHTMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l318 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l318);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.DHTMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DHTMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l319 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l319);\r\n" + 
        "cv.visitLabel(l318);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DHTMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l319);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DHTMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 39);\r\n" + 
        "Label l320 = new Label();\r\n" + 
        "cv.visitLabel(l320);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DRIMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l321 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l321);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.DRIMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DRIMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l322 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l322);\r\n" + 
        "cv.visitLabel(l321);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$DRIMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l322);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/DRIMarkerSegment\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 41);\r\n" + 
        "Label l323 = new Label();\r\n" + 
        "cv.visitLabel(l323);\r\n" + 
        "cv.visitVarInsn(ALOAD, 41);\r\n" + 
        "Label l324 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l324);\r\n" + 
        "Label l325 = new Label();\r\n" + 
        "cv.visitLabel(l325);\r\n" + 
        "cv.visitVarInsn(ALOAD, 41);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/DRIMarkerSegment\", \"restartInterval\", \"I\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 40);\r\n" + 
        "cv.visitLabel(l324);\r\n" + 
        "cv.visitVarInsn(ALOAD, 38);\r\n" + 
        "Label l326 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l326);\r\n" + 
        "Label l327 = new Label();\r\n" + 
        "cv.visitLabel(l327);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 36);\r\n" + 
        "cv.visitLabel(l326);\r\n" + 
        "cv.visitVarInsn(ALOAD, 39);\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l313);\r\n" + 
        "Label l328 = new Label();\r\n" + 
        "cv.visitLabel(l328);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 37);\r\n" + 
        "cv.visitLabel(l313);\r\n" + 
        "cv.visitVarInsn(ALOAD, 20);\r\n" + 
        "Label l329 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l329);\r\n" + 
        "Label l330 = new Label();\r\n" + 
        "cv.visitLabel(l330);\r\n" + 
        "cv.visitVarInsn(ALOAD, 38);\r\n" + 
        "Label l331 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l331);\r\n" + 
        "Label l332 = new Label();\r\n" + 
        "cv.visitLabel(l332);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectQTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;)[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "cv.visitJumpInsn(GOTO, l329);\r\n" + 
        "cv.visitLabel(l331);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "Label l333 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l333);\r\n" + 
        "Label l334 = new Label();\r\n" + 
        "cv.visitLabel(l334);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamQTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "cv.visitJumpInsn(GOTO, l329);\r\n" + 
        "cv.visitLabel(l333);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "Label l335 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l335);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"areTablesSet\", \"()Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l335);\r\n" + 
        "Label l336 = new Label();\r\n" + 
        "cv.visitLabel(l336);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"getQTables\", \"()[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "cv.visitJumpInsn(GOTO, l329);\r\n" + 
        "cv.visitLabel(l335);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"getDefaultQTables\", \"()[Ljavax/imageio/plugins/jpeg/JPEGQTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 20);\r\n" + 
        "cv.visitLabel(l329);\r\n" + 
        "cv.visitVarInsn(ILOAD, 23);\r\n" + 
        "Label l337 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l337);\r\n" + 
        "Label l338 = new Label();\r\n" + 
        "cv.visitLabel(l338);\r\n" + 
        "cv.visitVarInsn(ALOAD, 39);\r\n" + 
        "Label l339 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l339);\r\n" + 
        "cv.visitVarInsn(ILOAD, 32);\r\n" + 
        "cv.visitJumpInsn(IFNE, l339);\r\n" + 
        "Label l340 = new Label();\r\n" + 
        "cv.visitLabel(l340);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectHTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 21);\r\n" + 
        "Label l341 = new Label();\r\n" + 
        "cv.visitLabel(l341);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"metadata\", \"Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;\");\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"collectHTablesFromMetadata\", \"(Lcom/sun/imageio/plugins/jpeg/JPEGMetadata;Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 22);\r\n" + 
        "cv.visitJumpInsn(GOTO, l337);\r\n" + 
        "cv.visitLabel(l339);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "Label l342 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l342);\r\n" + 
        "Label l343 = new Label();\r\n" + 
        "cv.visitLabel(l343);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamDCHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 21);\r\n" + 
        "Label l344 = new Label();\r\n" + 
        "cv.visitLabel(l344);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"streamACHuffmanTables\", \"[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 22);\r\n" + 
        "cv.visitJumpInsn(GOTO, l337);\r\n" + 
        "cv.visitLabel(l342);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "Label l345 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l345);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"areTablesSet\", \"()Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l345);\r\n" + 
        "Label l346 = new Label();\r\n" + 
        "cv.visitLabel(l346);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"getDCHuffmanTables\", \"()[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 21);\r\n" + 
        "Label l347 = new Label();\r\n" + 
        "cv.visitLabel(l347);\r\n" + 
        "cv.visitVarInsn(ALOAD, 24);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/plugins/jpeg/JPEGImageWriteParam\", \"getACHuffmanTables\", \"()[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 22);\r\n" + 
        "cv.visitJumpInsn(GOTO, l337);\r\n" + 
        "cv.visitLabel(l345);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"getDefaultHuffmanTables\", \"(Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 21);\r\n" + 
        "Label l348 = new Label();\r\n" + 
        "cv.visitLabel(l348);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"getDefaultHuffmanTables\", \"(Z)[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 22);\r\n" + 
        "cv.visitLabel(l337);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 41);\r\n" + 
        "Label l349 = new Label();\r\n" + 
        "cv.visitLabel(l349);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 42);\r\n" + 
        "Label l350 = new Label();\r\n" + 
        "cv.visitLabel(l350);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 43);\r\n" + 
        "Label l351 = new Label();\r\n" + 
        "cv.visitLabel(l351);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitIntInsn(NEWARRAY, 10);\r\n" + 
        "cv.visitVarInsn(ASTORE, 44);\r\n" + 
        "Label l352 = new Label();\r\n" + 
        "cv.visitLabel(l352);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 45);\r\n" + 
        "Label l353 = new Label();\r\n" + 
        "cv.visitLabel(l353);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "Label l354 = new Label();\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l354);\r\n" + 
        "Label l355 = new Label();\r\n" + 
        "cv.visitLabel(l355);\r\n" + 
        "cv.visitVarInsn(ALOAD, 41);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l356 = new Label();\r\n" + 
        "cv.visitLabel(l356);\r\n" + 
        "cv.visitVarInsn(ALOAD, 42);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l357 = new Label();\r\n" + 
        "cv.visitLabel(l357);\r\n" + 
        "cv.visitVarInsn(ALOAD, 43);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l358 = new Label();\r\n" + 
        "cv.visitLabel(l358);\r\n" + 
        "cv.visitVarInsn(ALOAD, 44);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l359 = new Label();\r\n" + 
        "cv.visitLabel(l359);\r\n" + 
        "cv.visitIincInsn(45, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l353);\r\n" + 
        "cv.visitLabel(l354);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "Label l360 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l360);\r\n" + 
        "Label l361 = new Label();\r\n" + 
        "cv.visitLabel(l361);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 45);\r\n" + 
        "Label l362 = new Label();\r\n" + 
        "cv.visitLabel(l362);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitJumpInsn(IF_ICMPGE, l360);\r\n" + 
        "Label l363 = new Label();\r\n" + 
        "cv.visitLabel(l363);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"forceJFIF\", \"Z\");\r\n" + 
        "Label l364 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l364);\r\n" + 
        "Label l365 = new Label();\r\n" + 
        "cv.visitLabel(l365);\r\n" + 
        "cv.visitVarInsn(ALOAD, 41);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"componentId\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "cv.visitLabel(l364);\r\n" + 
        "cv.visitVarInsn(ALOAD, 42);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"HsamplingFactor\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l366 = new Label();\r\n" + 
        "cv.visitLabel(l366);\r\n" + 
        "cv.visitVarInsn(ALOAD, 43);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"VsamplingFactor\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l367 = new Label();\r\n" + 
        "cv.visitLabel(l367);\r\n" + 
        "cv.visitVarInsn(ALOAD, 44);\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ALOAD, 31);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment\", \"componentSpecs\", \"[Lcom/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/SOFMarkerSegment$ComponentSpec\", \"QtableSelector\", \"I\");\r\n" + 
        "cv.visitInsn(IASTORE);\r\n" + 
        "Label l368 = new Label();\r\n" + 
        "cv.visitLabel(l368);\r\n" + 
        "cv.visitIincInsn(45, 1);\r\n" + 
        "cv.visitJumpInsn(GOTO, l362);\r\n" + 
        "cv.visitLabel(l360);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 18);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceXOffset\", \"I\");\r\n" + 
        "Label l369 = new Label();\r\n" + 
        "cv.visitLabel(l369);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 18);\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "Label l370 = new Label();\r\n" + 
        "cv.visitLabel(l370);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 19);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceYOffset\", \"I\");\r\n" + 
        "Label l371 = new Label();\r\n" + 
        "cv.visitLabel(l371);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 19);\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "Label l372 = new Label();\r\n" + 
        "cv.visitLabel(l372);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 16);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitVarInsn(ILOAD, 16);\r\n" + 
        "cv.visitInsn(IDIV);\r\n" + 
        "cv.visitVarInsn(ISTORE, 45);\r\n" + 
        "Label l373 = new Label();\r\n" + 
        "cv.visitLabel(l373);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceHeight\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 17);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitVarInsn(ILOAD, 17);\r\n" + 
        "cv.visitInsn(IDIV);\r\n" + 
        "cv.visitVarInsn(ISTORE, 46);\r\n" + 
        "Label l374 = new Label();\r\n" + 
        "cv.visitLabel(l374);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitInsn(IMUL);\r\n" + 
        "cv.visitVarInsn(ISTORE, 47);\r\n" + 
        "Label l375 = new Label();\r\n" + 
        "cv.visitLabel(l375);\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/awt/image/DataBufferByte\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ILOAD, 47);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/awt/image/DataBufferByte\", \"<init>\", \"(I)V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 48);\r\n" + 
        "Label l376 = new Label();\r\n" + 
        "cv.visitLabel(l376);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"bandOffsets\", \"[[I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(ISUB);\r\n" + 
        "cv.visitInsn(AALOAD);\r\n" + 
        "cv.visitVarInsn(ASTORE, 49);\r\n" + 
        "Label l377 = new Label();\r\n" + 
        "cv.visitLabel(l377);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 48);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitVarInsn(ILOAD, 47);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 49);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"java/awt/image/Raster\", \"createInterleavedRaster\", \"(Ljava/awt/image/DataBuffer;IIII[ILjava/awt/Point;)Ljava/awt/image/WritableRaster;\");\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"raster\", \"Ljava/awt/image/WritableRaster;\");\r\n" + 
        "Label l378 = new Label();\r\n" + 
        "cv.visitLabel(l378);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processImageStarted\", \"(I)V\");\r\n" + 
        "Label l379 = new Label();\r\n" + 
        "cv.visitLabel(l379);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitVarInsn(ISTORE, 50);\r\n" + 
        "Label l380 = new Label();\r\n" + 
        "cv.visitLabel(l380);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"debug\", \"Z\");\r\n" + 
        "Label l381 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l381);\r\n" + 
        "Label l382 = new Label();\r\n" + 
        "cv.visitLabel(l382);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"inCsType: \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 27);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(I)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "Label l383 = new Label();\r\n" + 
        "cv.visitLabel(l383);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"java/lang/System\", \"out\", \"Ljava/io/PrintStream;\");\r\n" + 
        "cv.visitTypeInsn(NEW, \"java/lang/StringBuffer\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"java/lang/StringBuffer\", \"<init>\", \"()V\");\r\n" + 
        "cv.visitLdcInsn(\"outCsType: \");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(Ljava/lang/String;)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 28);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"append\", \"(I)Ljava/lang/StringBuffer;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/StringBuffer\", \"toString\", \"()Ljava/lang/String;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/io/PrintStream\", \"println\", \"(Ljava/lang/String;)V\");\r\n" + 
        "cv.visitLabel(l381);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"structPointer\", \"J\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 48);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/awt/image/DataBufferByte\", \"getData\", \"()[B\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 27);\r\n" + 
        "cv.visitVarInsn(ILOAD, 28);\r\n" + 
        "cv.visitVarInsn(ILOAD, 9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 12);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"sourceWidth\", \"I\");\r\n" + 
        "cv.visitVarInsn(ILOAD, 45);\r\n" + 
        "cv.visitVarInsn(ILOAD, 46);\r\n" + 
        "cv.visitVarInsn(ILOAD, 16);\r\n" + 
        "cv.visitVarInsn(ILOAD, 17);\r\n" + 
        "cv.visitVarInsn(ALOAD, 20);\r\n" + 
        "cv.visitVarInsn(ILOAD, 36);\r\n" + 
        "cv.visitVarInsn(ALOAD, 21);\r\n" + 
        "cv.visitVarInsn(ALOAD, 22);\r\n" + 
        "cv.visitVarInsn(ILOAD, 37);\r\n" + 
        "cv.visitVarInsn(ILOAD, 23);\r\n" + 
        "cv.visitVarInsn(ILOAD, 25);\r\n" + 
        "Label l384 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l384);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "Label l385 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l385);\r\n" + 
        "cv.visitLabel(l384);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitLabel(l385);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"numScans\", \"I\");\r\n" + 
        "cv.visitVarInsn(ALOAD, 33);\r\n" + 
        "cv.visitVarInsn(ALOAD, 41);\r\n" + 
        "cv.visitVarInsn(ALOAD, 42);\r\n" + 
        "cv.visitVarInsn(ALOAD, 43);\r\n" + 
        "cv.visitVarInsn(ALOAD, 44);\r\n" + 
        "cv.visitVarInsn(ILOAD, 35);\r\n" + 
        "cv.visitVarInsn(ILOAD, 40);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"writeImage\", \"(J[BIII[IIIIII[Ljavax/imageio/plugins/jpeg/JPEGQTable;Z[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;ZZZI[I[I[I[I[IZI)Z\");\r\n" + 
        "cv.visitVarInsn(ISTORE, 50);\r\n" + 
        "Label l386 = new Label();\r\n" + 
        "cv.visitLabel(l386);\r\n" + 
        "cv.visitVarInsn(ILOAD, 50);\r\n" + 
        "Label l387 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l387);\r\n" + 
        "Label l388 = new Label();\r\n" + 
        "cv.visitLabel(l388);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processWriteAborted\", \"()V\");\r\n" + 
        "Label l389 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l389);\r\n" + 
        "cv.visitLabel(l387);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"processImageComplete\", \"()V\");\r\n" + 
        "cv.visitLabel(l389);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"ios\", \"Ljavax/imageio/stream/ImageOutputStream;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEINTERFACE, \"javax/imageio/stream/ImageOutputStream\", \"flush\", \"()V\");\r\n" + 
        "Label l390 = new Label();\r\n" + 
        "cv.visitLabel(l390);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IADD);\r\n" + 
        "cv.visitFieldInsn(PUTFIELD, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"currentImage\", \"I\");\r\n" + 
        "Label l391 = new Label();\r\n" + 
        "cv.visitLabel(l391);\r\n" + 
        "cv.visitInsn(RETURN);\r\n" + 
        "cv.visitLineNumber(301, l0);\r\n" + 
        "cv.visitLineNumber(302, l2);\r\n" + 
        "cv.visitLineNumber(306, l1);\r\n" + 
        "cv.visitLineNumber(307, l4);\r\n" + 
        "cv.visitLineNumber(311, l3);\r\n" + 
        "cv.visitLineNumber(313, l5);\r\n" + 
        "cv.visitLineNumber(314, l6);\r\n" + 
        "cv.visitLineNumber(315, l8);\r\n" + 
        "cv.visitLineNumber(317, l7);\r\n" + 
        "cv.visitLineNumber(318, l10);\r\n" + 
        "cv.visitLineNumber(319, l12);\r\n" + 
        "cv.visitLineNumber(322, l11);\r\n" + 
        "cv.visitLineNumber(329, l9);\r\n" + 
        "cv.visitLineNumber(330, l13);\r\n" + 
        "cv.visitLineNumber(331, l14);\r\n" + 
        "cv.visitLineNumber(332, l15);\r\n" + 
        "cv.visitLineNumber(333, l16);\r\n" + 
        "cv.visitLineNumber(334, l17);\r\n" + 
        "cv.visitLineNumber(335, l19);\r\n" + 
        "cv.visitLineNumber(336, l20);\r\n" + 
        "cv.visitLineNumber(337, l21);\r\n" + 
        "cv.visitLineNumber(338, l22);\r\n" + 
        "cv.visitLineNumber(339, l23);\r\n" + 
        "cv.visitLineNumber(340, l24);\r\n" + 
        "cv.visitLineNumber(341, l25);\r\n" + 
        "cv.visitLineNumber(346, l18);\r\n" + 
        "cv.visitLineNumber(347, l26);\r\n" + 
        "cv.visitLineNumber(350, l27);\r\n" + 
        "cv.visitLineNumber(351, l29);\r\n" + 
        "cv.visitLineNumber(352, l30);\r\n" + 
        "cv.visitLineNumber(353, l31);\r\n" + 
        "cv.visitLineNumber(354, l33);\r\n" + 
        "cv.visitLineNumber(356, l32);\r\n" + 
        "cv.visitLineNumber(357, l34);\r\n" + 
        "cv.visitLineNumber(358, l35);\r\n" + 
        "cv.visitLineNumber(359, l36);\r\n" + 
        "cv.visitLineNumber(366, l28);\r\n" + 
        "cv.visitLineNumber(367, l39);\r\n" + 
        "cv.visitLineNumber(369, l42);\r\n" + 
        "cv.visitLineNumber(370, l43);\r\n" + 
        "cv.visitLineNumber(371, l45);\r\n" + 
        "cv.visitLineNumber(373, l46);\r\n" + 
        "cv.visitLineNumber(374, l48);\r\n" + 
        "cv.visitLineNumber(375, l49);\r\n" + 
        "cv.visitLineNumber(376, l52);\r\n" + 
        "cv.visitLineNumber(375, l53);\r\n" + 
        "cv.visitLineNumber(378, l51);\r\n" + 
        "cv.visitLineNumber(381, l44);\r\n" + 
        "cv.visitLineNumber(382, l54);\r\n" + 
        "cv.visitLineNumber(383, l55);\r\n" + 
        "cv.visitLineNumber(384, l57);\r\n" + 
        "cv.visitLineNumber(383, l58);\r\n" + 
        "cv.visitLineNumber(388, l47);\r\n" + 
        "cv.visitLineNumber(393, l61);\r\n" + 
        "cv.visitLineNumber(394, l63);\r\n" + 
        "cv.visitLineNumber(401, l62);\r\n" + 
        "cv.visitLineNumber(402, l65);\r\n" + 
        "cv.visitLineNumber(388, l64);\r\n" + 
        "cv.visitLineNumber(406, l60);\r\n" + 
        "cv.visitLineNumber(407, l67);\r\n" + 
        "cv.visitLineNumber(408, l68);\r\n" + 
        "cv.visitLineNumber(409, l69);\r\n" + 
        "cv.visitLineNumber(410, l70);\r\n" + 
        "cv.visitLineNumber(411, l71);\r\n" + 
        "cv.visitLineNumber(412, l72);\r\n" + 
        "cv.visitLineNumber(413, l75);\r\n" + 
        "cv.visitLineNumber(412, l76);\r\n" + 
        "cv.visitLineNumber(415, l74);\r\n" + 
        "cv.visitLineNumber(419, l66);\r\n" + 
        "cv.visitLineNumber(420, l77);\r\n" + 
        "cv.visitLineNumber(421, l79);\r\n" + 
        "cv.visitLineNumber(423, l80);\r\n" + 
        "cv.visitLineNumber(424, l81);\r\n" + 
        "cv.visitLineNumber(425, l82);\r\n" + 
        "cv.visitLineNumber(431, l78);\r\n" + 
        "cv.visitLineNumber(432, l83);\r\n" + 
        "cv.visitLineNumber(433, l84);\r\n" + 
        "cv.visitLineNumber(434, l85);\r\n" + 
        "cv.visitLineNumber(435, l86);\r\n" + 
        "cv.visitLineNumber(436, l87);\r\n" + 
        "cv.visitLineNumber(437, l88);\r\n" + 
        "cv.visitLineNumber(438, l89);\r\n" + 
        "cv.visitLineNumber(439, l90);\r\n" + 
        "cv.visitLineNumber(440, l91);\r\n" + 
        "cv.visitLineNumber(441, l92);\r\n" + 
        "cv.visitLineNumber(442, l93);\r\n" + 
        "cv.visitLineNumber(443, l94);\r\n" + 
        "cv.visitLineNumber(444, l95);\r\n" + 
        "cv.visitLineNumber(445, l96);\r\n" + 
        "cv.visitLineNumber(446, l97);\r\n" + 
        "cv.visitLineNumber(448, l98);\r\n" + 
        "cv.visitLineNumber(450, l100);\r\n" + 
        "cv.visitLineNumber(451, l101);\r\n" + 
        "cv.visitLineNumber(452, l103);\r\n" + 
        "cv.visitLineNumber(453, l104);\r\n" + 
        "cv.visitLineNumber(454, l105);\r\n" + 
        "cv.visitLineNumber(455, l106);\r\n" + 
        "cv.visitLineNumber(458, l102);\r\n" + 
        "cv.visitLineNumber(459, l108);\r\n" + 
        "cv.visitLineNumber(461, l107);\r\n" + 
        "cv.visitLineNumber(462, l110);\r\n" + 
        "cv.visitLineNumber(465, l109);\r\n" + 
        "cv.visitLineNumber(466, l111);\r\n" + 
        "cv.visitLineNumber(467, l112);\r\n" + 
        "cv.visitLineNumber(468, l113);\r\n" + 
        "cv.visitLineNumber(470, l114);\r\n" + 
        "cv.visitLineNumber(472, l115);\r\n" + 
        "cv.visitLineNumber(474, l117);\r\n" + 
        "cv.visitLineNumber(475, l119);\r\n" + 
        "cv.visitLineNumber(476, l120);\r\n" + 
        "cv.visitLineNumber(477, l121);\r\n" + 
        "cv.visitLineNumber(479, l122);\r\n" + 
        "cv.visitLineNumber(481, l123);\r\n" + 
        "cv.visitLineNumber(483, l116);\r\n" + 
        "cv.visitLineNumber(484, l124);\r\n" + 
        "cv.visitLineNumber(485, l125);\r\n" + 
        "cv.visitLineNumber(490, l118);\r\n" + 
        "cv.visitLineNumber(492, l126);\r\n" + 
        "cv.visitLineNumber(493, l127);\r\n" + 
        "cv.visitLineNumber(494, l128);\r\n" + 
        "cv.visitLineNumber(499, l99);\r\n" + 
        "cv.visitLineNumber(500, l129);\r\n" + 
        "cv.visitLineNumber(501, l131);\r\n" + 
        "cv.visitLineNumber(502, l133);\r\n" + 
        "cv.visitLineNumber(503, l134);\r\n" + 
        "cv.visitLineNumber(504, l135);\r\n" + 
        "cv.visitLineNumber(508, l132);\r\n" + 
        "cv.visitLineNumber(509, l137);\r\n" + 
        "cv.visitLineNumber(510, l138);\r\n" + 
        "cv.visitLineNumber(511, l140);\r\n" + 
        "cv.visitLineNumber(513, l139);\r\n" + 
        "cv.visitLineNumber(517, l136);\r\n" + 
        "cv.visitLineNumber(524, l130);\r\n" + 
        "cv.visitLineNumber(525, l141);\r\n" + 
        "cv.visitLineNumber(526, l142);\r\n" + 
        "cv.visitLineNumber(527, l143);\r\n" + 
        "cv.visitLineNumber(528, l144);\r\n" + 
        "cv.visitLineNumber(531, l145);\r\n" + 
        "cv.visitLineNumber(532, l146);\r\n" + 
        "cv.visitLineNumber(534, l147);\r\n" + 
        "cv.visitLineNumber(535, l148);\r\n" + 
        "cv.visitLineNumber(536, l149);\r\n" + 
        "cv.visitLineNumber(538, l150);\r\n" + 
        "cv.visitLineNumber(539, l152);\r\n" + 
        "cv.visitLineNumber(541, l155);\r\n" + 
        "cv.visitLineNumber(543, l158);\r\n" + 
        "cv.visitLineNumber(547, l151);\r\n" + 
        "cv.visitLineNumber(548, l161);\r\n" + 
        "cv.visitLineNumber(549, l162);\r\n" + 
        "cv.visitLineNumber(551, l163);\r\n" + 
        "cv.visitLineNumber(552, l165);\r\n" + 
        "cv.visitLineNumber(553, l167);\r\n" + 
        "cv.visitLineNumber(556, l166);\r\n" + 
        "cv.visitLineNumber(558, l168);\r\n" + 
        "cv.visitLineNumber(559, l170);\r\n" + 
        "cv.visitLineNumber(561, l171);\r\n" + 
        "cv.visitLineNumber(563, l172);\r\n" + 
        "cv.visitLineNumber(564, l174);\r\n" + 
        "cv.visitLineNumber(565, l175);\r\n" + 
        "cv.visitLineNumber(568, l173);\r\n" + 
        "cv.visitLineNumber(572, l169);\r\n" + 
        "cv.visitLineNumber(573, l178);\r\n" + 
        "cv.visitLineNumber(575, l179);\r\n" + 
        "cv.visitLineNumber(576, l180);\r\n" + 
        "cv.visitLineNumber(579, l177);\r\n" + 
        "cv.visitLineNumber(580, l181);\r\n" + 
        "cv.visitLineNumber(581, l182);\r\n" + 
        "cv.visitLineNumber(582, l183);\r\n" + 
        "cv.visitLineNumber(587, l164);\r\n" + 
        "cv.visitLineNumber(588, l185);\r\n" + 
        "cv.visitLineNumber(590, l186);\r\n" + 
        "cv.visitLineNumber(592, l187);\r\n" + 
        "cv.visitLineNumber(594, l191);\r\n" + 
        "cv.visitLineNumber(595, l192);\r\n" + 
        "cv.visitLineNumber(596, l193);\r\n" + 
        "cv.visitLineNumber(600, l190);\r\n" + 
        "cv.visitLineNumber(601, l194);\r\n" + 
        "cv.visitLineNumber(606, l184);\r\n" + 
        "cv.visitLineNumber(607, l195);\r\n" + 
        "cv.visitLineNumber(610, l196);\r\n" + 
        "cv.visitLineNumber(613, l197);\r\n" + 
        "cv.visitLineNumber(615, l198);\r\n" + 
        "cv.visitLineNumber(616, l199);\r\n" + 
        "cv.visitLineNumber(617, l200);\r\n" + 
        "cv.visitLineNumber(619, l202);\r\n" + 
        "cv.visitLineNumber(620, l205);\r\n" + 
        "cv.visitLineNumber(622, l204);\r\n" + 
        "cv.visitLineNumber(623, l207);\r\n" + 
        "cv.visitLineNumber(624, l208);\r\n" + 
        "cv.visitLineNumber(629, l206);\r\n" + 
        "cv.visitLineNumber(631, l209);\r\n" + 
        "cv.visitLineNumber(632, l210);\r\n" + 
        "cv.visitLineNumber(637, l201);\r\n" + 
        "cv.visitLineNumber(638, l212);\r\n" + 
        "cv.visitLineNumber(639, l214);\r\n" + 
        "cv.visitLineNumber(640, l215);\r\n" + 
        "cv.visitLineNumber(643, l216);\r\n" + 
        "cv.visitLineNumber(646, l213);\r\n" + 
        "cv.visitLineNumber(647, l218);\r\n" + 
        "cv.visitLineNumber(649, l219);\r\n" + 
        "cv.visitLineNumber(650, l222);\r\n" + 
        "cv.visitLineNumber(652, l220);\r\n" + 
        "cv.visitLineNumber(653, l223);\r\n" + 
        "cv.visitLineNumber(655, l221);\r\n" + 
        "cv.visitLineNumber(657, l224);\r\n" + 
        "cv.visitLineNumber(658, l225);\r\n" + 
        "cv.visitLineNumber(659, l226);\r\n" + 
        "cv.visitLineNumber(663, l217);\r\n" + 
        "cv.visitLineNumber(666, l227);\r\n" + 
        "cv.visitLineNumber(667, l229);\r\n" + 
        "cv.visitLineNumber(669, l228);\r\n" + 
        "cv.visitLineNumber(671, l230);\r\n" + 
        "cv.visitLineNumber(672, l232);\r\n" + 
        "cv.visitLineNumber(674, l231);\r\n" + 
        "cv.visitLineNumber(679, l211);\r\n" + 
        "cv.visitLineNumber(680, l234);\r\n" + 
        "cv.visitLineNumber(681, l235);\r\n" + 
        "cv.visitLineNumber(684, l233);\r\n" + 
        "cv.visitLineNumber(685, l237);\r\n" + 
        "cv.visitLineNumber(687, l239);\r\n" + 
        "cv.visitLineNumber(688, l240);\r\n" + 
        "cv.visitLineNumber(691, l238);\r\n" + 
        "cv.visitLineNumber(694, l236);\r\n" + 
        "cv.visitLineNumber(697, l241);\r\n" + 
        "cv.visitLineNumber(698, l243);\r\n" + 
        "cv.visitLineNumber(700, l242);\r\n" + 
        "cv.visitLineNumber(702, l244);\r\n" + 
        "cv.visitLineNumber(707, l247);\r\n" + 
        "cv.visitLineNumber(709, l203);\r\n" + 
        "cv.visitLineNumber(710, l248);\r\n" + 
        "cv.visitLineNumber(711, l250);\r\n" + 
        "cv.visitLineNumber(712, l252);\r\n" + 
        "cv.visitLineNumber(713, l253);\r\n" + 
        "cv.visitLineNumber(717, l254);\r\n" + 
        "cv.visitLineNumber(718, l251);\r\n" + 
        "cv.visitLineNumber(719, l256);\r\n" + 
        "cv.visitLineNumber(721, l258);\r\n" + 
        "cv.visitLineNumber(722, l259);\r\n" + 
        "cv.visitLineNumber(725, l257);\r\n" + 
        "cv.visitLineNumber(727, l255);\r\n" + 
        "cv.visitLineNumber(730, l249);\r\n" + 
        "cv.visitLineNumber(731, l261);\r\n" + 
        "cv.visitLineNumber(732, l262);\r\n" + 
        "cv.visitLineNumber(734, l260);\r\n" + 
        "cv.visitLineNumber(735, l264);\r\n" + 
        "cv.visitLineNumber(737, l265);\r\n" + 
        "cv.visitLineNumber(739, l266);\r\n" + 
        "cv.visitLineNumber(743, l263);\r\n" + 
        "cv.visitLineNumber(752, l176);\r\n" + 
        "cv.visitLineNumber(753, l267);\r\n" + 
        "cv.visitLineNumber(755, l268);\r\n" + 
        "cv.visitLineNumber(756, l270);\r\n" + 
        "cv.visitLineNumber(757, l272);\r\n" + 
        "cv.visitLineNumber(760, l271);\r\n" + 
        "cv.visitLineNumber(761, l276);\r\n" + 
        "cv.visitLineNumber(762, l277);\r\n" + 
        "cv.visitLineNumber(763, l279);\r\n" + 
        "cv.visitLineNumber(765, l278);\r\n" + 
        "cv.visitLineNumber(768, l275);\r\n" + 
        "cv.visitLineNumber(769, l280);\r\n" + 
        "cv.visitLineNumber(774, l269);\r\n" + 
        "cv.visitLineNumber(775, l283);\r\n" + 
        "cv.visitLineNumber(776, l284);\r\n" + 
        "cv.visitLineNumber(780, l285);\r\n" + 
        "cv.visitLineNumber(782, l287);\r\n" + 
        "cv.visitLineNumber(783, l289);\r\n" + 
        "cv.visitLineNumber(784, l290);\r\n" + 
        "cv.visitLineNumber(785, l291);\r\n" + 
        "cv.visitLineNumber(791, l288);\r\n" + 
        "cv.visitLineNumber(792, l293);\r\n" + 
        "cv.visitLineNumber(793, l294);\r\n" + 
        "cv.visitLineNumber(794, l295);\r\n" + 
        "cv.visitLineNumber(795, l296);\r\n" + 
        "cv.visitLineNumber(799, l292);\r\n" + 
        "cv.visitLineNumber(801, l297);\r\n" + 
        "cv.visitLineNumber(803, l298);\r\n" + 
        "cv.visitLineNumber(804, l300);\r\n" + 
        "cv.visitLineNumber(805, l301);\r\n" + 
        "cv.visitLineNumber(808, l299);\r\n" + 
        "cv.visitLineNumber(809, l302);\r\n" + 
        "cv.visitLineNumber(810, l303);\r\n" + 
        "cv.visitLineNumber(820, l286);\r\n" + 
        "cv.visitLineNumber(826, l307);\r\n" + 
        "cv.visitLineNumber(827, l308);\r\n" + 
        "cv.visitLineNumber(830, l309);\r\n" + 
        "cv.visitLineNumber(831, l310);\r\n" + 
        "cv.visitLineNumber(833, l311);\r\n" + 
        "cv.visitLineNumber(835, l312);\r\n" + 
        "cv.visitLineNumber(836, l314);\r\n" + 
        "cv.visitLineNumber(838, l317);\r\n" + 
        "cv.visitLineNumber(840, l320);\r\n" + 
        "cv.visitLineNumber(843, l323);\r\n" + 
        "cv.visitLineNumber(844, l325);\r\n" + 
        "cv.visitLineNumber(847, l324);\r\n" + 
        "cv.visitLineNumber(848, l327);\r\n" + 
        "cv.visitLineNumber(850, l326);\r\n" + 
        "cv.visitLineNumber(851, l328);\r\n" + 
        "cv.visitLineNumber(857, l313);\r\n" + 
        "cv.visitLineNumber(858, l330);\r\n" + 
        "cv.visitLineNumber(859, l332);\r\n" + 
        "cv.visitLineNumber(860, l331);\r\n" + 
        "cv.visitLineNumber(861, l334);\r\n" + 
        "cv.visitLineNumber(862, l333);\r\n" + 
        "cv.visitLineNumber(863, l336);\r\n" + 
        "cv.visitLineNumber(865, l335);\r\n" + 
        "cv.visitLineNumber(871, l329);\r\n" + 
        "cv.visitLineNumber(873, l338);\r\n" + 
        "cv.visitLineNumber(874, l340);\r\n" + 
        "cv.visitLineNumber(875, l341);\r\n" + 
        "cv.visitLineNumber(876, l339);\r\n" + 
        "cv.visitLineNumber(877, l343);\r\n" + 
        "cv.visitLineNumber(878, l344);\r\n" + 
        "cv.visitLineNumber(879, l342);\r\n" + 
        "cv.visitLineNumber(880, l346);\r\n" + 
        "cv.visitLineNumber(881, l347);\r\n" + 
        "cv.visitLineNumber(883, l345);\r\n" + 
        "cv.visitLineNumber(884, l348);\r\n" + 
        "cv.visitLineNumber(889, l337);\r\n" + 
        "cv.visitLineNumber(890, l349);\r\n" + 
        "cv.visitLineNumber(891, l350);\r\n" + 
        "cv.visitLineNumber(892, l351);\r\n" + 
        "cv.visitLineNumber(893, l352);\r\n" + 
        "cv.visitLineNumber(894, l355);\r\n" + 
        "cv.visitLineNumber(895, l356);\r\n" + 
        "cv.visitLineNumber(896, l357);\r\n" + 
        "cv.visitLineNumber(897, l358);\r\n" + 
        "cv.visitLineNumber(893, l359);\r\n" + 
        "cv.visitLineNumber(901, l354);\r\n" + 
        "cv.visitLineNumber(902, l361);\r\n" + 
        "cv.visitLineNumber(903, l363);\r\n" + 
        "cv.visitLineNumber(904, l365);\r\n" + 
        "cv.visitLineNumber(906, l364);\r\n" + 
        "cv.visitLineNumber(907, l366);\r\n" + 
        "cv.visitLineNumber(908, l367);\r\n" + 
        "cv.visitLineNumber(902, l368);\r\n" + 
        "cv.visitLineNumber(912, l360);\r\n" + 
        "cv.visitLineNumber(913, l369);\r\n" + 
        "cv.visitLineNumber(914, l370);\r\n" + 
        "cv.visitLineNumber(915, l371);\r\n" + 
        "cv.visitLineNumber(917, l372);\r\n" + 
        "cv.visitLineNumber(918, l373);\r\n" + 
        "cv.visitLineNumber(921, l374);\r\n" + 
        "cv.visitLineNumber(923, l375);\r\n" + 
        "cv.visitLineNumber(926, l376);\r\n" + 
        "cv.visitLineNumber(928, l377);\r\n" + 
        "cv.visitLineNumber(937, l378);\r\n" + 
        "cv.visitLineNumber(939, l379);\r\n" + 
        "cv.visitLineNumber(941, l380);\r\n" + 
        "cv.visitLineNumber(942, l382);\r\n" + 
        "cv.visitLineNumber(943, l383);\r\n" + 
        "cv.visitLineNumber(946, l381);\r\n" + 
        "cv.visitLineNumber(971, l386);\r\n" + 
        "cv.visitLineNumber(972, l388);\r\n" + 
        "cv.visitLineNumber(974, l387);\r\n" + 
        "cv.visitLineNumber(977, l389);\r\n" + 
        "cv.visitLineNumber(978, l390);\r\n" + 
        "cv.visitLineNumber(979, l391);\r\n" + 
        "cv.visitMaxs(28, 51);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"getDefaultImageMetadata\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;)Ljavax/imageio/metadata/IIOMetadata;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitTypeInsn(NEW, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"<init>\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Lcom/sun/imageio/plugins/jpeg/JPEGImageWriter;)V\");\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(186, l0);\r\n" + 
        "cv.visitMaxs(5, 3);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"convertStreamMetadata\", \"(Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/ImageWriteParam;)Ljavax/imageio/metadata/IIOMetadata;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 3);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"isStream\", \"Z\");\r\n" + 
        "cv.visitJumpInsn(IFEQ, l1);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(195, l0);\r\n" + 
        "cv.visitLineNumber(196, l2);\r\n" + 
        "cv.visitLineNumber(197, l3);\r\n" + 
        "cv.visitLineNumber(198, l4);\r\n" + 
        "cv.visitLineNumber(201, l1);\r\n" + 
        "cv.visitMaxs(1, 4);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"writeImage\", \"(J[BIII[IIIIII[Ljavax/imageio/plugins/jpeg/JPEGQTable;Z[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;ZZZI[I[I[I[I[IZI)Z\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE + ACC_NATIVE, \"writeTables\", \"(J[Ljavax/imageio/plugins/jpeg/JPEGQTable;[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;[Ljavax/imageio/plugins/jpeg/JPEGHuffmanTable;)V\", null, null);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"convertImageMetadata\", \"(Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;)Ljavax/imageio/metadata/IIOMetadata;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitFieldInsn(GETFIELD, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"isStream\", \"Z\");\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNE, l4);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/metadata/IIOMetadata\", \"isStandardMetadataFormatSupported\", \"()Z\");\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l6);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitLdcInsn(\"javax_imageio_1.0\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 4);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"javax/imageio/metadata/IIOMetadata\", \"getAsTree\", \"(Ljava/lang/String;)Lorg/w3c/dom/Node;\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitJumpInsn(IFNULL, l6);\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitTypeInsn(NEW, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"<init>\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Lcom/sun/imageio/plugins/jpeg/JPEGImageWriter;)V\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 6);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"setFromTree\", \"(Ljava/lang/String;Lorg/w3c/dom/Node;)V\");\r\n" + 
        "Label l12 = new Label();\r\n" + 
        "cv.visitLabel(l12);\r\n" + 
        "Label l13 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l13);\r\n" + 
        "Label l14 = new Label();\r\n" + 
        "cv.visitLabel(l14);\r\n" + 
        "cv.visitVarInsn(ASTORE, 7);\r\n" + 
        "Label l15 = new Label();\r\n" + 
        "cv.visitLabel(l15);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLabel(l13);\r\n" + 
        "cv.visitVarInsn(ALOAD, 6);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitTryCatchBlock(l11, l12, l14, \"javax/imageio/metadata/IIOInvalidTreeException\");\r\n" + 
        "cv.visitLineNumber(209, l0);\r\n" + 
        "cv.visitLineNumber(210, l2);\r\n" + 
        "cv.visitLineNumber(211, l3);\r\n" + 
        "cv.visitLineNumber(212, l5);\r\n" + 
        "cv.visitLineNumber(216, l4);\r\n" + 
        "cv.visitLineNumber(221, l1);\r\n" + 
        "cv.visitLineNumber(222, l7);\r\n" + 
        "cv.visitLineNumber(224, l8);\r\n" + 
        "cv.visitLineNumber(225, l9);\r\n" + 
        "cv.visitLineNumber(226, l10);\r\n" + 
        "cv.visitLineNumber(230, l11);\r\n" + 
        "cv.visitLineNumber(235, l12);\r\n" + 
        "cv.visitLineNumber(231, l14);\r\n" + 
        "cv.visitLineNumber(234, l15);\r\n" + 
        "cv.visitLineNumber(237, l13);\r\n" + 
        "cv.visitLineNumber(240, l6);\r\n" + 
        "cv.visitMaxs(5, 8);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"getNumThumbnailsSupported\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/metadata/IIOMetadata;)I\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"jfifOK\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/metadata/IIOMetadata;)Z\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitLdcInsn(new Integer(2147483647));\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(247, l0);\r\n" + 
        "cv.visitLineNumber(248, l2);\r\n" + 
        "cv.visitLineNumber(250, l1);\r\n" + 
        "cv.visitMaxs(5, 5);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PRIVATE, \"jfifOK\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/metadata/IIOMetadata;)Z\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEG\", \"isJFIFcompliant\", \"(Ljavax/imageio/ImageTypeSpecifier;Z)Z\");\r\n" + 
        "cv.visitJumpInsn(IFNE, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "Label l3 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNULL, l3);\r\n" + 
        "Label l4 = new Label();\r\n" + 
        "cv.visitLabel(l4);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l5 = new Label();\r\n" + 
        "cv.visitLabel(l5);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitTypeInsn(INSTANCEOF, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "Label l6 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l6);\r\n" + 
        "Label l7 = new Label();\r\n" + 
        "cv.visitLabel(l7);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "Label l8 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l8);\r\n" + 
        "cv.visitLabel(l6);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"convertImageMetadata\", \"(Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;)Ljavax/imageio/metadata/IIOMetadata;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\");\r\n" + 
        "cv.visitVarInsn(ASTORE, 5);\r\n" + 
        "cv.visitLabel(l8);\r\n" + 
        "cv.visitVarInsn(ALOAD, 5);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l9 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l9);\r\n" + 
        "cv.visitLdcInsn(\"com.sun.imageio.plugins.jpeg.JFIFMarkerSegment\");\r\n" + 
        "cv.visitMethodInsn(INVOKESTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$\", \"(Ljava/lang/String;)Ljava/lang/Class;\");\r\n" + 
        "cv.visitInsn(DUP);\r\n" + 
        "cv.visitFieldInsn(PUTSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "Label l10 = new Label();\r\n" + 
        "cv.visitJumpInsn(GOTO, l10);\r\n" + 
        "cv.visitLabel(l9);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"class$com$sun$imageio$plugins$jpeg$JFIFMarkerSegment\", \"Ljava/lang/Class;\");\r\n" + 
        "cv.visitLabel(l10);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"com/sun/imageio/plugins/jpeg/JPEGMetadata\", \"findMarkerSegment\", \"(Ljava/lang/Class;Z)Lcom/sun/imageio/plugins/jpeg/MarkerSegment;\");\r\n" + 
        "cv.visitJumpInsn(IFNONNULL, l3);\r\n" + 
        "Label l11 = new Label();\r\n" + 
        "cv.visitLabel(l11);\r\n" + 
        "cv.visitInsn(ICONST_0);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLabel(l3);\r\n" + 
        "cv.visitInsn(ICONST_1);\r\n" + 
        "cv.visitInsn(IRETURN);\r\n" + 
        "cv.visitLineNumber(271, l0);\r\n" + 
        "cv.visitLineNumber(273, l2);\r\n" + 
        "cv.visitLineNumber(275, l1);\r\n" + 
        "cv.visitLineNumber(276, l4);\r\n" + 
        "cv.visitLineNumber(277, l5);\r\n" + 
        "cv.visitLineNumber(278, l7);\r\n" + 
        "cv.visitLineNumber(280, l6);\r\n" + 
        "cv.visitLineNumber(285, l8);\r\n" + 
        "cv.visitLineNumber(287, l11);\r\n" + 
        "cv.visitLineNumber(290, l3);\r\n" + 
        "cv.visitMaxs(4, 6);\r\n" + 
        "}\r\n" + 
        "{\r\n" + 
        "cv = cw.visitMethod(ACC_PUBLIC, \"getPreferredThumbnailSizes\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/metadata/IIOMetadata;)[Ljava/awt/Dimension;\", null, null);\r\n" + 
        "Label l0 = new Label();\r\n" + 
        "cv.visitLabel(l0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 0);\r\n" + 
        "cv.visitVarInsn(ALOAD, 1);\r\n" + 
        "cv.visitVarInsn(ALOAD, 2);\r\n" + 
        "cv.visitVarInsn(ALOAD, 3);\r\n" + 
        "cv.visitVarInsn(ALOAD, 4);\r\n" + 
        "cv.visitMethodInsn(INVOKESPECIAL, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"jfifOK\", \"(Ljavax/imageio/ImageTypeSpecifier;Ljavax/imageio/ImageWriteParam;Ljavax/imageio/metadata/IIOMetadata;Ljavax/imageio/metadata/IIOMetadata;)Z\");\r\n" + 
        "Label l1 = new Label();\r\n" + 
        "cv.visitJumpInsn(IFEQ, l1);\r\n" + 
        "Label l2 = new Label();\r\n" + 
        "cv.visitLabel(l2);\r\n" + 
        "cv.visitFieldInsn(GETSTATIC, \"com/sun/imageio/plugins/jpeg/JPEGImageWriter\", \"preferredThumbSizes\", \"[Ljava/awt/Dimension;\");\r\n" + 
        "cv.visitMethodInsn(INVOKEVIRTUAL, \"java/lang/Object\", \"clone\", \"()Ljava/lang/Object;\");\r\n" + 
        "cv.visitTypeInsn(CHECKCAST, \"[Ljava/awt/Dimension;\");\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLabel(l1);\r\n" + 
        "cv.visitInsn(ACONST_NULL);\r\n" + 
        "cv.visitInsn(ARETURN);\r\n" + 
        "cv.visitLineNumber(260, l0);\r\n" + 
        "cv.visitLineNumber(261, l2);\r\n" + 
        "cv.visitLineNumber(263, l1);\r\n" + 
        "cv.visitMaxs(5, 5);\r\n" + 
        "}\r\n" + 
        "cw.visitEnd();\r\n" + 
        "\r\n" + 
        "return cw.toByteArray();\r\n" + 
        "}\r\n" + 
        "}\r\n" + 
        "";
    
    IClassLoader cl = new ClassLoaderIClassLoader( new URLClassLoader( new URL[] {}));

    Parser p = new Parser( new Scanner( "JPEGImageWriterDump", new StringReader( code)));
    CompilationUnit cu = p.parseCompilationUnit();
    cu.compile( cl, DebuggingInformation.NONE)[0].toByteArray();
    
  }
}
