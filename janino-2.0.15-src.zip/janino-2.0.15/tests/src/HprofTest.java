
public class HprofTest {
    public static void main(String[] args) {
        for (int i = 0; i < 123; ++i) {
            char[] ca = new char[6789];
//            if (i == 121) System.gc();
        }
//        System.gc();
    }
}
