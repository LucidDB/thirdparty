
public class Bug_1061120 {
    public static void main(String[] args) {
        Integer i=new Integer; //duh
        System.out.println(i.intValue());
    }
}