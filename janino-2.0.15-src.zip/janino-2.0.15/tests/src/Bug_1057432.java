
public class Bug_1057432 {
    public static void main(String[] args) {
        int x = 5;
        System.out.println("1:" + x);
        silly(x*=2); //d'oh
        System.out.println("3:" + x);

        short[] y = { 1, 2, 3, 4, 5 };
        y[2] *= 2;
        System.out.println("y[2] = " + y[2]);
        System.out.println("(y[2] *= 3) = " + (y[2] *= 3));
        System.out.println("y[2] = " + y[2]);
    }
    public static void silly(int x) {
        System.out.println("2:" + x);
    }
}
