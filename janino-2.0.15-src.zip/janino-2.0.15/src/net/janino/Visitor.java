
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

/**
 * Basis for the "visitor" pattern as described in "Gamma, Helm, Johnson,
 * Vlissides: Design Patterns".
 */
public interface Visitor {
    void visitCompilationUnit(Java.CompilationUnit cu);
    void visitAnonymousClassDeclaration(Java.AnonymousClassDeclaration acd);
    void visitLocalClassDeclaration(Java.LocalClassDeclaration lcd);
    void visitPackageMemberClassDeclaration(Java.PackageMemberClassDeclaration pmcd);
    void visitMemberInterfaceDeclaration(Java.MemberInterfaceDeclaration mid);
    void visitPackageMemberInterfaceDeclaration(Java.PackageMemberInterfaceDeclaration pmid);
    void visitMemberClassDeclaration(Java.MemberClassDeclaration mcd);
    void visitConstructorDeclarator(Java.ConstructorDeclarator cd);
    void visitInitializer(Java.Initializer i);
    void visitMethodDeclarator(Java.MethodDeclarator md);
    void visitFieldDeclarator(Java.FieldDeclarator fd);
    void visitLabeledStatement(Java.LabeledStatement ls);
    void visitBlock(Java.Block b);
    void visitExpressionStatement(Java.ExpressionStatement es);
    void visitIfStatement(Java.IfStatement is);
    void visitForStatement(Java.ForStatement fs);
    void visitWhileStatement(Java.WhileStatement ws);
    void visitTryStatement(Java.TryStatement ts);
    void visitSwitchStatement(Java.SwitchStatement ss);
    void visitSynchronizedStatement(Java.SynchronizedStatement ss);
    void visitDoStatement(Java.DoStatement ds);
    void visitLocalVariableDeclarationStatement(Java.LocalVariableDeclarationStatement lvds);
    void visitReturnStatement(Java.ReturnStatement rs);
    void visitThrowStatement(Java.ThrowStatement ts);
    void visitBreakStatement(Java.BreakStatement bs);
    void visitContinueStatement(Java.ContinueStatement cs);
    void visitEmptyStatement(Java.EmptyStatement es);
    void visitLocalClassDeclarationStatement(Java.LocalClassDeclarationStatement lcds);
    void visitVariableDeclarator(Java.VariableDeclarator vd);
    void visitFormalParameter(Java.FormalParameter fp);
    void visitNewAnonymousClassInstance(Java.NewAnonymousClassInstance naci);
    void visitMethodInvocation(Java.MethodInvocation mi);
    void visitAlternateConstructorInvocation(Java.AlternateConstructorInvocation aci);
    void visitSuperConstructorInvocation(Java.SuperConstructorInvocation sci);
    void visitNewClassInstance(Java.NewClassInstance nci);
    void visitAssignment(Java.Assignment a);
    void visitArrayInitializer(Java.ArrayInitializer ai);
    void visitSimpleType(Java.SimpleType st);
    void visitBasicType(Java.BasicType bt);
    void visitReferenceType(Java.ReferenceType rt);
    void visitRvalueMemberType(Java.RvalueMemberType rmt);
    void visitArrayType(Java.ArrayType at);
    void visitAmbiguousName(Java.AmbiguousName an);
    void visitPackage(Java.Package p);
    void visitLocalVariableAccess(Java.LocalVariableAccess lva);
    void visitFieldAccess(Java.FieldAccess fa);
    void visitArrayLength(Java.ArrayLength al);
    void visitThisReference(Java.ThisReference tr);
    void visitQualifiedThisReference(Java.QualifiedThisReference qtr);
    void visitClassLiteral(Java.ClassLiteral cl);
    void visitConditionalExpression(Java.ConditionalExpression ce);
    void visitCrement(Java.Crement c);
    void visitArrayAccessExpression(Java.ArrayAccessExpression aae);
    void visitFieldAccessExpression(Java.FieldAccessExpression fae);
    void visitUnaryOperation(Java.UnaryOperation uo);
    void visitInstanceof(Java.Instanceof io);
    void visitBinaryOperation(Java.BinaryOperation bo);
    void visitCast(Java.Cast c);
    void visitSuperclassMethodInvocation(Java.SuperclassMethodInvocation smi);
    void visitParameterAccess(Java.ParameterAccess pa);
    void visitNewArray(Java.NewArray na);
    void visitLiteral(Java.Literal l);
    void visitConstantValue(Java.ConstantValue cv);
    void visitParenthesizedExpression(Java.ParenthesizedExpression pe);
}
