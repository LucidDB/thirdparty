
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.*;

import net.janino.util.ClassFile;
import net.janino.util.resource.ResourceFinder;

/**
 * This {@link net.janino.IClassLoader} loads IClasses through a
 * a {@link net.janino.util.resource.ResourceFinder} that designates
 * {@link net.janino.util.ClassFile}s.
 */
public class ResourceFinderIClassLoader extends IClassLoader {
    private final ResourceFinder resourceFinder;

    public ResourceFinderIClassLoader(
        ResourceFinder resourceFinder,
        IClassLoader   optionalParentIClassLoader
    ) {
        super(optionalParentIClassLoader);
        this.resourceFinder = resourceFinder;
        this.postConstruct();
    }

    protected IClass findIClass(String descriptor) {
        String className = Descriptor.toClassName(descriptor);
        InputStream is = this.resourceFinder.findResourceAsStream(className.replace('.', '/') + ".class");
        if (is == null) return null;
        IClass iClass;
        try {
            iClass = new ClassFileIClass(new ClassFile(is), this);
        } catch (IOException e) {
            throw new ClassFormatError(className);
        } finally {
            try { is.close(); } catch (IOException e) {}
        }
        this.defineIClass(iClass);
        return iClass;
    }

}
