
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.samples;

import net.janino.*;

/**
 * A test program that allows you to play around with the
 * {@link net.janino.ExpressionEvaluator ExpressionEvaluator} class.
 */

public class ExpressionDemo extends DemoBase {
    public static void main(String[] args) throws Exception {
        String   expression             = "total >= 100.0 ? 0.0 : 7.95";
        Class    optionalExpressionType = null;
        String[] parameterNames         = { "total", };
        Class[]  parameterTypes         = { Double.TYPE, };
        Class[]  thrownExceptions       = new Class[0];

        int i;
        for (i = 0; i < args.length; ++i) {
            String arg = args[i];
            if (!arg.startsWith("-")) break;
            if (arg.equals("-e")) {
                expression = args[++i];
            } else
            if (arg.equals("-et")) {
                optionalExpressionType = DemoBase.stringToType(args[++i]);
            } else
            if (arg.equals("-pn")) {
                parameterNames = DemoBase.explode(args[++i]);
            } else
            if (arg.equals("-pt")) {
                parameterTypes = DemoBase.stringToTypes(args[++i]);
            } else
            if (arg.equals("-te")) {
                thrownExceptions = DemoBase.stringToTypes(args[++i]);
            } else
            if (arg.equals("-help")) {
                usage();
                System.exit(0);
            } else
            {
                System.err.println("Invalid command line option \"" + arg + "\".");
                usage();
                System.exit(0);
            }
        }

        if (parameterTypes.length != parameterNames.length) {
            System.err.println("Parameter type count and parameter name count do not match.");
            usage();
            System.exit(1);
        }

        // One command line argument for each parameter.
        if (args.length - i != parameterNames.length) {
            System.err.println("Parameter value count and parameter name count do not match.");
            usage();
            System.exit(1);
        }

        // Convert command line arguments to parameter values.
        Object[] parameterValues = new Object[parameterNames.length];
        for (int j = 0; j < parameterNames.length; ++j) {
            parameterValues[j] = DemoBase.createObject(parameterTypes[j], args[i + j]);
        }

        // Create "ExpressionEvaluator" object.
        ExpressionEvaluator ee = new ExpressionEvaluator(
            expression,
            optionalExpressionType,
            parameterNames,
            parameterTypes,
            thrownExceptions,
            null              // optionalClassLoader
        );

        // Evaluate expression with actual parameter values.
        Object res = ee.evaluate(parameterValues);

        // Print expression result.
        System.out.println("Result = " + DemoBase.toString(res));
    }

    private ExpressionDemo() {}

    private static void usage() {
        System.err.println("Usage:  ExpressionDemo { <option> } { <parameter-value> }");
        System.err.println("Valid options are");
        System.err.println(" -e <expression>");
        System.err.println(" -et <expression-type>");
        System.err.println(" -pn <comma-separated-parameter-names>");
        System.err.println(" -pt <comma-separated-parameter-types>");
        System.err.println(" -te <comma-separated-thrown-exception-types>");
        System.err.println(" -help");
        System.err.println("The number of parameter names, types and values must be identical.");
    }
}
