
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util;

import java.io.FilterWriter;
import java.io.IOException;
import java.io.Writer;

/**
 * A {@link java.io.FilterWriter} that automatically indents lines by looking at
 * trailing opening braces ('{') and leading closing braces ('}').
 */
public class AutoIndentWriter extends FilterWriter {
    private static final String LINE_SEPARATOR = System.getProperty("line.separator");
    private int previousChar = -1;
    private int indentation = 0;

    public AutoIndentWriter(Writer out) {
        super(out);
    }

    public void write(int c) throws IOException {
        if (AutoIndentWriter.isLineSeparatorChar(c)) {
            if (this.previousChar == '{') this.indent();
        } else
        if (AutoIndentWriter.isLineSeparatorChar(this.previousChar)) {
            if (c == '}') this.unindent();
            for (int i = 0; i < this.indentation; ++i) this.out.write("    ");
        }
        super.write(c);
        this.previousChar = c;
    }

    public void unindent() {
        --this.indentation;
    }

    public void indent() {
        ++this.indentation;
    }
    public void write(char[] cbuf, int off, int len) throws IOException {
        for (; len > 0; --len) this.write(cbuf[off++]);
    }
    public void write(String str, int off, int len) throws IOException {
        for (; len > 0; --len) this.write(str.charAt(off++));
    }

    private static boolean isLineSeparatorChar(int c) {
        return AutoIndentWriter.LINE_SEPARATOR.indexOf(c) != -1;
    }
}
