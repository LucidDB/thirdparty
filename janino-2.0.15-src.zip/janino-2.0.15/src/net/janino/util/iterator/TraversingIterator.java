
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.iterator;

import java.util.*;

/**
 * An {@link java.util.Iterator} that iterates over a delegate, and while
 * it encounters an array, a {@link java.util.Collection}, an
 * {link Enumeration} or a {@link java.util.Iterator} element, it iterates
 * into it recursively.
 * <p>
 * Be aware that {@link #hasNext()} must read ahead one element.
 */
public class TraversingIterator implements Iterator {
    private final Stack nest = new Stack(); // Iterator
    private Object      nextElement = null;
    private boolean     nextElementRead = false; // Have we read ahead?

    public TraversingIterator(Iterator delegate) {
        this.nest.push(delegate);
    }

    public boolean hasNext() {
        return this.nextElementRead || this.readNext();
    }

    public Object next() {
        if (!this.nextElementRead && !this.readNext()) throw new NoSuchElementException();
        this.nextElementRead = false;
        return this.nextElement;
    }

    /**
     * Reads the next element and stores it in {@link #nextElement}.
     * @return <code>false</code> if no more element can be read.
     */
    private boolean readNext() {
        while (!this.nest.empty()) {
            Iterator it = (Iterator) this.nest.peek();
            if (!it.hasNext()) {
                this.nest.pop();
                continue;
            }
            Object o = it.next();
            if (o instanceof Iterator) {
                this.nest.push(o);
            } else
            if (o instanceof Object[]) {
                this.nest.push(Arrays.asList((Object[]) o).iterator());
            } else
            if (o instanceof Collection) {
                this.nest.push(((Collection) o).iterator());
            } else
            if (o instanceof Enumeration) {
                this.nest.push(new EnumerationIterator((Enumeration) o));
            } else
            {
                this.nextElement = o;
                this.nextElementRead = true;
                return true;
            }
        }
        return false;
    }

    public void remove() { throw new UnsupportedOperationException("remove"); }
}
