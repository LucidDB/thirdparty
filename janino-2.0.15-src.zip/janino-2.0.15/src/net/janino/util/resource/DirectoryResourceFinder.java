
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.resource;

import java.io.*;
import java.util.*;

/**
 * A {@link net.janino.util.resource.FileResourceFinder} that finds file resources in
 * a directory. The name of the file is constructed by concatenating a dirctory name
 * with the resource name such that slashes in the resource name map to file
 * separators.
 */
public class DirectoryResourceFinder extends FileResourceFinder {
    private final File directory;
    private final Map  subdirectoryNameToFiles = new HashMap(); // String directoryName => Set => File

    /**
     * @param directory the directory to use as the search base
     */
    public DirectoryResourceFinder(File directory) {
        this.directory = directory;
    }

    public String toString() { return "dir:" + this.directory; }

    // Implement FileResourceFinder.
    protected File findResourceAsFile(String resourceName) {
    
        // Determine the subdirectory name (null for no subdirectory).
        int idx = resourceName.lastIndexOf('/');
        String subdirectoryName = (
            idx == -1 ? null :
            resourceName.substring(0, idx).replace('/', File.separatorChar)
        );
    
        // Determine files existing in this subdirectory.
        Set files = (Set) this.subdirectoryNameToFiles.get(subdirectoryName); // String directoryName => Set => File
        if (files == null) {
            File subDirectory = (subdirectoryName == null) ? this.directory : new File(this.directory, subdirectoryName);
            File[] fa = subDirectory.listFiles();
            files = (fa == null) ? Collections.EMPTY_SET : new HashSet(Arrays.asList(fa));
            this.subdirectoryNameToFiles.put(subdirectoryName, files);
        }
    
        // Notice that "File.equals()" performs all the file-system dependent
        // magic like case conversion.
        File file = new File(this.directory, resourceName.replace('/', File.separatorChar));
        if (!files.contains(file)) return null;
    
        return file;
    }
}
