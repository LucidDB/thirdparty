
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.resource;

import java.io.*;
import java.util.*;
import java.util.zip.ZipFile;

import net.janino.util.iterator.*;

/**
 * Finds resources in "*.jar" files that exist in a given set of directories.
 */
public class JarDirectoriesResourceFinder extends LazyMultiResourceFinder {

    /**
     * @param directories The set of directories to search for JAR files.
     */
    public JarDirectoriesResourceFinder(final File[] directories) {
        this(Arrays.asList(directories).iterator());
    }
    public JarDirectoriesResourceFinder(
        Iterator directoriesIterator  // File
    ) {
        super(JarDirectoriesResourceFinder.createIterator(directoriesIterator));
    }

    private static Iterator createIterator(
        Iterator directoriesIterator  // File
    ) {
        return new MultiDimensionalIterator(

            // Iterate over directories.
            new TransformingIterator(directoriesIterator) {
                protected Object transform(Object o) {

                    // Iterate over JAR files.
                    File[] jarFiles = ((File) o).listFiles(new FilenameFilter() {
                        public boolean accept(File dir, String name) { return name.endsWith(".jar"); }
                    });
                    return new TransformingIterator(Arrays.asList(jarFiles).iterator()) {
                        protected Object transform(Object o) {
                            try {
                                return new ZipFileResourceFinder(new ZipFile((File) o));
                            } catch (IOException e) {
                                return MultiResourceFinder.EMPTY_RESOURCE_FINDER;
                            }
                        }
                    };
                }
            },
            2
        );
    }
}
