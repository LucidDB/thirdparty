
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.enum;

import java.lang.reflect.*;
import java.util.*;

/**
 * A class that represents an enumerated value. Its main feature is its
 * {@link #toString()} method, which reconstructs the clear text value
 * through reflection.
 * <p>
 * To use this class, derive from it and define one or more
 * <code>public static final</code> fields, as follows:
 * <pre>
 * public class Color extends Enumerator {
 *     public static final Color RED   = new Color(0);
 *     public static final Color GREEN = new Color(1);
 *     public static final Color BLUE  = new Color(2);
 *
 *     public Color(String s) throws EnumeratorFormatException { super(s); }
 *
 *     private Color(int value) { super(value); }
 * }
 * </pre>
 */
public abstract class Enumerator {
    private final int value;

    /**
     * Initialize the enumerator to the given value.
     */
    protected Enumerator(int value) {
        this.value = value;
    }

    /**
     * Check the object's value
     */
    public boolean equals(Object that) {
        return that.getClass() == this.getClass() && this.value == ((Enumerator) that).value;
    }

    /**
     * Examines the given {@link Class} and its superclasses for <code>public static final</code>
     * fields of the same type as <code>this</code>, and maps their names to their values.
     * @return {@link String} name => {@link Integer} values
     */
    private Map getMapping() {
        Class clazz = this.getClass();

        // Look up the mappings cache.
        {
            Map m = (Map) Enumerator.mappings.get(clazz);
            if (m != null) return m;
        }

        // Cache miss, create a new mapping.
        Map m = new HashMap();
        Field[] fields = clazz.getFields();
        for (int i = 0; i < fields.length; ++i) {
            Field f = fields[i];
            if (
                f.getType() == clazz &&
                (f.getModifiers() & (Modifier.STATIC | Modifier.FINAL)) == (Modifier.STATIC | Modifier.FINAL)
            ) {
                try {
                    Enumerator e = (Enumerator) f.get(null);
                    m.put(f.getName(), new Integer(e.value));
                } catch (IllegalAccessException ex) {
                    throw new RuntimeException("SNO: Field \"" + f + "\" is inaccessible");
                }
            }
        }

        // Cache it.
        Enumerator.mappings.put(this.getClass(), m);
        return m;
    }
    private static final Map mappings = new HashMap(); // Class => Map String name => Integer value

    /**
     * Initialize an {@link Enumerator} from a string.
     * <p>
     * The given string is converted into a value by looking at the class's
     * <code>public static final</code> fields which have the same type as the class itself.
     * 
     * @throws EnumeratorFormatException if the string cannot be identified
     */
    protected Enumerator(String s) throws EnumeratorFormatException {
        Integer v = (Integer) this.getMapping().get(s);
        if (v == null) throw new EnumeratorFormatException(s);
        this.value = v.intValue();
    }

    /**
     * Convert an {@link Enumerator} into a clear-text string.
     * <p>
     * Examine the object through reflection for <code>public static final</code>
     * fields that have the same type as this object, and return the name of the fields who's value
     * matches the object's value.
     */
    public String toString() {
        for (Iterator esi = this.getMapping().entrySet().iterator(); esi.hasNext();) {
            Map.Entry me = (Map.Entry) esi.next();
            if (this.value == ((Integer) me.getValue()).intValue()) {
                return (String) me.getKey();
            }
        }
        return Integer.toString(this.value);
    }
}
