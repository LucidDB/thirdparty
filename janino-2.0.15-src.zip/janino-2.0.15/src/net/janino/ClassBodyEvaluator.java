
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.*;

/**
 * Parses a class body and returns it as a <tt>java.lang.Class</tt> object
 * ready for use with <tt>java.lang.reflect</tt>.
 * <p>
 * Example:
 * <pre>
 *   import java.util.*;
 *
 *   static private int a = 1;
 *   private int b = 2;
 *
 *   public void func(int c, int d) {
 *       return func2(c, d);
 *   }
 *
 *   private static void func2(int e, int f) {
 *       return e * f;
 *   }
 * </pre>
 */

public class ClassBodyEvaluator extends EvaluatorBase {
    private static final String DEFAULT_CLASS_NAME = "SC";

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader)}.
     */
    public ClassBodyEvaluator(
        String classBody
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(null, new java.io.StringReader(classBody)), // scanner
            null                                                    // optionalClassLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader)}.
     */
    public ClassBodyEvaluator(
        String      optionalFileName,
        InputStream is
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(optionalFileName, is), // scanner
            null                       // optionalClassLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader)}.
     */
    public ClassBodyEvaluator(
        String   optionalFileName,
        Reader   reader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(optionalFileName, reader), // scanner
            null                                   // optionalClassLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader)}.
     */
    public ClassBodyEvaluator(
        Scanner     scanner,
        ClassLoader optionalClassLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            scanner,            // scanner
            (Class) null,       // optionalExtendedType
            new Class[0],       // implementedTypes
            optionalClassLoader // optionalClassLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader)}.
     */
    public ClassBodyEvaluator(
        Scanner     scanner,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        ClassLoader optionalClassLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            scanner,                               // scanner
            ClassBodyEvaluator.DEFAULT_CLASS_NAME, // className
            optionalExtendedType,                  // optionalExtendedType
            implementedTypes,                      // implementedTypes
            optionalClassLoader                    // optionalClassLoader
        );
    }

    /**
     * Parse and compile a class body, i.e. a series of member definitions.
     * <p>
     * The <code>optionalClassLoader</code> serves two purposes:
     * <ul>
     *   <li>It is used to look for classes referenced by the class body.
     *   <li>It is used to load the generated Java<sup>TM</sup> class
     *   into the JVM; directly if it is a subclass of {@link
     *   ByteArrayClassLoader}, or by creation of a temporary
     *   {@link ByteArrayClassLoader} if not.
     * </ul>
     * A number of constructors exist that provide useful default values for
     * the various parameters, or parse the class body from a
     * {@link String}, an {@link InputStream} or a {@link Reader}
     * instead of a {@link Scanner}.
     *
     * @param scanner source of tokens
     * @param className the name of the temporary class (uncritical)
     * @param optionalExtendedType class to extend or <tt>null</tt>
     * @param implementedTypes interfaces to implement
     * @param optionalClassLoader loads referenced classes and defines the generated class
     */
    public ClassBodyEvaluator(
        Scanner     scanner,
        String      className,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        ClassLoader optionalClassLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        super(optionalClassLoader);
        Java.CompilationUnit compilationUnit = new Java.CompilationUnit(scanner.peek().getLocation().getFileName());
        
        // Parse import declarations.
        Parser parser = new Parser(scanner);
        this.parseImportDeclarations(compilationUnit, scanner);
        
        // Add class declaration.
        Java.ClassDeclaration cd = this.addPackageMemberClassDeclaration(
            scanner.peek().getLocation(),
            compilationUnit,
            className, optionalExtendedType, implementedTypes
        );
        
        // Parse class body declarations (member declarations) until EOF.
        while (!scanner.peek().isEOF()) {
            parser.parseClassBodyDeclaration(cd);
        }

        // Compile and load it.
        try {
            this.clazz = this.compileAndLoad(
                compilationUnit,                                             // compilationUnit
                DebuggingInformation.SOURCE.add(DebuggingInformation.LINES), // debuggingInformation
                className                                                    // className
            );
        } catch (ClassNotFoundException e) {
            throw new RuntimeException();
        }
    }

    /**
     * Compiles a class body and instantiates it. The generated class may optionally
     * extend/implement a given type. The returned instance can safely be type-casted
     * to that <code>optionalBaseType</code>.
     * <p>
     * Example:
     * <pre>
     * public interface Foo {
     *     int bar(int a, int b);
     * }
     * ...
     * Foo f = (Foo) ClassBodyEvaluator.createFastClassBodyEvaluator(
     *     new Scanner(null, new StringReader("public int bar(int a, int b) { return a + b; }")),
     *     Foo.class,
     *     (ClassLoader) null          // Use current thread's context class loader
     * );
     * System.out.println("1 + 2 = " + f.bar(1, 2));
     * </pre>
     * Notice: The <code>optionalBaseType</code> must either be declared <code>public</code>,
     * or with package scope in the root package (i.e. "no" package).
     * 
     * @param scanner Source of class body tokens
     * @param optionalBaseType Base type to extend/implement (see above)
     * @param optionalClassLoader
     * @return an object that extends/implements the given <code>optionalBaseType</code>
     */
    public static Object createFastClassBodyEvaluator(
        Scanner     scanner,
        Class       optionalBaseType,
        ClassLoader optionalClassLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        return ClassBodyEvaluator.createFastClassBodyEvaluator(
            scanner,                               // scanner
            ClassBodyEvaluator.DEFAULT_CLASS_NAME, // className
            (                                      // optionalExtendedType
                optionalBaseType != null && !optionalBaseType.isInterface() ?
                optionalBaseType : null
            ),
            (                                      // implementedTypes
                optionalBaseType != null && optionalBaseType.isInterface() ?
                new Class[] { optionalBaseType } : new Class[0]
            ),
            optionalClassLoader                    // optionalClassLoader
        );
    }

    /**
     * Like {@link #createFastClassBodyEvaluator(Scanner, Class, ClassLoader)},
     * but gives you more control over the generated class (rarely needed in practice).
     * <p> 
     * Notice: The <code>optionalExtendedType</code> and the <code>implementedTypes</code>
     * must either be declared <code>public</code>, or with package scope in the same
     * package as <code>className</code>.
     * 
     * @param scanner Source of class body tokens
     * @param className Name of generated class
     * @param optionalExtendedType Class to extend
     * @param implementedTypes Interfaces to implement
     * @param optionalClassLoader
     * @return an object that extends the <code>optionalExtendedType</code> and implements the given <code>implementedTypes</code>
     */
    public static Object createFastClassBodyEvaluator(
        Scanner     scanner,
        String      className,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        ClassLoader optionalClassLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        Class c = new ClassBodyEvaluator(
            scanner,                // scanner
            className,              // className
            optionalExtendedType,   // optionalExtendedType
            implementedTypes,       // implementedTypes
            optionalClassLoader     // optionalClassLoader
        ).evaluate();
        try {
            return c.newInstance();
        } catch (InstantiationException e) {
            throw new Java.CompileException("Cannot instantiate abstract class -- one or more method implementations are missing", null);
        } catch (IllegalAccessException e) {
            // SNO - type and default constructor of generated class are PUBLIC.
            throw new RuntimeException(e.toString());
        }
    }

    /**
     * Returns the <tt>java.lang.Class</tt> object compiled from the class
     * body.
     */
    public Class evaluate() {
        return this.clazz;
    }

    private final Class clazz;
}
