
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

/**
 * An {@link IClassLoader} that loads {@link IClass}es through a reflection
 * {@link ClassLoader}.
 */
public class ClassLoaderIClassLoader extends IClassLoader {
    private static final boolean DEBUG = false;

    public ClassLoaderIClassLoader(ClassLoader classLoader) {
        super(
            null   // optionalParentIClassLoader
        );

        if (classLoader == null) throw new RuntimeException();

        this.classLoader = classLoader;
        super.postConstruct();
    }

    /**
     * Equivalent to
     * <pre>
     *   ClassLoaderIClassLoader(Thread.currentThread().getContextClassLoader())
     * </pre>
     */
    public ClassLoaderIClassLoader() {
        this(Thread.currentThread().getContextClassLoader());
    }

    public ClassLoader getClassLoader() {
        return this.classLoader;
    }

    /**
     * Find a new {@link IClass} by descriptor.
     */
    protected IClass findIClass(String descriptor) {

        //
        // See also [ 931385 ] Janino 2.0 throwing exception on arrays of java.io.File:
        //
        // "ClassLoader.loadClass()" and "Class.forName()" should be identical,
        // but "ClassLoader.loadClass("[Ljava.lang.Object;")" throws a
        // ClassNotFoundException under JDK 1.5.0 beta.
        // Unclear whether this a beta version bug and SUN will fix this in the final
        // release, but "Class.forName()" seems to work fine in all cases, so we
        // use that.
        //

        Class clazz;
        try {
//            clazz = this.classLoader.loadClass(className);
            clazz = Class.forName(Descriptor.toClassName(descriptor), false, this.classLoader);
        } catch (ClassNotFoundException e) {
            return null;
        }
        if (ClassLoaderIClassLoader.DEBUG) System.out.println("clazz = " + clazz);

        IClass result = new ReflectionIClass(clazz, this);
        this.defineIClass(result);
        return result;
    }

    private /*final*/ ClassLoader classLoader;
}
