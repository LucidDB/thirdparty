To run the tests for the system, place the junit.jar file here and run "ant test"
Must use at least version 3.7 of JUnit.
JUnit can be found at SourceForge.