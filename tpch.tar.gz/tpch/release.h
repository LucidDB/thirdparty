/*
 * : update_release.sh,v 1.3 2006/08/01 17:15:51 jms Exp $
 */
#define VERSION 2
#define RELEASE 6
#define PATCH 0
#define BUILD 1
