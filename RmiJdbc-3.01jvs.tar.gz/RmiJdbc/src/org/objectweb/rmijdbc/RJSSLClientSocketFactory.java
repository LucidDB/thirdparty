/*
 * RMISSLClientSocketFactory.java
 *
 * Created on October 7, 2001, 6:18 PM
 * @Author Douglas Hammond(djhammond@sympatico.ca)
 */

package org.objectweb.rmijdbc;

import java.net.*;
import java.io.*;
import java.util.*;
import java.security.*;
import javax.net.*;
import javax.net.ssl.*;
//import com.sun.net.ssl.*;
import java.rmi.server.*;

/**
 * SocketFactory with SSL support
 */
public class RJSSLClientSocketFactory	implements RMIClientSocketFactory, Serializable {
    public Socket createSocket(String host, int port)
        throws IOException {
            SSLSocketFactory factory =
                (SSLSocketFactory) SSLSocketFactory.getDefault();
	
            SSLSocket sslSocket = null;
            try {
                sslSocket =
                (SSLSocket) factory.createSocket(host, port);
                
//                String [] cipherSuites = sslSocket.getEnabledCipherSuites();

//                for (int i = 0; i < cipherSuites.length; i++) {
//                    System.out.println("Cipher Suite " + i +
//                                  " = " + cipherSuites[i]);
//                }
            } catch(IOException e) {
                e.printStackTrace();
                System.exit(2);
            }
            return sslSocket;
    }
}
