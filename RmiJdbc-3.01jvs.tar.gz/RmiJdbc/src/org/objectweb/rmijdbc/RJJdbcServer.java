
/**
 * RmiJdbc client/server JDBC Driver
 * (C) GIE Dyade (Groupe BULL / INRIA Research Center) 1997
 *
 * @version     1.0
 * @author      Pierre-Yves Gibello (pierreyves.gibello@experlog.com)
 *              Additional SSL support
 *              Douglas Hammond(djhammond@sympatico.ca)
 */

package org.objectweb.rmijdbc;

import java.sql.DriverManager;
import java.sql.Driver; 
import java.sql.Connection;
import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.net.InetAddress;
import java.util.Vector;
import java.util.Hashtable;
import java.security.*;

import org.objectweb.rmijdbc.RJDriverServer;
import org.objectweb.rmijdbc.RJSSLClientSocketFactory;
import org.objectweb.rmijdbc.RJSSLServerSocketFactory;
import org.objectweb.rmijdbc.RJClientSocketFactory;
import org.objectweb.rmijdbc.RJServerSocketFactory;

/**
 * The main class for RMI/JDBC Server
 */
public class RJJdbcServer
{
static
  {
// load the Jdbc-Odbc bridge by default
// added by Mike Jennings in the summer of 1999  
    try {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    } catch(ClassNotFoundException cnfe) {
      System.out.println("WARNING: Could not load the JDBC/ODBC Bridge");
    }
}


  static Vector drivers_ = new Vector();
  static int port_ = -1;
  static int lport_ = 0;  
  static boolean startreg_ = true;
  static String admpasswd_ = null;

  public static boolean verboseMode = true;

  static boolean installRMISecurityMgr = false;
  private static final int rmiJdbcDefaultPort = 1099;

  //Default value of the listener port for remote objects
  public  static  int rmiJdbcListenerPort = 0;

  //Set communication type defaul id normal sockets
  public static RMIClientSocketFactory rmiClientSocketFactory = new RJClientSocketFactory();
  public static RMIServerSocketFactory rmiServerSocketFactory = new RJServerSocketFactory();

  // GC problem on Linux Red Hat 6.0 + JDK v1.1.7B (Blackdown)
  // Thanks to Per Widerlund from Parallel Systems for the fix.
  static DriverManager dummy_for_gc;

  /**
   * Process the command-line parameters
   */
static void processArgs(String args[])
  {

    int nb = args.length;

    Hashtable hash = new Hashtable();
    hash.put("-noreg",new Integer(0));
    hash.put("-port",new Integer(1));

    hash.put("-sm",new Integer(2));
    hash.put("-securitymanager",new Integer(2));

    hash.put("-lp",new Integer(3));
    hash.put("-listenerport",new Integer(3));

    hash.put("-ssl",new Integer(4));

    hash.put("-passwd",new Integer(5));
    
    hash.put("-?",new Integer(99));
    hash.put("?",new Integer(99));
    hash.put("-h",new Integer(99));
    hash.put("-help",new Integer(99));
    hash.put("help",new Integer(99));

    
    for (int argnum=0; argnum < nb; argnum++) {

      Integer opt = (Integer)hash.get(args[argnum]);
      if(opt == null) opt = new Integer(-1);

      switch (opt.intValue()) {

       case 0:
        startreg_ = false;
        break;

       case 1:
        try {
          port_ = Integer.parseInt(args[++argnum]);
        } catch(Exception e) {
          System.err.println("Error: port must be a number");
          System.exit(1);
        }
        break;

       case 2:
        installRMISecurityMgr = true;
        break;

       case 3:
        try {
          // Check for valid port number entry
          lport_ = Integer.parseInt(args[++argnum]);
        } catch(Exception e) {
          System.err.println("Error: Listener port must be a number");
          System.exit(1);
        }
        break;

       case 4:
          try {
            // Change this line if using another security provider
            // You can also remove it if your security provider is statically
            // registered in java.security
            Security.addProvider((java.security.Provider)Class.forName(
              "com.sun.net.ssl.internal.ssl.Provider").newInstance());
          } catch(Exception ee) {
            ee.printStackTrace();
            System.exit(1);
          }
          rmiClientSocketFactory = new RJSSLClientSocketFactory();
          rmiServerSocketFactory = new RJSSLServerSocketFactory();
          break;

       case 5:
        try {
          admpasswd_ = args[++argnum];
        } catch(Exception e) {
          System.err.println("Error: no value specified for -passwd option");
          System.exit(1);
        }
        break;
 
       case 99:
        RJJdbcServer.printUsage();
        System.exit(1);
           
       default:
        drivers_.addElement(args[argnum]);
        break;
      }
    }
  }

static void printUsage() {

    System.out.println(
    "Usage:\tjava org.objectweb.rmijdbc.RJJdbcServer [-noreg] [-port port] [-lp port] [-sm] [-ssl] [driver]*");

    System.out.println(
     "-noreg: No internal registry, requires rmiregistry to be started");
    System.out.println(
     "-port: specify a TCP port number for the rmi registry (default: 1099)");
    System.out.println(
     "-lp: specify a TCP port number for the remote objects to listen (default: anonymous)");
    System.out.println(
     "-sm: Install RMI security manager (not installed by default)");
    System.out.println(
     "-ssl: Run in SSL mode (both javax.net.ssl.trustStore and javax.net.ssl.trustStorePassword must be defined");
    System.out.println(
     "-passwd: specify an administrative password");
    System.out.println("[driver]*: A list of JDBC driver classes"); 
  }


void register(String name, int port, boolean startreg) throws Exception
  {
    String host;
    try {
      String hostprop="java.rmi.server.hostname";
      host = System.getProperty(hostprop);
      //System.out.println(hostprop+"="+host);

    } catch (Exception e) {

        host = null;
        System.out.println("WARNING: java.rmi.server.hostname property"
           + " can\'t be read (access denied)");
        System.out.println("If you use java.rmi.server.hostname, set the"
         + " corresponding property to \"read\" in your java.policy file");
    }

    // assume localhost if no default rmi server
    if (host == null) host = InetAddress.getLocalHost().getHostName();

    String rmiRef = "//" + host + "/" + name;

    if (port > 0) {
      rmiRef = new String("//" + host + ":" + port + "/" + name);
    }

    // RWS REMOVED
    // RJDriverServer theDriver = new RJDriverServer();
    RJDriverServer theDriver = buildDriverServer(); // RWS ADDED

    if (!startreg) { // External registry assumed
      Naming.rebind(rmiRef, theDriver);
      return;
    }

    // No external registry, start one
    if (port <= 0) port = rmiJdbcDefaultPort;
    Registry registry = LocateRegistry.createRegistry(port);
    registry.rebind(name, theDriver);
//    registry.rebind(rmiRef, theDriver);
  }
  
  
  /**
   * Build the driver server object. This is a separate method
   * so extensions can build different driver-server classes.
   * 
   * @since 8-May-1999
   */
  RJDriverServer buildDriverServer() throws java.rmi.RemoteException {
    return new RJDriverServer(admpasswd_);
  }

  public static void main(String[] args) {
    try {
      Class.forName("org.objectweb.rmijdbc.RJDriverServer_Stub");
    } catch(ClassNotFoundException cnfe) {
      System.out.println("Can't find stub!");
      System.exit(0);
    }

    verboseMode = Boolean.valueOf(
     System.getProperty("RmiJdbc.verbose", "true")).booleanValue();

    processArgs(args);
  
    printMsg("Starting RmiJdbc Server !");

    // RWS ADDED -- broke up main into two routines
    initServer(new RJJdbcServer()); // RWS ADDED
    // RWS ADDED
  }


  static void initServer(RJJdbcServer theServer) { // RWS ADDED

    try {

      // Check for valid listener port

      if(lport_<0) {
        printMsg(" Invalid TCP port \" "+lport_+" \" as listener port for remote objects:  Using an anonymous port");
      } else if(lport_>0) {
        rmiJdbcListenerPort=lport_;
        printMsg("Remote objects will be listening on port number: "+rmiJdbcListenerPort);
      }

      // Args on the command line are interpreted as jdbc Driver class names
      // Try to register them in the jdbc DriverManager
      // For example, to register the driver for the InstantDB database:
      // java org.objectweb.rmijdbc.RJJdbcServer org.enhydra.instantdb.jdbc.idbDriver
      // Of course, you can also use the jdbc.drivers System property

      for(int i = 0; i < drivers_.size(); i++)
      {
        String drv = (String)drivers_.elementAt(i);
        try {
          // Class.forName(...) should be enough, without newInstance() !
          // On some platforms, it is not...
          Class.forName(drv).newInstance();
          printMsg(drv + " registered in DriverManager");
        } catch(Exception e) {
          System.err.println("*** Can't register jdbc Driver for " + drv);
          System.err.println("Error message is: " + e.getMessage());
        }
      }

      // The following code is useful on some platforms where the ClassLoader
      // has a strange behaviour (that causes "No suitable driver" exceptions
      // concerning properly registered drivers !)
      java.util.Enumeration ed = DriverManager.getDrivers();
      while(ed.hasMoreElements()) { Driver d = (Driver)ed.nextElement(); }

      // We do load a special RMISecurityManager to relax RMI Security Mgr.
      // restrictions. This is because we need to remove some of the
      // restrictions from the default RMISecurityManager, since the RMI
      // threads will/might need to access database or local files and this
      // is not allowed by default.
      //
      // IMPORTANT NOTE: the specialized RJRMISecurityManager is only
      // required if your RMI threads might do I/O operations, otherwise
      // you can use the default RMISecurityManager and uncomment the
      // following line below to use it instead.
      //
      // FIXME: Make it optional (configurable).
      //
      // NOTE: If RmiJdbc is ran _embedded_ within an application, then
      // there might be a possibility that the application has already
      // installed a Security Manager; so in that case we will let that
      // one run instead of the RMI Security Manager and we will print
      // a warning.
      //
      // System.setSecurityManager(new RMISecurityManager());
      //
      if (System.getSecurityManager() == (SecurityManager) null) {
        // check if we've asked not to install rmi security manager
        if (installRMISecurityMgr)
          System.setSecurityManager(
           (SecurityManager)new RJRMISecurityManager());
        else
          printMsg("No installation of RMI Security Manager...");

      } else {
        // We print a warning message and decide to continue
        // (ignore this at it is possible that the application
        // embedding us had already installed set a security Mgr.

        printMsg(
         "** Warning: RMI Security Manager has NOT been installed as ");
        printMsg(
         "** a Security Manager was already installed by the application...\n");
      }

      // RWS REMOVED
      // RJJdbcServer theServer = new RJJdbcServer();

      printMsg("Binding RmiJdbcServer...");
      theServer.register("RmiJdbcServer", port_, startreg_);
      printMsg("RmiJdbcServer bound in rmi registry");

      // If the server has its own registry, make sure the process keeps running
      if (startreg_) {
        //System.out.println("server has its own registry");
        // suspend the main thread to ensure that this process
        // will continue to run
//      Thread.currentThread().suspend();
        Thread tt = new Thread();
        tt.suspend();
        }

    }
  catch(Exception e)
    {
      System.err.println("Got Exception: "+e.getMessage());
      e.printStackTrace();
      System.exit(1);
    }
  }

 /**
  * Convenient static method to dump timestamped passed-in
  * message to the standard output.
  *
  * If RmiJdbc.verbose system property is set to false, then the messages
  * are not written out to standard output at all.
  */
  public static void printMsg(String msg) {
    if (verboseMode)
      System.out.println(new java.util.Date().toString()
       + ": [RmiJdbc] " + msg);
  }

};

