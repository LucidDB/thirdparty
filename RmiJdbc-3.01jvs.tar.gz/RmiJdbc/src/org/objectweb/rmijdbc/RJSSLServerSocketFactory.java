/*
 * RMISSLServerSocketFactory.java
 *
 * Created on October 7, 2001, 6:17 PM
 * @Author Douglas Hammond(djhammond@sympatico.ca)
 */

package org.objectweb.rmijdbc;

import java.net.*;
import java.io.*;
import java.util.*;
import javax.net.*;
import javax.net.ssl.*;
import java.rmi.server.*;


/**
 * ServerSocketFactory with SSL support
 */
public class RJSSLServerSocketFactory implements RMIServerSocketFactory, Serializable {
    public ServerSocket createServerSocket(int serverPort)
	throws IOException { 
            try {
                SSLServerSocketFactory factory =
                    (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
	    
                 SSLServerSocket sslSocket =
                    (SSLServerSocket) factory.createServerSocket(serverPort);

//                 String [] cipherSuites = sslSocket.getEnabledCipherSuites();

//                for (int i = 0; i < cipherSuites.length; i++) {
//                    System.out.println("Cipher Suite " + i +
//                                  " = " + cipherSuites[i]);
//                }
                 return sslSocket;
	    } catch(IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
            return null;
    }
}
