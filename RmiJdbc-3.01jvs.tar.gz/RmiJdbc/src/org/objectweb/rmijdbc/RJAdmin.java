
/**
 * RmiJdbc client/server JDBC Driver
 * (C) GIE Dyade (Groupe BULL / INRIA Research Center) 1997
 *
 * @version     1.0
 * @author      Pierre-Yves Gibello (pierreyves.gibello@experlog.com)
 */

package org.objectweb.rmijdbc;

import java.sql.*;
import java.rmi.*;

import java.net.InetAddress;

/**
 * This is a sample program for RmiJdbc client/server jdbc Driver
 * RmiJdbc relies on Java RMI for jdbc objects distribution
 */
public class RJAdmin {

  public static void main(String args[]) {

    if(args.length <= 0) {
      printUsage();
      return;
    }
    String op = args[0];

    String url = "";
    if(args.length > 1) {
      url = args[1];
    }

    String user = null;
    if(args.length > 2) {
      user = args[2];
    }

    String passwd = "";
    if(args.length > 3) {
      passwd = args[3];
    }

    try {

      RJAdmin adm = new RJAdmin();

      // Register RmiJdbc Driver in jdbc DriverManager
      // The call to newInstance() is necessary on some platforms
      // (with some java VM implementations)
      Class.forName("org.objectweb.rmijdbc.Driver").newInstance();

      //System.out.println(url);

      if(op.toUpperCase().equals("SHUTDOWN")) {
        adm.shutdown(url, user); // the 2nd arg ("user") is the admin password !
        
      } else if(op.toUpperCase().equals("PING")) {
        boolean cnx=false, info=false;
        try {
          DriverPropertyInfo[] drv_inf = adm.pingDriverInfo(url);
          info = true;
          cnx = adm.pingDriverConnect(url, user, passwd);
        } catch(Exception e) {
        }

        if(cnx) {
          System.out.println("[" + url + "] server is alive.");
        } else {
          System.out.println("[" + url +
           "] server is responding, but database connection failed for [" +
           user + "," + passwd + "]");
        }
 
      } else if(op.toUpperCase().equals("INFO")) {

        System.out.println("Asking for driver info, URL=" + url);
        DriverPropertyInfo[] drv_inf = adm.pingDriverInfo(url);

        System.out.println("\nJDBC driver info - RmiJdbc server is alive.\n");

        if (drv_inf.length == 0) {
          System.out.println("No JDBC driver info available for this driver");

        } else {

          for (int i = 0;i<drv_inf.length;i++) {
            System.out.println("----------------------------------------");
            System.out.println("DriverPropertyInfo[" + i + "].name = "
                 + drv_inf[i].name );
            System.out.println("DriverPropertyInfo[" + i + "].value = "
                 + drv_inf[i].value );
            System.out.println("DriverPropertyInfo[" + i + "].description = "
                 + drv_inf[i].description );
            System.out.println("DriverPropertyInfo[" + i + "].required = "
                 + drv_inf[i].required );

            System.out.print("DriverPropertyInfo[" + i + "].choices[] = [");
            for (int j=0; j < drv_inf[i].choices.length; j++) {
              if (j > 0)
                System.out.print(",");
              System.out.print(drv_inf[i].choices[j]);
            }
            System.out.println("]");
            System.out.println("----------------------------------------");
          }
        }

        System.out.println("Trying database connection, URL=" + url);
        boolean ret = adm.pingDriverConnect(url, user, passwd);
        if(ret == true) System.out.println("Connection OK");

      }

    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  static void printUsage() {
    System.out.println("Usage: RJAdmin op url [user] [passwd]");
    System.out.println("op is one of PING or INFO");
    System.out.println("example: RJAdmin PING jdbc:rmi:jdbc:idb=sample.prp");
  }

  public DriverPropertyInfo[] pingDriverInfo(String driverURL)
  throws Exception {

    java.sql.Driver drv = DriverManager.getDriver(driverURL);
    java.util.Properties p = new java.util.Properties();
    return drv.getPropertyInfo(driverURL, p);
  }

  public boolean pingDriverConnect(String driverURL, String usr, String passwd) 
  throws Exception {
    Connection c;
    if(usr != null) c = DriverManager.getConnection(driverURL, usr, passwd);
    else c = DriverManager.getConnection(driverURL);
    c.close();
    return true;
  }

  public void shutdown(String url, String passwd) 
  throws Exception {
    org.objectweb.rmijdbc.Driver drv
     = (org.objectweb.rmijdbc.Driver)DriverManager.getDriver(url);
    drv.shutdown(url, passwd);
  }

};

