
/**
 * RmiJdbc client/server JDBC Driver
 * (C) GIE Dyade (Groupe BULL / INRIA Research Center) 1997
 * (C) ExperLog 1999-2000
 *
 * @version     1.0
 * @author      Pierre-Yves Gibello (Pierre-Yves.Gibello@experlog.com)
 */

import java.sql.*;
import java.net.InetAddress;

/**
 * This is a sample program for RmiJdbc client/server jdbc Driver
 * RmiJdbc relies on Java RMI for jdbc objects distribution
 */
public class TestClient {

  public static void main(String args[]) {

    try {

      // Register RmiJdbc Driver in jdbc DriverManager
      // The call to newInstance() is necessary on some platforms
      // (with some java VM implementations)
      Class.forName("org.objectweb.rmijdbc.Driver").newInstance();

      // Test with InstantDB free java database engine
      // See http://www.lutris.com/products/instantDB/index.html
      // for info & download
      String url = "jdbc:idb:sample.prp";

      // RMI host will point to local host
      // A port number may be specified as 1st argument to the program

      String portSpec = "";
      if(args.length > 0) {
        Integer.parseInt(args[0]); // Check port number is an integer
        portSpec = new String(":" + args[0]);
      }

      String rmiHost = new String(
       "//" + InetAddress.getLocalHost().getHostName() + portSpec);

      // RmiJdbc URL is of the form:
      // jdbc:rmi://<rmiHostName[:port]>/<jdbc-url>

      String jurl = "jdbc:rmi:" + rmiHost + "/" + url;
      System.out.println("TestClient:" + jurl);
      Connection c = DriverManager.getConnection(jurl);

      Statement st = c.createStatement();
      ResultSet rs = st.executeQuery("select * from import1");

      ResultSetMetaData md = rs.getMetaData();
      while(rs.next()) {
        System.out.print("\nTUPLE: | ");
        for(int i=1; i<= md.getColumnCount(); i++) {
          System.out.print(rs.getString(i) + " | ");
        }
      }

      rs.close();

    } catch(Exception e) {
      e.printStackTrace();
    }
  }
};

