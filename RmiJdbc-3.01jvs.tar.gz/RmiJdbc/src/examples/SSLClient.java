
/**
 * RmiJdbc client/server JDBC Driver
 * (C) GIE Dyade (Groupe BULL / INRIA Research Center) 1997
 * (C) ExperLog 1999-2000
 *
 * @version     1.0
 * @author      Pierre-Yves Gibello (pierreyves.gibello@experlog.com)
 *              Additional SSL Support
 *              Douglas Hammond(djhammond@sympatico.ca)
 */

import java.sql.*;
import java.net.InetAddress;
import java.security.*;
/**
 * This is a sample program for RmiJdbc client/server jdbc Driver in SSL mode
 * SSL is suppose to rely on Sun's JSSE (becomes standard from JDK 1.4).
 */
public class SSLClient {

  public static void main(String args[]) {
    try {

      // Change this line if you use another security provider
      // You can also remove it if the security provider is
      // statically registered in java.security
      Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

      // Register RmiJdbc Driver in jdbc DriverManager
      // The call to newInstance() is necessary on some platforms
      // (with some java VM implementations)
      Class.forName("org.objectweb.rmijdbc.Driver").newInstance();

      // Test with JDBC/ODBC bridge
      // Requires a "newtest" DSN to be properly configured
      String url = "jdbc:odbc:newtest";

      // RMI host will point to local host
      // A port number may be specified as 1st argument to the program

      String portSpec = "";
      if(args.length > 0) {
        Integer.parseInt(args[0]); // Check port number is an integer
        portSpec = new String(":" + args[0]);
      }

      String rmiHost = new String(
       "//" + InetAddress.getLocalHost().getHostName() + portSpec);

      // RmiJdbc URL is of the form:
      // jdbc:rmi://<rmiHostName[:port]>/<jdbc-url>

      String jurl = "jdbc:rmi:" + rmiHost + "/" + url;
      System.out.println("SSLClient:" + jurl);
      Connection c = DriverManager.getConnection(jurl);

      Statement st = c.createStatement();
      ResultSet rs = st.executeQuery("select * from tb_names");

      ResultSetMetaData md = rs.getMetaData();
      while(rs.next()) {
        System.out.print("\nTUPLE: | ");
        for(int i=1; i<= md.getColumnCount(); i++) {
          System.out.print(rs.getString(i) + " | ");
        }
      }

      rs.close();

    } catch(Exception e) {
      e.printStackTrace();
    }
  }

};

