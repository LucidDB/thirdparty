
/**
 * RmiJdbc client/server JDBC Driver
 * (C) GIE Dyade (Groupe BULL / INRIA Research Center) 1997
 *
 * @version     1.0
 * @author      Pierre-Yves Gibello (Pierre-Yves.Gibello@inrialpes.fr)
 */

import java.sql.*;
import java.applet.*;
import java.awt.*;

/**
 * This is a sample program for RmiJdbc client/server jdbc Driver
 * RmiJdbc relies on Java RMI for jdbc objects distribution
 */
public class TestApplet extends Applet {

  String driver_ = "org.objectweb.rmijdbc.Driver";
  String url_ = "localhost";
  String srvUrl_ = "jdbc:idb=sample.prp";
  String user_ = "";
  String passwd_ = "";
  String sql_ = "select * from import1";
  int maxResults_ = 16;

  Panel connectPanel_;
  TextField driverText_;
  TextField urlText_;
  TextField userText_;
  TextField passwdText_;
  Button connectButton_;
  Button disconnectButton_;

  Panel sqlPanel_;
  TextArea sqlArea_;
  TextField maxText_;
  Button sqlButton_;

  Panel resultPanel_;
  List sqlResults_;

  Connection connection_ = null;

  void build() {

    String srv = getCodeBase().getHost();
    if(srv == null || srv.length() < 1) {
      try {
        srv = java.net.InetAddress.getLocalHost().getHostName();
      } catch(Exception e) {
        e.printStackTrace();
        srv = new String("localhost");
      }
    }

    url_ = new String("jdbc:rmi://" + srv + "/" + srvUrl_);

    setLayout(new BorderLayout());

    connectPanel_ = new Panel();
    connectPanel_.setLayout(new GridLayout(5,2));

    connectPanel_.add(new Label("Driver"));
    driverText_ = new TextField(driver_);
    connectPanel_.add(driverText_);

    connectPanel_.add(new Label("URL"));
    urlText_ = new TextField(url_);
    connectPanel_.add(urlText_);

    connectPanel_.add(new Label("User"));
    userText_ = new TextField(user_);
    connectPanel_.add(userText_);

    connectPanel_.add(new Label("Password"));
    passwdText_ = new TextField(passwd_);
    connectPanel_.add(passwdText_);

    connectButton_ = new Button("Connect");
    connectPanel_.add(connectButton_);

    disconnectButton_ = new Button("Disconnect");
    disconnectButton_.disable();
    connectPanel_.add(disconnectButton_);

    add(connectPanel_, "North");

    // Query Panel
    sqlPanel_ = new Panel();
    sqlPanel_.setLayout(new BorderLayout());
    
    Panel reqPanel = new Panel();
    reqPanel.setLayout(new GridLayout(1,2));

    reqPanel.add(new Label("SQL"));
    sqlArea_ = new TextArea(sql_, 4, 20);
    reqPanel.add(sqlArea_);

    sqlPanel_.add(reqPanel, "North");

    Panel execPanel = new Panel();
    execPanel.setLayout(new GridLayout(1,3));
    execPanel.add(new Label("Max Results"));
    maxText_ = new TextField(Integer.toString(maxResults_), 3);
    execPanel.add(maxText_);

    sqlButton_ = new Button("Execute");
    sqlButton_.disable();
    execPanel.add(sqlButton_);

    sqlPanel_.add(execPanel, "Center");

    add(sqlPanel_, "Center");

    resultPanel_ = new Panel();
    resultPanel_.setLayout(new BorderLayout());
    sqlResults_ = new List(16);
    resultPanel_.add(sqlResults_, "Center");

    add(resultPanel_, "South");
  }

  public boolean action(Event evt, Object o) {
    try {
      if(evt.target == connectButton_) {
        driver_ = driverText_.getText();
        url_ = urlText_.getText();
        user_ = userText_.getText();
        passwd_ = passwdText_.getText();
        connectDB();
        sqlButton_.enable();
        connectButton_.disable();
        disconnectButton_.enable();
      } if(evt.target == disconnectButton_) {
        disconnectDB();
        sqlResults_.clear();
        sqlButton_.disable();
        disconnectButton_.disable();
        connectButton_.enable();

      } else if(evt.target == sqlButton_) {
        sql_ = sqlArea_.getText();
        maxResults_ = Integer.parseInt(maxText_.getText());
        execSQL();
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  void connectDB() throws Exception {
    Class.forName(driver_).newInstance();
    connection_ = DriverManager.getConnection(url_, user_, passwd_);
  }

  void disconnectDB() throws Exception {
    if(connection_ != null) connection_.close();
    connection_ = null;
  }

  void execSQL() throws Exception {
    
    Statement st = connection_.createStatement();
    ResultSet rs = st.executeQuery(sql_);

    sqlResults_.clear();
    ResultSetMetaData md = rs.getMetaData();
    StringBuffer result;
    for(int row = 0; row < maxResults_ && rs.next(); row++) {
      result = new StringBuffer();
      for(int col=1; col<= md.getColumnCount(); col++) {
        result.append(rs.getString(col) + ", ");
      }
      sqlResults_.add(result.toString());
    }

    rs.close();
    st.close();
  }

  public void init() {

    try {

      // Register RmiJdbc Driver in jdbc DriverManager
      // The call to newInstance() is necessary on some platforms 
      // (with some java VM implementations)
      Class.forName("org.objectweb.rmijdbc.Driver").newInstance();

      build();
      validate();

    } catch(Exception e) {
      e.printStackTrace();
    }

/*******************


      // Test with InstantDB free java database engine
      // See http://www.instantdb.co.uk for info & download
      String url = "jdbc:idb=sample.prp";

      // RMI host will point to applet server
      String rmiHost = new String("//" + getCodeBase().getHost());

      // RmiJdbc URL is of the form:
      // jdbc:rmi://<rmiHostName[:port]>/<jdbc-url>

      Connection c = DriverManager.getConnection("jdbc:rmi:"
       + rmiHost + "/" + url);

      Statement st = c.createStatement();
      ResultSet rs = st.executeQuery("select * from import1");

      ResultSetMetaData md = rs.getMetaData();
      while(rs.next()) {
        System.out.print("\nTUPLE: | ");
        for(int i=1; i<= md.getColumnCount(); i++) {
          System.out.print(rs.getString(i) + " | ");
        }
      }

      rs.close();

****************/
  }
};

