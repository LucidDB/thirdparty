/*
 * @(#)JGraphUtilities.java 1.0 12-MAY-2004
 * 
 * Copyright (c) 2001-2004, Gaudenz Alder
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation 
 *   and/or other materials provided with the distribution.
 * - Neither the name of JGraph nor the names of its contributors may be used
 *   to endorse or promote products derived from this software without specific
 *   prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package org.jgraph.util;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Transparency;
import java.awt.color.ColorSpace;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.swing.RepaintManager;
import javax.swing.SwingConstants;

import org.jgraph.JGraph;
import org.jgraph.algebra.CostFunction;
import org.jgraph.algebra.DefaultCostFunction;
import org.jgraph.algebra.PriorityQueue;
import org.jgraph.algebra.UnionFind;
import org.jgraph.graph.CellView;
import org.jgraph.graph.ConnectionSet;
import org.jgraph.graph.DefaultGraphCell;
import org.jgraph.graph.DefaultGraphModel;
import org.jgraph.graph.GraphConstants;
import org.jgraph.graph.GraphLayoutCache;
import org.jgraph.graph.GraphModel;
import org.jgraph.layout.JGraphLayoutAlgorithm;

/**
 * @author Gaudenz Alder
 * 
 * TODO Add code for BFS and DFS traversal (iterators)
 */
public class JGraphUtilities {

	public static final int ALIGN_LEFT = SwingConstants.LEFT;

	public static final int ALIGN_RIGHT = SwingConstants.RIGHT;

	public static final int ALIGN_TOP = SwingConstants.TOP;

	public static final int ALIGN_BOTTOM = SwingConstants.BOTTOM;

	public static final int ALIGN_CENTER = SwingConstants.CENTER;

	public static final int ALIGN_MIDDLE = SwingConstants.NEXT;

	/**
	 * @return
	 */
	public static BufferedImage toImage(JGraph graph, int inset) {
		Object[] cells = graph.getRoots();
		Rectangle2D bounds = graph.getCellBounds(cells);
		if (bounds != null) {
			graph.toScreen(bounds);
			ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_sRGB);
			ColorModel cm = new ComponentColorModel(cs, false, true,
					Transparency.OPAQUE, DataBuffer.TYPE_BYTE);
			BufferedImage img = new BufferedImage((int) bounds.getWidth() + 2
					* inset, (int) bounds.getHeight() + 2 * inset,
					BufferedImage.TYPE_INT_ARGB);
			Graphics2D graphics = img.createGraphics();
			if (graph.isOpaque()) {
				graphics.setColor(graph.getBackground());
				graphics.fillRect(0, 0, img.getWidth(), img.getHeight());

			} else {
				graphics.setComposite(AlphaComposite.getInstance(
						AlphaComposite.CLEAR, 0.0f));
				graphics.fillRect(0, 0, img.getWidth(), img.getHeight());
				graphics.setComposite(AlphaComposite.SrcOver);
			}
			graphics.translate((int) (-bounds.getX() + inset), (int) (-bounds
					.getY() + inset));
			boolean tmp = graph.isDoubleBuffered();
			RepaintManager currentManager = RepaintManager
					.currentManager(graph);
			currentManager.setDoubleBufferingEnabled(false);
			graph.paint(graphics);
			currentManager.setDoubleBufferingEnabled(true);
			return img;
		}
		return null;
	}

	/**
	 * @return Returns all vertices in <code>cells</code>.
	 */
	public static Object[] getVertices(GraphModel model, Object[] cells) {
		if (cells != null) {
			ArrayList result = new ArrayList();
			for (int i = 0; i < cells.length; i++) {
				if (!model.isPort(cells[i]) && !model.isEdge(cells[i])
						&& !isGroup(model, cells[i]))
					result.add(cells[i]);
			}
			return result.toArray();
		}
		return null;
	}

	/**
	 * @return Returns all edges in <code>model</code>.
	 */
	public static Object[] getEdges(GraphModel model) {
		Object[] cells = DefaultGraphModel.getAll(model);
		if (cells != null) {
			ArrayList result = new ArrayList();
			for (int i = 0; i < cells.length; i++)
				if (model.isEdge(cells[i]))
					result.add(cells[i]);
			return result.toArray();
		}
		return null;
	}

	/**
	 * Returns all edges in <code>cells</code>. Note: Use
	 * DefaultGraphModel.getEdges() to get all <strong>connected</code> edges.
	 * 
	 * @return
	 */
	public static Object[] getEdges(JGraph graph, Object[] cells) {
		if (cells != null) {
			ArrayList result = new ArrayList();
			GraphModel model = graph.getModel();
			for (int i = 0; i < cells.length; i++) {
				if (model.isEdge(cells[i]))
					result.add(cells[i]);
			}
			return result.toArray();
		}
		return null;
	}

	/**
	 * @return
	 */
	public static boolean isVertex(JGraph graph, Object cell) {
		return !graph.getModel().isEdge(cell) && !graph.getModel().isPort(cell)
				&& !isGroup(graph, cell);
	}

	/**
	 * @return
	 */
	public static boolean isGroup(JGraph graph, Object cell) {
		CellView view = graph.getGraphLayoutCache().getMapping(cell, false);
		if (view != null)
			return !view.isLeaf();
		return false;
	}

	/**
	 * @return
	 */
	public static boolean isVertex(GraphModel model, Object cell) {
		return !model.isEdge(cell) && !model.isPort(cell)
				&& !isGroup(model, cell);
	}

	/**
	 * @return
	 */
	public static boolean isGroup(GraphModel model, Object cell) {
		for (int i = 0; i < model.getChildCount(cell); i++) {
			if (!model.isPort(model.getChild(cell, i)))
				return true;
		}
		return false;
	}

	/**
	 * @return
	 */
	public static CostFunction createDefaultCostFunction(JGraph graph) {
		return new DefaultCostFunction(graph.getGraphLayoutCache());
	}

	/**
	 * @return
	 */
	public static UnionFind getComponents(GraphModel model) {
		UnionFind uf = new UnionFind();
		// Vertices
		Object[] v = getVertices(model, DefaultGraphModel.getAll(model));
		for (int i = 0; i < v.length; i++)
			uf.find(v[i]);
		// Edges
		Object[] e = getEdges(model);
		for (int i = 0; i < e.length; i++) {
			Object source = DefaultGraphModel.getSourceVertex(model, e[i]);
			Object target = DefaultGraphModel.getTargetVertex(model, e[i]);
			uf.union(uf.find(source), uf.find(target));
		}
		return uf;
	}

	/**
	 * Returns the ShortestPath between two cells or their descendants.
	 * Implemented with the Dijkstra Algorithm Give the method your graph, the
	 * starting cell, the finishing cell, your cost function ( if null you'll
	 * use the default ) and whether or not you want to travel only from source
	 * to target ports across edges. <br>
	 * If no cost function is provided then the default cost per edge is 1. Here
	 * is an example of how to use this with the DefaultCostFunction:
	 * 
	 * <pre>
	 * CostFunction cf = createDefaultCostFunction(graph);Object[] path = getShortestPath(graph.getModel(), graph.getSelectionCell(), sinkCell, cf, true);
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * The above code returns the shortest directed path between the selected
	 * cell (eg. a vertex) and a predefined sink (typically a vertex with no
	 * outgoing edges).
	 */
	public static Object[] getShortestPath(GraphModel model, Object from,
			Object to, CostFunction cf, boolean directed) {
		PriorityQueue q = new PriorityQueue();
		Hashtable pred = new Hashtable();
		q.setPrio(from, 0);
		// Main Loop
		int jmax = getVertices(model, DefaultGraphModel.getAll(model)).length;
		for (int j = 0; j < jmax; j++) {
			double prio = q.getPrio();
			Object obj = q.pop();
			if (obj == to)
				break;
			Object[] tmp = new Object[] { obj };
			Object[] e = (directed) ? DefaultGraphModel.getOutgoingEdges(model, obj) : DefaultGraphModel
					.getEdges(model, tmp).toArray();
			if (e != null) {
				for (int i = 0; i < e.length; i++) {
					Object neighbour = DefaultGraphModel.getOpposite(model, e[i], obj);
					double newPrio = prio
							+ ((cf != null) ? cf.getCost(e[i]) : 1);
					if (neighbour != null && neighbour != obj
							&& newPrio < q.getPrio(neighbour)) {
						pred.put(neighbour, e[i]);
						q.setPrio(neighbour, newPrio);
					}
				}
			}
			if (q.isEmpty())
				break;
		}
		// Return Path-Array
		ArrayList list = new ArrayList();
		Object obj = to;
		while (obj != null) {
			list.add(obj);
			Object edge = pred.get(obj);
			if (edge != null) {
				list.add(edge);
				obj = DefaultGraphModel.getOpposite(model, edge, obj);
			} else
				obj = null;
		}
		return list.toArray();
	}

	/**
	 * Returns the shortest spanning tree. Implemented with the Kruskal
	 * Algorithm
	 */
	public static Object[] getSpanningTree(JGraph graph, CostFunction cf) {
		if (cf == null)
			cf = createDefaultCostFunction(graph);
		GraphModel model = graph.getModel();
		SortedSet edges = sort(graph, getEdges(model), cf);
		UnionFind uf = new UnionFind();
		HashSet result = new HashSet();
		while (!edges.isEmpty()) {
			Object edge = edges.first();
			edges.remove(edge);
			Object setA, setB;
			setA = uf.find(DefaultGraphModel.getSourceVertex(model, edge));
			setB = uf.find(DefaultGraphModel.getTargetVertex(model, edge));
			if (setA == null || setB == null || setA != setB) {
				uf.union(setA, setB);
				result.add(edge);
			}
		}
		// Create set of vertices
		HashSet v = new HashSet();
		Iterator it = result.iterator();
		while (it.hasNext()) {
			Object edge = it.next();
			Object source = DefaultGraphModel.getSourceVertex(model, edge);
			Object target = DefaultGraphModel.getTargetVertex(model, edge);
			if (source != null)
				v.add(source);
			if (target != null)
				v.add(target);
		}
		Object[] cells = new Object[result.size() + v.size()];
		System.arraycopy(result.toArray(), 0, cells, 0, result.size());
		System.arraycopy(v.toArray(), 0, cells, result.size(), v.size());
		return cells;
	}

	/**
	 * @return
	 */
	public static SortedSet sort(final JGraph graph, Object[] cells,
			final CostFunction cf) {
		TreeSet set = new TreeSet(new Comparator() {

			public int compare(Object o1, Object o2) {
				Double d1 = new Double(cf.getCost(o1));
				Double d2 = new Double(cf.getCost(o2));
				return d1.compareTo(d2);
			}
		});
		for (int i = 0; i < cells.length; i++)
			set.add(cells[i]);
		return set;
	}

	/**
	 * @return
	 */
	public static void connect(JGraph graph, DefaultGraphCell prototype,
			Object[] cells) {
		Object[] v = getVertices(graph.getModel(), cells);
		if (v != null && v.length < 20) {
			ConnectionSet cs = new ConnectionSet();
			for (int i = 0; i < v.length; i++) {
				for (int j = i + 1; j < v.length; j++) {
					if (!DefaultGraphModel.containsEdgeBetween(graph.getModel(), v[i], v[j])) {
						Object edge = prototype.clone();
						Object sourcePort = graph.getModel().getChild(v[i], 0);
						Object targetPort = graph.getModel().getChild(v[j], 0);
						cs.connect(edge, sourcePort, targetPort);
					}
				}
			}
			if (!cs.isEmpty())
				graph.getGraphLayoutCache().insert(
						cs.getChangedEdges().toArray(), null, cs, null, null);
		} else
			throw new IllegalArgumentException("Too many cells selected");
	}
	
	/**
	 * @return
	 */
	public static void alignCells(JGraph graph, Object[] cells, int constraint) {
		Rectangle2D bounds = graph.getCellBounds(cells);
		GraphLayoutCache layoutCache = graph.getGraphLayoutCache();
		Map nested = new Hashtable();
		for (int i = 0; i < cells.length; i++) {
			CellView cellView = layoutCache.getMapping(cells[i], false);
			Rectangle2D cellBounds = GraphConstants.getBounds(cellView
					.getAllAttributes());
			if (bounds != null && cellBounds != null) {
				Map attrs = new Hashtable();
				Rectangle2D newBounds = align(constraint,
						(Rectangle2D) cellBounds.clone(), bounds);
				GraphConstants.setBounds(attrs, newBounds);
				nested.put(cellView.getCell(), attrs);
			}
		}
		if (!nested.isEmpty())
			layoutCache.edit(nested, null, null, null);
	}

	/**
	 * @return
	 */
	public static Rectangle2D align(int constraint, Rectangle2D cellBounds,
			Rectangle2D bounds) {
		switch (constraint) {
		case ALIGN_LEFT:
			cellBounds.setFrame(bounds.getX(), cellBounds.getY(), cellBounds
					.getWidth(), cellBounds.getHeight());
			break;
		case ALIGN_TOP:
			cellBounds.setFrame(cellBounds.getX(), bounds.getY(), cellBounds
					.getWidth(), cellBounds.getHeight());
			break;
		case ALIGN_RIGHT:
			cellBounds.setFrame(bounds.getX() + bounds.getWidth()
					- cellBounds.getWidth(), cellBounds.getY(), cellBounds
					.getWidth(), cellBounds.getHeight());
			break;
		case ALIGN_BOTTOM:
			cellBounds.setFrame(cellBounds.getX(), bounds.getY()
					+ bounds.getHeight() - cellBounds.getHeight(), cellBounds
					.getWidth(), cellBounds.getHeight());
			break;
		case ALIGN_CENTER:
			double cx = bounds.getWidth() / 2;
			cellBounds.setFrame(bounds.getX() + cx - cellBounds.getWidth() / 2,
					cellBounds.getY(), cellBounds.getWidth(), cellBounds
							.getHeight());
			break;
		case ALIGN_MIDDLE:
			double cy = bounds.getHeight() / 2;
			cellBounds.setFrame(cellBounds.getX(), bounds.getY() + cy
					- cellBounds.getHeight() / 2, cellBounds.getWidth(),
					cellBounds.getHeight());
			break;
		}
		return cellBounds;
	}

	/**
	 * @return
	 */
	public static void applyLayout(JGraph sourceGraph,
			JGraphLayoutAlgorithm layout) {
		Object[] cells = (sourceGraph.isSelectionEmpty()) ? DefaultGraphModel
				.getAll(sourceGraph.getModel()) : sourceGraph
				.getSelectionCells();
		JGraphLayoutAlgorithm.applyLayout(sourceGraph, layout, cells, null);
	}

}
