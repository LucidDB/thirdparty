// VJDBC - Virtual JDBC
// Written by Michael Link
// Website: http://vjdbc.sourceforge.net

package de.simplicit.vjdbc.command;

public class NullCommandSinkListener implements CommandSinkListener {
    public void preExecution(Command cmd) {
    }

    public void postExecution(Command cmd) {
    }
}
