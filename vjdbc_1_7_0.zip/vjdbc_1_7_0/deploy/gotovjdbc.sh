cd /home/groups/v/vj/vjdbc

cd htdocs
rm -f -r *

unzip website.zip -d htdocs/
