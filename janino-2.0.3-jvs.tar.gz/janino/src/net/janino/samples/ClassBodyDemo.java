
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.samples;

import java.lang.reflect.*;
import net.janino.*;

/**
 * A test program that allows you to play around with the
 * {@link net.janino.ClassBodyEvaluator ClassBodyEvaluator} class.
 */

public class ClassBodyDemo extends DemoBase {
    public static void main(String[] args) throws Exception {
        String script = (
            "import java.util.*;\n" +
            "\n" +
            "public static int add(int a, int b) {\n" +
            "    return a + b;\n" +
            "}\n"
        );

        Class c = new ClassBodyEvaluator(script).evaluate();
        Method m = c.getMethod("add", new Class[] { Integer.TYPE, Integer.TYPE });
        Integer res = (Integer) m.invoke(null, new Object[] {
            new Integer(7),
            new Integer(11),
        });
        System.out.println("res = " + res);
    }

    private ClassBodyDemo() {}
}
