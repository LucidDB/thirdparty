
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.samples;

import net.janino.*;

/**
 * Sample application which demonstrates how to use the
 * {@link net.janino.ExpressionEvaluator ExpressionEvaluator} class.
 */

public class ShippingCost {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: <total>");
            System.err.println("Computes the shipping costs from the double value \"total\".");
            System.err.println("If \"total\" is less than 100.0, then the result is 7.95, else the result is 0.");
            System.exit(1);
        }

        // Convert command line argument to parameter "total".
        Object[] parameterValues = new Object[] { new Double(args[0]) };

        // Create "ExpressionEvaluator" object.
        ExpressionEvaluator ee = new ExpressionEvaluator(
            "total >= 100.0 ? 0.0 : 7.95", // expression
            Double.TYPE,                   // expressionType
            new String[] { "total" },      // parameterNames,
            new Class[] { Double.TYPE },   // parameterTypes
            new Class[0],                  // thrownExceptions
            null                           // classLoader
        );

        // Evaluate expression with actual parameter values.
        Object res = ee.evaluate(parameterValues);

        // Print expression result.
        System.out.println("Result = " + (res == null ? "(null)" : res.toString()));
    }
}
