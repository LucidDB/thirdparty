
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

/**
 * This class defines constants and convenience methods for the handling of
 * modifiers as defined by the JVM.
 */
public class Mod {
    private Mod() {} // Don't instantiate me!

    public final static short NONE         = 0x0000;

    public final static short PUBLIC       = 0x0001;
    public final static short PRIVATE      = 0x0002;
    public final static short PROTECTED    = 0x0004;
    public final static short PACKAGE      = 0x0000;
    public final static short PPP          = 0x0007;

    public final static short STATIC       = 0x0008;
    public final static short FINAL        = 0x0010;
    public final static short SUPER        = 0x0020;
    public final static short SYNCHRONIZED = 0x0020;
    public final static short VOLATILE     = 0x0040;
    public final static short TRANSIENT    = 0x0080;
    public final static short NATIVE       = 0x0100;
    public final static short INTERFACE    = 0x0200;
    public final static short ABSTRACT     = 0x0400;
    public final static short STRICTFP     = 0x0800;

    public static String shortToString(short sh) {
        String res = "";
        for (int i = 0; i < Mod.mappings.length; i += 2) {
            if ((sh & ((Short) Mod.mappings[i + 1]).shortValue()) == 0) continue;
            if (res.length() > 0) res += ' ';
            res += (String) Mod.mappings[i];
        }
        return res;
    }

    private final static Object[] mappings = {
        "public",       new Short(Mod.PUBLIC),
        "private",      new Short(Mod.PRIVATE),
        "protected",    new Short(Mod.PROTECTED),
        "static",       new Short(Mod.STATIC),
        "final",        new Short(Mod.FINAL),
        "super",        new Short(Mod.SUPER),
        "synchronized", new Short(Mod.SYNCHRONIZED),
        "volatile",     new Short(Mod.VOLATILE),
        "transient",    new Short(Mod.TRANSIENT),
        "native",       new Short(Mod.NATIVE),
        "interface",    new Short(Mod.INTERFACE),
        "abstract",     new Short(Mod.ABSTRACT),
        "strictfp",     new Short(Mod.STRICTFP),
    };
}

