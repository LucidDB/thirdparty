
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.resource;

import java.io.InputStream;
import java.net.URL;

/**
 * Finds a resource by name.
 */
public interface ResourceFinder {

    /**
     * Find a resource by name and open it for reading
     * @param resourceName Slash-separated name that identifies the resource
     * @return <code>null</code> if the resource could not be found
     */
    InputStream findResourceAsStream(String resourceName);

    /**
     * Find a resource by name and return a URL that refers to it.
     * @param resourceName Slash-separated name that identifies the resource
     * @return <code>null</code> if the resource could not be found
     */
    URL findResource(String resourceName);
}
