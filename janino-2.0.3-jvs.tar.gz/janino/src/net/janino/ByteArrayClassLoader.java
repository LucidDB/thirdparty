
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * This {@link ClassLoader} allows for the loading of Java<sup>TM</sup> classes
 * from a byte array, an {@link InputStream} or a {@link File}.
 */
public class ByteArrayClassLoader extends ClassLoader {
    public ByteArrayClassLoader() {
    }

    public ByteArrayClassLoader(ClassLoader parent) {
        super(parent);
    }

    /**
     * Adds a class that will be found by {@link #findClass(String)}.
     * @param name the name of the class
     * @param data the data of the class in "class file format"
     */
    public void addClass(String name, byte[] data) {
        this.classes.put(name, data);
    }

    /**
     * Adds a class that will be found by {@link #findClass(String)}.
     * @param name the name of the class
     * @param inputStream source of data of the class in "class file format"
     * @throws IOException Problems reading from the <code>inputStream</code>
     */
    public void addClass(String name, InputStream inputStream) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        for (;;) {
            int br = inputStream.read(buffer);
            if (br == -1) break;
            baos.write(buffer, 0, br);
        }
        this.addClass(name, baos.toByteArray());
    }

    /**
     * Adds a class that will be found by {@link #findClass(String)}.
     * @param name the name of the class
     * @param file the file that contains the data of the class in "class file format"
     * @throws FileNotFoundException The file does not exist
     * @throws IOException Problems reading the class file
     */
    public void addClass(String name, File file) throws FileNotFoundException, IOException {
        InputStream is = new FileInputStream(file);
        try {
            this.addClass(name, is);
        } finally {
            is.close();
        }
    }

    /**
     * Implements {@link ClassLoader#findClass(String)}.
     */
    protected Class findClass(String name) throws ClassNotFoundException {
        byte[] data = (byte[]) this.classes.get(name);
        if (data == null) throw new ClassNotFoundException(name); 

        return super.defineClass(
            name,                // name
            data, 0, data.length // b, off, len
        );
    }

    private final Map classes = new HashMap(); // String className => byte[] data
}
