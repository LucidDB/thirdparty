
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.*;
import java.lang.reflect.*;

import net.janino.Java.Block;
import net.janino.Java.CompilationUnit;

/**
 * A script evaluator that executes a script in Java<sup>TM</sup> bytecode.
 * <p>
 * The syntax of the script to compile is a sequence of import declarations followed by a
 * sequence of statements, as defined in the
 * <a href="http://java.sun.com/docs/books/jls/second_edition">Java Language Specification, 2nd
 * edition</a>, sections
 * <a href="http://java.sun.com/docs/books/jls/second_edition/html/packages.doc.html#70209">7.5</a>
 * and
 * <a href="http://java.sun.com/docs/books/jls/second_edition/html/statements.doc.html#101241">14</a>.
 * <p>
 * Example:
 * <pre>
 *   import java.text.*;
 * 
 *   System.out.println("HELLO");
 *   System.out.println(new DecimalFormat("####,###.##").format(a));
 * </pre>
 * (Notice that this expression refers to a parameter "a", as explained below.)
 * <p>
 * The script may complete abnormally, e.g. through a RETURN statement:
 * <pre>
 *   if (a == null) {
 *       System.out.println("Oops!");
 *       return;
 *   }
 * </pre>
 * Optionally, the script may be declared with a non-void return type. In this case, the last
 * statement of the script must be a RETURN statement (or a THROW statement), and all RETURN
 * statements in the script must return a value with the given type.
 * <p>
 * The script is compiled when the {@link ScriptEvaluator} object is instantiated. The script,
 * its return type, and its parameter names and types are specified at compile time.
 * <p>
 * The script evaluator is implemented by creating and compiling a temporary compilation unit
 * defining one class with one static method the body of which consists of the statements of the
 * script.
 * <p>
 * After the {@link ScriptEvaluator} object is created, the script can be executed as often with
 * different parameter values (see {@link #evaluate(Object[])}). This execution is very fast,
 * compared to the compilation.
 * <p>
 * The more elaborate constructors of {@link ScriptEvaluator} also allow for the specification
 * of the name of the generated class, the class it extends, the interfaces it implements, the
 * name of the method that executes the script, the exceptions that this method is allowed
 * to throw, and the {@link ClassLoader} that is used to define the generated
 * class and to load classes referenced by the expression. This degree of flexibility is usually
 * not required; the most commonly used constructor is
 * {@link #ScriptEvaluator(String, Class, String[], Class[])}.
 */
public class ScriptEvaluator extends EvaluatorBase {

    /**
     * Parse a script from a {@link String} and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        String   script
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(script, Void.TYPE, new String[0], new Class[0], new Class[0]);
    }

    /**
     * Parse a script from a {@link String} and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        String   script,
        Class    returnType
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(script, returnType, new String[0], new Class[0], new Class[0]);
    }

    /**
     * Parse a script from a {@link String} and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        String   script,
        Class    returnType,
        String[] parameterNames,
        Class[]  parameterTypes
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(script, returnType, parameterNames, parameterTypes, new Class[0]);
    }

    /**
     * Parse a script from a {@link String} and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        String   script,
        Class    returnType,
        String[] parameterNames,
        Class[]  parameterTypes,
        Class[]  thrownExceptions
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(null, new java.io.StringReader(script)),
            returnType, parameterNames, parameterTypes, thrownExceptions,
            (ClassLoader) null
        );
    }

    /**
     * Parse a script from an {@link InputStream} and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        String      fileName,
        InputStream is,
        Class       returnType,
        String[]    parameterNames,
        Class[]     parameterTypes,
        Class[]     thrownExceptions,
        ClassLoader classLoader // null = use current thread's context class loader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(fileName, is),
            returnType, parameterNames, parameterTypes, thrownExceptions,
            classLoader
        );
    }

    /**
     * Parse a script from a {@link Reader} and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        String      fileName,
        Reader      reader,
        Class       returnType,
        String[]    parameterNames,
        Class[]     parameterTypes,
        Class[]     thrownExceptions,
        ClassLoader classLoader // null = use current thread's context class loader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(fileName, reader),
            returnType, parameterNames, parameterTypes, thrownExceptions,
            classLoader
        );
    }

    /**
     * Parse a script from a sequence of {@link Scanner.Token}s delivered by the given
     * {@link Scanner} object and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        Scanner     scanner,
        Class       returnType,
        String[]    parameterNames,
        Class[]     parameterTypes,
        Class[]     thrownExceptions,
        ClassLoader classLoader // null = use current thread's context class loader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            scanner,                        // scanner
            (Class) null,                   // optionalExtendedType
            new Class[0],                   // implementedInterfaces
            returnType,                     // returnType
            parameterNames, parameterTypes, // parameterNames, parameterTypes
            thrownExceptions,               // thrownExceptions
            classLoader                     // classLoader
        );
    }

    /**
     * Parse a script from a sequence of {@link Scanner.Token}s delivered by the given
     * {@link Scanner} object and compile it.
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     */
    public ScriptEvaluator(
        Scanner     scanner,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        Class       returnType,
        String[]    parameterNames,
        Class[]     parameterTypes,
        Class[]     thrownExceptions,
        ClassLoader classLoader // null = use current thread's context class loader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            scanner,                                // scanner
            "SC",                                   // className
            optionalExtendedType, implementedTypes, // optionalExtendedType, implementedTypes
            returnType, "eval",                     // returnType, methodName
            parameterNames, parameterTypes,         // parameterNames, parameterTypes
            thrownExceptions,                       // thrownExceptions
            classLoader                             // classLoader
        );
    }

    /**
     * Parse a script from a {@link String} that returns a value with the given type and
     * compile it. Parameters with the given names and types are accessible in the script.
     * <p>
     * The script is allowed to throw any of the specified exceptions.
     * <p>
     * @see #ScriptEvaluator(Scanner, String, Class, Class[], Class, String, String[], Class[], Class[], ClassLoader)
     * Construct a script evaluator that processes the given script
     * with the given return type, parameter names and types. A script is a
     * sequence of valid Java<sup>TM</sup> statements.
     * <p>
     * If the return type of the script is {@link Void#TYPE}, then all RETURN
     * statements must have no value, and the script need not be concluded by a RETURN
     * statement.
     * <p>
     * <code>parameterNames</code> and <code>parameterTypes</code> must have the same length.
     * <p>
     * The <code>classLoader</code> serves two purposes:
     * <ul>
     *   <li>It is used to look for classes referenced by the script.
     *   <li>It is used to load the generated Java<sup>TM</sup> class
     *   into the JVM; directly if it is a subclass of {@link ByteArrayClassLoader},
     *   or by creation of a temporary {@link ByteArrayClassLoader} if not.
     * </ul>
     * A <code>null</code> <code>classLoader</code> means to use the current
     * thread's context class loader.
     * <p>
     * A number of constructors exist that provide useful default values for the various
     * parameters, or parse their script from a {@link String}, an {@link InputStream}
     * or a {@link Reader} instead of a {@link Scanner}.
     *
     * @param scanner Source of tokens to parse
     * @param className Name of the temporary class (uncritical)
     * @param optionalExtendedType Superclass of the temporary class or <code>null</code>
     * @param implementedTypes The interfaces that the the generated object implements (all methods must be implemented by the <code>optionalExtendedType</code>)
     * @param returnType The return type of the temporary method that implements the script, e.g. {@link Double#TYPE} or {@link Void#TYPE}
     * @param methodName The name of the temporary method (uncritical)
     * @param parameterNames The names of the script parameters, e.g. "i" and "j".
     * @param parameterTypes The types of the script parameters, e.g. {@link Integer#TYPE} or {@link Double#TYPE}.
     * @param thrownExceptions The exceptions that the script is allowed to throw, e.g. {@link IOException}<code>.class</code>.
     * @param classLoader Loads referenced classes and defines the generated class
     */
    public ScriptEvaluator(
        Scanner     scanner,
        String      className,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        Class       returnType,
        String      methodName,
        String[]    parameterNames,
        Class[]     parameterTypes,
        Class[]     thrownExceptions,
        ClassLoader classLoader // null = use current thread's context class loader
    ) throws Scanner.ScanException, Parser.ParseException, Java.CompileException, IOException {
        super(classLoader);
        if (parameterNames.length != parameterTypes.length) throw new RuntimeException("Lengths of \"parameterNames\" and \"parameterTypes\" do not match");

        // Create a temporary compilation unit.
        CompilationUnit compilationUnit = new Java.CompilationUnit(scanner.peek().getLocation().getFileName());

        // Parse import declarations.
        this.parseImportDeclarations(compilationUnit, scanner);

        // Create class, method and block.
        Block block = this.addClassMethodBlockDeclaration(
            scanner.peek().getLocation(),           // location
            compilationUnit,                        // compilationUnit
            className,                              // className
            optionalExtendedType, implementedTypes, // optionalExtendedType, implementedTypes
            returnType, methodName,                 // returnType, methodName
            parameterNames, parameterTypes,         // parameterNames, parameterTypes
            thrownExceptions                        // thrownExceptions
        );
        
        // Parse block statements.
        Parser parser = new Parser(scanner);
        while (!scanner.peek().isEOF()) {
            block.addStatement(parser.parseBlockStatement(block));
        }

        // Compile and load it.
        Class c;
        try {
            c = this.compileAndLoad(compilationUnit, className);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException();
        }

        // Get method "eval()".
        try {
            this.method = c.getMethod(methodName, parameterTypes);
        } catch (NoSuchMethodException ex) {
            throw new RuntimeException(ex.toString());
        }
        if (this.method == null) throw new RuntimeException("Eval method not found");
    }

    /**
     * Evaluates a script with concrete parameter values.
     *
     * <p>
     *   Each parameter value must have the same type as specified through
     *   the "parameterTypes" parameter of
     *   {@link net.janino.ScriptEvaluator#ScriptEvaluator(String,
     *   Class, String[], Class[])}.
     * </p>
     * <p>
     *   Parameters of primitive type must passed with their wrapper class
     *   objects.
     * </p>
     * <p>
     *   The object returned has the class specified through the "returnType"
     *   parameter of
     *   {@link net.janino.ScriptEvaluator#ScriptEvaluator(String,
     *   Class, String[], Class[])}.
     * </p>
     *
     * @param parameterValues The concrete parameter values.
     */
    public Object evaluate(Object[] parameterValues) throws InvocationTargetException {
        try {
            return this.method.invoke(null, parameterValues);
        } catch (IllegalAccessException ex) {
            throw new RuntimeException(ex.toString());
        }
    }

    /**
     * If, for any reason, somebody needs the
     * {@link Method} object...
     *
     */
    public Method getMethod() {
        return this.method;
    }

    private final Method method;
}
