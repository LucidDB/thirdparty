
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.lang.reflect.*;

/**
 * An {@link IClassLoader} that loads {@link IClass}es through a reflection
 * {@link ClassLoader}.
 */
public class ClassLoaderIClassLoader extends IClassLoader {
    private static final boolean DEBUG = false;

    public ClassLoaderIClassLoader(ClassLoader classLoader) {
        if (classLoader == null) throw new RuntimeException();
        this.classLoader = classLoader;
        try {
            super.postConstruct();
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("ClassLoader has unexpected problems loading standard classes: " + ex.getMessage());
        }
    }

    /**
     * Equivalent to
     * <pre>
     *   ClassLoaderIClassLoader(Thread.currentThread().getContextClassLoader())
     * </pre>
     */
    public ClassLoaderIClassLoader() {
        this(Thread.currentThread().getContextClassLoader());
    }

    public ClassLoader getClassLoader() {
        return this.classLoader;
    }

    /**
     * Find a new {@link IClass} by descriptor.
     */
    protected IClass findIClass(String type) throws ClassNotFoundException {
        Class clazz;
        if (Descriptor.isPrimitive(type)) {
            if (type.equals(Descriptor.VOID   )) { clazz = Void.TYPE;      } else 
            if (type.equals(Descriptor.BYTE   )) { clazz = Byte.TYPE;       } else
            if (type.equals(Descriptor.CHAR   )) { clazz = Character.TYPE; } else
            if (type.equals(Descriptor.DOUBLE )) { clazz = Double.TYPE;    } else
            if (type.equals(Descriptor.FLOAT  )) { clazz = Float.TYPE;     } else 
            if (type.equals(Descriptor.INT    )) { clazz = Integer.TYPE;   } else
            if (type.equals(Descriptor.LONG   )) { clazz = Long.TYPE;      } else 
            if (type.equals(Descriptor.SHORT  )) { clazz = Short.TYPE;     } else 
            if (type.equals(Descriptor.BOOLEAN)) { clazz = Boolean.TYPE;   } else
            throw new RuntimeException("Invalid type \"" + type + "\""); 
        } else {
            String className = Descriptor.toClassName(type);
            if (ClassLoaderIClassLoader.DEBUG) System.out.println("1 className = " + className);

            //
            // See also [ 931385 ] Janino 2.0 throwing exception on arrays of java.io.File:
            //
            // "ClassLoader.loadClass()" and "Class.forName()" should be identical,
            // but "ClassLoader.loadClass("[Ljava.lang.Object;")" throws a
            // ClassNotFoundException under JDK 1.5.0 beta.
            // Unclear whether this a beta version bug and SUN will fix this in the final
            // release, but "Class.forName()" seems to work fine in all cases, so we
            // use that.
            //

//          clazz = this.classLoader.loadClass(className);
            clazz = Class.forName(className, false, this.classLoader);
        }
        if (ClassLoaderIClassLoader.DEBUG) System.out.println("clazz = " + clazz);

        // Create IClass object.
        IClass result = this.defineIClass(clazz);

        // Register it with the IClassLoader.
        this.defineIClass(result);

        return result;        
    }

    /**
     * Similar to {@link IClassLoader#loadIClass(String)}, but loads the {@link IClass}
     * by {@link Class} rather than by descriptor.
     * <p>
     * Ensures that there is a one-to-one mapping of {@link IClass} and
     * {@link Class} objects.
     * @param clazz
     * @return The {@link IClass} object that wraps the {@link Class} object
     */
    public synchronized IClass defineIClass(Class clazz) {
        IClass result = this.getLoadedIClass(Descriptor.fromClassName(clazz.getName()));
        if (result != null) return result;

        result = this.new ReflectionIClass(clazz);
        this.defineIClass(result);
        return result;
    }

    private /*final*/ ClassLoader classLoader;

    // Reflection implementation of IClass. 
    private class ReflectionIClass extends IClass {
        public ReflectionIClass(Class clazz) {
            this.clazz = clazz;
        }

        public IConstructor[] getDeclaredIConstructors() {
            if (ClassLoaderIClassLoader.DEBUG) System.out.println("getDeclaredIConstructors(\"" + this.clazz.getName() + "\")");
            Constructor[] constructors = this.clazz.getDeclaredConstructors();
            IConstructor[] res = new IConstructor[constructors.length];
            for (int i = 0; i < constructors.length; ++i) {
                res[i] = new ReflectionIConstructor(constructors[i]);
            }
            return res;
        }
        public IMethod[] getDeclaredIMethods() {
            Method[] methods = this.clazz.getDeclaredMethods();
            IMethod[] res = new IMethod[methods.length];
            for (int i = 0; i < methods.length; ++i) {
                res[i] = new ReflectionIMethod(methods[i]);
            }
            return res;
        }
        public IField[] getDeclaredIFields() {
            Field[] fields = this.clazz.getDeclaredFields();
            IField[] res = new IField[fields.length];
            for (int i = 0; i < fields.length; ++i) {
                res[i] = new ReflectionIField(fields[i]);
            }
            return res;
        }
        public IClass[] getDeclaredIClasses() {
            return this.classesToIClasses(this.clazz.getDeclaredClasses());
        }
        public IClass getDeclaringIClass() {
            Class declaringClass = this.clazz.getDeclaringClass();
            if (declaringClass == null) return null;
            return this.classToIClass(declaringClass);
        }
        public IClass getOuterIClass() {
            if (Modifier.isStatic(this.clazz.getModifiers())) return null;
            return this.getDeclaringIClass();
        }
        public IClass getSuperclass() {
            Class superclass = this.clazz.getSuperclass();
            return superclass == null ? null : this.classToIClass(superclass);
        }
        public IClass[] getInterfaces() {
            return this.classesToIClasses(this.clazz.getInterfaces());
        }
        public String getDescriptor() {
            return Descriptor.fromClassName(this.clazz.getName());
        }
        public boolean isPublic()    { return Modifier.isPublic(this.clazz.getModifiers()); }
        public boolean isFinal()     { return Modifier.isFinal(this.clazz.getModifiers()); }
        public boolean isInterface() { return this.clazz.isInterface(); }
        public boolean isAbstract()  { return Modifier.isAbstract(this.clazz.getModifiers()); }
        public boolean isArray()     { return this.clazz.isArray(); }
        public IClass getComponentType() {
            Class componentType = this.clazz.getComponentType();
            return componentType == null ? null : this.classToIClass(componentType);
        }
        public boolean isPrimitive() {
            return this.clazz.isPrimitive();
        }
        public boolean isPrimitiveNumeric() {
            return (
                this.clazz == Byte.TYPE      ||
                this.clazz == Short.TYPE     ||
                this.clazz == Integer.TYPE   ||
                this.clazz == Long.TYPE      ||
                this.clazz == Character.TYPE ||
                this.clazz == Float.TYPE     ||
                this.clazz == Double.TYPE
            );
        }

        /**
         * @return E.g. "int", "int[][]", "pkg1.pkg2.Outer$Inner[]"
         */
        public String toString() {
            int brackets = 0;
            Class c = this.clazz;
            while (c.isArray()) {
                ++brackets;
                c = c.getComponentType();
            }
            String s = c.getName();
            while (brackets-- > 0) s += "[]";
            return s;
        }

        /**
         * The {@link Class} represented by this object.
         */
        private /*final*/ Class clazz;

        private class ReflectionIConstructor extends IConstructor {
            public ReflectionIConstructor(Constructor constructor) { this.constructor = constructor; }

            // Implement IMember.
            public int getAccess() {
                int mod = this.constructor.getModifiers();
                return (
                    Modifier.isPrivate(mod)   ? IClass.PRIVATE   :
                    Modifier.isProtected(mod) ? IClass.PROTECTED :
                    Modifier.isPublic(mod)    ? IClass.PUBLIC    :
                    IClass.PACKAGE
                );
            }

            // Implement "IConstructor".
            public IClass[] getParameterTypes() throws Java.CompileException {
                IClass[] parameterTypes = ReflectionIClass.this.classesToIClasses(this.constructor.getParameterTypes());

                // The JAVADOC of java.lang.reflect.Constructor does not document it, but
                // "getParameterTypes()" includes the synthetic "enclosing instance" parameter.
                IClass outerClass = ReflectionIClass.this.getOuterIClass();
                if (outerClass != null) {
                    if (parameterTypes.length < 1) throw new Java.CompileException("Constructor \"" + this.constructor + "\" lacks synthetic enclosing instance parameter", null);
                    if (parameterTypes[0] != outerClass) throw new Java.CompileException("Enclosing instance parameter of constructor \"" + this.constructor + "\" has wrong type -- \"" + parameterTypes[0] + "\" vs. \"" + outerClass + "\"", null);
                    IClass[] tmp = new IClass[parameterTypes.length - 1];
                    System.arraycopy(parameterTypes, 1, tmp, 0, tmp.length);
                    parameterTypes = tmp;
                }

                return parameterTypes;
            }
            public IClass[] getThrownExceptions() {
                return ReflectionIClass.this.classesToIClasses(this.constructor.getExceptionTypes());
            }

            final Constructor constructor;
        };
        private class ReflectionIMethod extends IMethod {
            public ReflectionIMethod(Method method) { this.method = method; }

            // Implement IMember.
            public int getAccess() {
                int mod = this.method.getModifiers();
                return (
                    Modifier.isPrivate(mod)   ? IClass.PRIVATE   :
                    Modifier.isProtected(mod) ? IClass.PROTECTED :
                    Modifier.isPublic(mod)    ? IClass.PUBLIC    :
                    IClass.PACKAGE
                );
            }

            // Implemnt "IMethod".
            public String getName() { return this.method.getName(); }
            public IClass[] getParameterTypes() {
                return ReflectionIClass.this.classesToIClasses(this.method.getParameterTypes());
            }
            public boolean isStatic() { return Modifier.isStatic(this.method.getModifiers()); }
            public boolean isAbstract() { return Modifier.isAbstract(this.method.getModifiers()); }
            public IClass getReturnType() {
                return ReflectionIClass.this.classToIClass(this.method.getReturnType());
            }
            public IClass[] getThrownExceptions() {
                return ReflectionIClass.this.classesToIClasses(this.method.getExceptionTypes());
            }

            final Method method;
        };
        private class ReflectionIField extends IField {
            public ReflectionIField(Field field) { this.field = field; }

            // Implement IMember.
            public int getAccess() {
                int mod = this.field.getModifiers();
                return (
                    Modifier.isPrivate(mod)   ? IClass.PRIVATE   :
                    Modifier.isProtected(mod) ? IClass.PROTECTED :
                    Modifier.isPublic(mod)    ? IClass.PUBLIC    :
                    IClass.PACKAGE
                );
            }

            // Implement "IField".
            public String getName() { return this.field.getName(); }
            public boolean isStatic() {
                return Modifier.isStatic(this.field.getModifiers());
            }
            public IClass getType() {
                return ReflectionIClass.this.classToIClass(this.field.getType());
            }
            public String toString() {
                return (
                    Descriptor.toString(this.getDeclaringIClass().getDescriptor()) +
                    "." +
                    getName()
                );
            }
            public Object getConstantValue() throws Java.CompileException {
                int mod = this.field.getModifiers();
                Class clazz = this.field.getType();
                if (
                    Modifier.isStatic(mod) &&
                    Modifier.isFinal(mod) &&
                    (clazz.isPrimitive() || clazz == String.class)
                ) {
                    try {
                        return this.field.get(null);
                    } catch (IllegalAccessException ex) {
                        throw new Java.CompileException("Field \"" + this.field.getName() + "\" is not accessible", (Scanner.Location) null);
                    }
                }
                return null;
            }

            final Field field;
        }

        /**
         * Load {@link Class} through {@link IClassLoader} to
         * ensure unique {@link IClass}es.
         */
        /*private*/ IClass classToIClass(Class c) {
            return ClassLoaderIClassLoader.this.defineIClass(c);
        }

        /**
         * @see {@link #classToIClass(Class)}
         */
        /*private*/ IClass[] classesToIClasses(Class[] cs) {
            IClass[] result = new IClass[cs.length];
            for (int i = 0; i < cs.length; ++i) result[i] = this.classToIClass(cs[i]);
            return result;
        }
    }
}
