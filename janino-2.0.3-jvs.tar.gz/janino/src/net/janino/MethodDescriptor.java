
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.util.ArrayList;
import java.util.List;

public class MethodDescriptor {
    public final String[] parameterFDs;
    public final String   returnFD;

    public MethodDescriptor(String[] parameterFDs, String returnFD) {
        this.parameterFDs = parameterFDs;
        this.returnFD     = returnFD;
    }

    /**
     * Parse a method descriptor into parameter FDs and return FDs.
     */
    public MethodDescriptor(String s) {
        if (s.charAt(0) != '(') throw new RuntimeException();

        int from = 1;
        List parameterFDs = new ArrayList(); // String
        while (s.charAt(from) != ')') {
            int to = from;
            while (s.charAt(to) =='[') ++to;
            if ("BCDFIJSZ".indexOf(s.charAt(to)) != -1) {
                ++to;
            } else
            if (s.charAt(to) == 'L') {
                for (++to; s.charAt(to) != ';'; ++to);
                ++to;
            } else {
                throw new RuntimeException();
            }
            parameterFDs.add(s.substring(from, to));
            from = to;
        }
        this.parameterFDs = (String[]) parameterFDs.toArray(new String[parameterFDs.size()]);
        this.returnFD = s.substring(++from);
    }

    public String toString() {
        StringBuffer sb = new StringBuffer("(");
        for (int i = 0; i < this.parameterFDs.length; ++i) sb.append(this.parameterFDs[i]);
        return sb.append(')').append(this.returnFD).toString();
    }
}
