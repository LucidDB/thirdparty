package org.incava.java;

import java.util.*;
import net.sourceforge.pmd.ast.*;


/**
 * Miscellaneous routines for interfaces.
 */
public class InterfaceUtil extends ClassUtil
{

}

