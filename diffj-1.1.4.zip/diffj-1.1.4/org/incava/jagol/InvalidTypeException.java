package org.incava.jagol;

import java.io.*;
import java.util.*;

public class InvalidTypeException extends OptionException
{
    public InvalidTypeException(String msg)
    {
        super(msg);
    }

}
