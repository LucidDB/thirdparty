package org.incava.diffj;

import java.awt.Point;
import java.io.StringWriter;
import org.incava.analysis.CodeReference;


public class TestImportsDiff extends Tester
{
    public TestImportsDiff(String name)
    {
        super(name);
    }

    public void testImportsNoneNoChange()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testImportsOneNoChange()
    {
        evaluate("import java.foo.*;\n" +
                 "\n" +
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 "import java.foo.*;\n" +
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testImportsTwoNoChange()
    {
        evaluate("import java.foo.*;\n" +
                 "import org.incava.Bazr;\n" +
                 "\n" +
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 "import java.foo.*;\n" +
                 "import org.incava.Bazr;\n" +
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testImportsSectionRemovedOne()
    {
        evaluate("import java.foo.*;\n" +
                 "\n" +
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.DELETED, ImportsDiff.IMPORT_SECTION_REMOVED, new Point(1, 1), new Point(1, 18), new Point(1, 1), new Point(1, 5)),
                 });
    }

    public void testImportsSectionRemovedTwo()
    {
        evaluate("import java.foo.*;\n" +
                 "import org.incava.Bazr;\n" +
                 "\n" +
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.DELETED, ImportsDiff.IMPORT_SECTION_REMOVED, new Point(1, 1), new Point(2, 23), new Point(1, 1), new Point(1, 5)),
                 });
    }

    public void testImportsSectionAddedOne()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "import java.foo.*;\n" +
                 "\n" +
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.ADDED, ImportsDiff.IMPORT_SECTION_ADDED, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 18)),
                 });
    }

    public void testImportsSectionAddedTwo()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "import java.foo.*;\n" +
                 "import org.incava.Bazr;\n" +
                 "\n" +
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.ADDED, ImportsDiff.IMPORT_SECTION_ADDED, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(2, 23)),
                 });
    }

    public void testImportsBlockAddedNoClassDefined()
    {
        evaluate("package org.incava.foo;\n" +
                 "\n",
                 "package org.incava.foo;\n" +
                 "\n" +
                 "import java.foo.*;\n" +
                 "import org.incava.Bazr;\n" +
                 "\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.ADDED, ImportsDiff.IMPORT_SECTION_ADDED, new Point(1, 1), new Point(1, 7), new Point(3, 1), new Point(4, 23)),
                 },
                 "1.3",
                 makeDetailedReport(new StringWriter()));
    }
}
