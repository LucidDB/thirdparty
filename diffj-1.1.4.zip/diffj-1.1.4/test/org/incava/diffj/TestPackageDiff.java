package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestPackageDiff extends TestItemDiff
{
    protected final static String[] PACKAGE_MSGS = new String[] {
        PackageDiff.PACKAGE_REMOVED, 
        PackageDiff.PACKAGE_RENAMED,
        PackageDiff.PACKAGE_ADDED,
    };

    public TestPackageDiff(String name)
    {
        super(name);
    }

    public void testPackageNoChange()
    {
        evaluate("package org.incava.foo;\n" +
                 "\n" + 
                 "class Test {\n" +
                 "}\n",
                 "package org.incava.foo;\n" +
                 "\n" + 
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testPackageNone()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testPackageRemoved()
    {
        evaluate("package org.incava.foo;\n" +
                 "\n" + 
                 "/**\n" + 
                 " * This is a test class.\n" +
                 " */\n" +
                 "class Test {\n" +
                 "}\n",
                 "/**\n" + 
                 " * This is a test class.\n" +
                 " */\n" +
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makePackageRef("org.incava.foo", null, 1, 9, 1, 22, 4, 1, 5, 1),
                 });
    }

    public void testPackageAdded()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "package org.incava.foo;\n" +
                 "\n" + 
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makePackageRef(null, "org.incava.foo", 1, 1, 1, 5, 1, 9, 1, 22),
                 });
    }

    public void testPackageRenamed()
    {
        evaluate("package org.incava.bar;\n" +
                 "class Test {\n" +
                 "}\n",
                 "package org.incava.foo;\n" +
                 "\n" + 
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makePackageRef("org.incava.bar", "org.incava.foo", 1, 9, 1, 22, 1, 9, 1, 22),
                 });
    }

    protected CodeReference makePackageRef(String from, String to,
                                           int aFromLine, int aFromColumn, int aToLine, int aToColumn,
                                           int bFromLine, int bFromColumn, int bToLine, int bToColumn)
    {
        return makeRef(from, to, PACKAGE_MSGS, 
                       aFromLine, aFromColumn, aToLine, aToColumn,
                       bFromLine, bFromColumn, bToLine, bToColumn);
    }

}
