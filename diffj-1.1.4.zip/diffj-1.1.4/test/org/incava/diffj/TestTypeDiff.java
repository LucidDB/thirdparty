package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestTypeDiff extends TestItemDiff
{
    protected final static String[] METHOD_MSGS = new String[] {
        TypeDiff.METHOD_REMOVED,
        TypeDiff.METHOD_CHANGED, 
        TypeDiff.METHOD_ADDED,
    };

    protected final static String[] FIELD_MSGS = new String[] {
        TypeDiff.FIELD_REMOVED,
        null,
        TypeDiff.FIELD_ADDED,
    };

    protected final static String[] CLASS_MSGS = new String[] {
        TypeDiff.INNER_CLASS_REMOVED,
        null,
        TypeDiff.INNER_CLASS_ADDED,
    };

    protected final static String[] INTERFACE_MSGS = new String[] {
        TypeDiff.INNER_INTERFACE_REMOVED,
        null,
        TypeDiff.INNER_INTERFACE_ADDED,
    };

    protected final static String[] CONSTRUCTOR_MSGS = new String[] {
        TypeDiff.CONSTRUCTOR_REMOVED,
        null,
        TypeDiff.CONSTRUCTOR_ADDED,
    };

    public TestTypeDiff(String name)
    {
        super(name);
    }

    public void xtestClassToInterface()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "interface Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, TypesDiff.TYPE_CHANGED_FROM_CLASS_TO_INTERFACE, new Point(1, 1), new Point(2, 1), new Point(1, 1), new Point(2, 1)),
                 });
    }

    public void xtestInterfaceToClass()
    {
        evaluate("interface Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, TypesDiff.TYPE_CHANGED_FROM_INTERFACE_TO_CLASS, new Point(1, 1), new Point(2, 1), new Point(1, 1), new Point(2, 1)),
                 });
    }

    public void xtestClassAccessChanged()
    {
        evaluate("class Test {\n" +
                 "}\n",
                 "public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "public", ACCESS_MSGS, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 6)),
                 });
        
        evaluate("public class Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "public", null, ACCESS_MSGS, new Point(1, 1), new Point(1, 6), new Point(1, 1), new Point(1, 5)),
                 });
    }

    public void xtestClassModifierAdded()
    {
        evaluate("public class Test {\n" +
                 "}\n",
                 "abstract public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "abstract", MODIFIER_MSGS, new Point(1, 1), new Point(1, 6), new Point(1, 1), new Point(1, 8)),
                 });

        evaluate("public class Test {\n" +
                 "}\n",
                 "final public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "final", MODIFIER_MSGS, new Point(1, 1), new Point(1, 6), new Point(1, 1), new Point(1, 5)),
                 });

        evaluate("class Test {\n" +
                 "}\n",
                 "strictfp class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, null, "strictfp", MODIFIER_MSGS, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 8)),
                 });
    }

    public void xtestClassModifierRemoved()
    {
        evaluate("abstract public class Test {\n" +
                 "}\n",
                 "public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "abstract", null, MODIFIER_MSGS, new Point(1, 1), new Point(1, 8), new Point(1, 1), new Point(1, 6)),
                 });

        evaluate("final public class Test {\n" +
                 "}\n",
                 "public class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "final", null, MODIFIER_MSGS, new Point(1, 1), new Point(1, 5), new Point(1, 1), new Point(1, 6)),
                 });

        evaluate("strictfp class Test {\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(CodeReference.CHANGED, "strictfp", null, MODIFIER_MSGS, new Point(1, 1), new Point(1, 8), new Point(1, 1), new Point(1, 5)),
                 });
    }

    public void xtestClassAllMethodsAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 17)),
                 });
    }

    public void xtestClassOneMethodAdded()
    {
        evaluate("class Test {\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { return -1; }\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "foo()", METHOD_MSGS, new Point(1, 1), new Point(4, 1), new Point(4, 5), new Point(4, 17)),
                 });
    }

    public void xtestClassAllMethodsRemoved()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("foo()", null, METHOD_MSGS, new Point(3, 5), new Point(3, 17), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void xtestClassNoMethodsChanged()
    {
        evaluate("class Test {\n" +
                 "    void foo() {}\n" +
                 "    int bar() { return -1; }\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int bar() { \n" +
                 "        return -1;\n" +
                 "    }\n" +
                 "\n" +
                 "    void foo() {}\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void xtestClassOneFieldAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "i", FIELD_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 10)),
                 });
    }

    public void xtestClassOneFieldRemoved()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("i", null, FIELD_MSGS, new Point(2, 5), new Point(2, 10), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void xtestClassOneFieldRemovedOneFieldAdded()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "    String j;\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "j",  FIELD_MSGS, new Point(1, 1), new Point(4,  1), new Point(2, 5), new Point(2, 13)),
                     makeRef("i",  null, FIELD_MSGS, new Point(2, 5), new Point(2, 10), new Point(1, 1), new Point(4,  1)),
                 });
    }

    public void xtestClassInnerInterfaceUnchanged()
    {
        evaluate("class Test {\n" +
                 "    interface ITest {}\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {}\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void xtestClassInnerInterfaceAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    interface ITest {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "ITest", INTERFACE_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 22)),
                 });
    }

    public void xtestClassInnerInterfaceRemoved()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "    interface ITest {}\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("ITest", null, INTERFACE_MSGS, new Point(3, 5), new Point(3, 22), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void xtestClassConstructorAdded()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    Test(String s) {}\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "Test(String)", CONSTRUCTOR_MSGS, new Point(1, 1), new Point(3, 1), new Point(3, 5), new Point(3, 21)),
                 });
    }

    public void xtestClassConstructorRemoved()
    {
        evaluate("class Test {\n" +
                 "\n" +
                 "    public Test(int i, double d, float f) {}\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("Test(int, double, float)", null, CONSTRUCTOR_MSGS, new Point(3, 12), new Point(3, 44), new Point(1, 1), new Point(3, 1)),
                 });
    }

    public void xtestSemicolonDeclarationRemoved()
    {
        // Is this really a change? I don't think so.
        evaluate("class Test {\n" +
                 "    ;\n" +
                 "}\n",
                 "class Test {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testClassExtendsAdded()
    {
        evaluate("class A {\n" +
                 "}\n",
                 "class A extends Date {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_ADDED, "Date", new Point(1, 1), new Point(2, 1), new Point(1, 17), new Point(1, 20)),
                 });

        evaluate("class A {\n" +
                 "}\n",
                 "class A extends java.util.Date {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_ADDED, "java.util.Date", new Point(1, 1), new Point(2, 1), new Point(1, 17), new Point(1, 30)),
                 });
    }

    public void testClassExtendsChanged()
    {
        // Thanks to Pat for finding and reporting this.
        evaluate("class A extends Object {\n" +
                 "}\n",
                 "class A extends Date {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_CHANGED, new String[] { "Object", "Date" }, new Point(1, 17), new Point(1, 22), new Point(1, 17), new Point(1, 20)),
                 });
    }

    public void testClassExtendsDeleted()
    {
        evaluate("class A extends Date {\n" +
                 "}\n",
                 "class A {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_REMOVED, "Date", new Point(1, 17), new Point(1, 20), new Point(1, 1), new Point(2, 1)),
                 });

        evaluate("class A extends java.util.Date {\n" +
                 "}\n",
                 "class A {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_REMOVED, "java.util.Date", new Point(1, 17), new Point(1, 30), new Point(1, 1), new Point(2, 1)),
                 });
    }

    public void testInterfaceExtendsAdded()
    {
        evaluate("interface A {\n" +
                 "}\n",
                 "interface A extends Comparator {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_ADDED, "Comparator", new Point(1, 1), new Point(2, 1), new Point(1, 21), new Point(1, 30)),
                 });
    }

    public void testInterfaceExtendsChanged()
    {
        evaluate("interface A extends Comparable {\n" +
                 "}\n",
                 "interface A extends Comparator {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_CHANGED, new String[] { "Comparable", "Comparator" }, new Point(1, 21), new Point(1, 30), new Point(1, 21), new Point(1, 30)),
                 });
    }

    public void testInterfaceExtendsDeleted()
    {
        evaluate("interface A extends Comparable {\n" +
                 "}\n",
                 "interface A {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.EXTENDED_TYPE_REMOVED, "Comparable", new Point(1, 21), new Point(1, 30), new Point(1, 1), new Point(2, 1)),
                 });
    }

    public void testClassImplementsAdded()
    {
        evaluate("class A {\n" +
                 "}\n",
                 "class A implements Runnable {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.IMPLEMENTED_TYPE_ADDED, "Runnable", new Point(1, 1), new Point(2, 1), new Point(1, 20), new Point(1, 27)),
                 });

        evaluate("class A {\n" +
                 "}\n",
                 "class A implements java.lang.Runnable {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.IMPLEMENTED_TYPE_ADDED, "java.lang.Runnable", new Point(1, 1), new Point(2, 1), new Point(1, 20), new Point(1, 37)),
                 });
    }

    public void testClassImplementsChanged()
    {
        // Thanks to Pat for finding and reporting this.
        evaluate("class A implements Cloneable {\n" +
                 "}\n",
                 "class A implements Runnable {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.IMPLEMENTED_TYPE_CHANGED, new String[] { "Cloneable", "Runnable" }, new Point(1, 20), new Point(1, 28), new Point(1, 20), new Point(1, 27)),
                 });
    }

    public void testClassImplementsNoChange()
    {
        // Thanks to Pat for finding and reporting this.
        evaluate("class A implements Cloneable {\n" +
                 "}\n",
                 "class A implements Cloneable {\n" +
                 "}\n",
                 new CodeReference[] { 
                 });
    }

    public void testClassImplementsDeleted()
    {
        evaluate("class A implements Runnable {\n" +
                 "}\n",
                 "class A {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.IMPLEMENTED_TYPE_REMOVED, "Runnable", new Point(1, 20), new Point(1, 27), new Point(1, 1), new Point(2, 1)),
                 });

        evaluate("class A implements java.lang.Runnable {\n" +
                 "}\n",
                 "class A {\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(TypeDiff.IMPLEMENTED_TYPE_REMOVED, "java.lang.Runnable", new Point(1, 20), new Point(1, 37), new Point(1, 1), new Point(2, 1)),
                 });
    }

}
