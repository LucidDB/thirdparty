package org.incava.diffj;

import java.awt.Point;
import java.text.MessageFormat;
import org.incava.analysis.CodeReference;


public class TestFieldDiff extends TestItemDiff
{
    protected final static String[] VARIABLE_MSGS = new String[] {
        FieldDiff.VARIABLE_REMOVED,
        FieldDiff.VARIABLE_CHANGED, 
        FieldDiff.VARIABLE_ADDED,
    };

    public TestFieldDiff(String name)
    {
        super(name);
    }

    public void testAccessAdded()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    private int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeAccessRef(null, "private", 2, 5, 2, 7, 3, 5, 3, 11),
                 });
    }

    public void testAccessRemoved()
    {
        evaluate("class Test {\n" +
                 "    public int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeAccessRef("public", null, 2, 5, 2, 10, 3, 5, 3, 7),
                 });
    }

    public void testAccessChanged()
    {
        evaluate("class Test {\n" +
                 "    private int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    public int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeAccessRef("private", "public", 2, 5, 2, 11, 3, 5, 3, 10),
                 });
    }

    public void testModifierAdded()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    static int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeModifierRef(null, "static", 2, 5, 2, 7, 3, 5, 3, 10),
                 });
    }

    public void testModifierRemoved()
    {
        evaluate("class Test {\n" +
                 "    final int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeModifierRef("final", null, 2, 5, 2, 9, 3, 5, 3, 7),
                 });
    }

    public void testInitializerAdded()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i = 4;\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, FieldDiff.INITIALIZER_ADDED, new Point(2, 9), new Point(2, 9), new Point(3, 13), new Point(3, 13)),
                 });
    }

    public void testInitializerRemoved()
    {
        evaluate("class Test {\n" +
                 "    int i = 4;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i;\n" +
                 "}\n",
                 new CodeReference[] { 
                     new CodeReference(CodeReference.CHANGED, FieldDiff.INITIALIZER_REMOVED, new Point(2, 13), new Point(2, 13), new Point(3, 9), new Point(3, 9)),
                 });
    }

    public void testInitializerCodeChanged()
    {
        evaluate("class Test {\n" +
                 "    int i = 4;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i = 5;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(FieldDiff.CODE_CHANGED, "i", new Point(2, 13), new Point(2, 13), new Point(3, 13), new Point(3, 13)),
                 });
    }

    public void testInitializerCodeAdded()
    {
        evaluate("class Test {\n" +
                 "    int i = 4;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i = 4 * 5;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(FieldDiff.CODE_ADDED, "i", new Point(2, 14), new Point(2, 14), new Point(3, 15), new Point(3, 17)),
                 });
    }

    public void testInitializerCodeRemoved()
    {
        evaluate("class Test {\n" +
                 "    int i = 4 * 5;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int i = 4;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeCodeChangedRef(FieldDiff.CODE_REMOVED, "i", new Point(2, 15), new Point(2, 17), new Point(3, 14), new Point(3, 14)),
                 });
    }

    public void testVariableChanged()
    {
        evaluate("class Test {\n" +
                 "    int i;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "\n" +
                 "    int j;\n" +
                 "\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("i", "j", VARIABLE_MSGS, new Point(2, 9), new Point(2,  9), new Point(4, 9), new Point(4, 9)),
                 });
    }

    public void testVariableAddedRemoved()
    {
        evaluate("public class Collections {\n" +
                 "\n" +
                 "    private static class SingletonMap\n" +
                 "                                      implements Serializable {\n" +
                 "        private final Object k, v;\n" +
                 "    }\n" +
                 "}\n",
                 "public class Collections {\n" +
                 "\n" +
                 "    private static class SingletonMap<K,V>\n" +
                 "	  implements Serializable {\n" +
                 "\n" +
                 "        private final K k;\n" +
                 "        private final V v;\n" +
                 "    }\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef(null, "v",  TestTypeDiff.FIELD_MSGS, new Point(3, 20), new Point(6,  5), new Point(7, 23), new Point(7, 26)),
                     makeCodeChangedRef(FieldDiff.VARIABLE_REMOVED, "v",  new Point(5, 33), new Point(5, 33), new Point(6, 25), new Point(6, 25)),
                 });
    }

    public void testVariableWithInitializerChanged()
    {
        evaluate("class Test {\n" +
                 "    int i = 4;\n" +
                 "\n" +
                 "}\n",
                 "class Test {\n" +
                 "\n" +
                 "    int j = 4;\n" +
                 "}\n",
                 new CodeReference[] { 
                     makeRef("i", "j", VARIABLE_MSGS, new Point(2, 9), new Point(2, 9), new Point(3, 9), new Point(3, 9)),
                 });
    }

}
