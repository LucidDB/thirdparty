
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.*;

/**
 * A simplified version of {@link Compiler} that can compile only a single
 * compilation unit. (A "compilation unit" is the characters stored in a
 * ".java" file.)
 * <p>
 * Opposed to a normal ".java" file, you can declare multiple public classes
 * here.
 */
public class SimpleCompiler extends EvaluatorBase {
    public SimpleCompiler(
        String fileName,
        Reader in
    ) throws IOException, Scanner.ScanException, Parser.ParseException, Java.CompileException, ClassNotFoundException {
        this(new Scanner(fileName, in), null);
    }

    public SimpleCompiler(
        String      fileName,
        InputStream is
    ) throws IOException, Scanner.ScanException, Parser.ParseException, Java.CompileException, ClassNotFoundException {
        this(new Scanner(fileName, is), null);
    }

    public SimpleCompiler(
        String fileName
    ) throws IOException, Scanner.ScanException, Parser.ParseException, Java.CompileException, ClassNotFoundException {
        this(new Scanner(fileName), null);
    }

    /**
     * Parse a compilation unit from the given {@link Scanner} object and
     * compile it to a set of Java<sup>TM</sup> classes.
     * @param scanner Source of tokens
     * @param classLoader Used to load referenced classes
     * @throws IOException
     * @throws Scanner.ScanException
     * @throws Parser.ParseException
     * @throws Java.CompileException
     */
    public SimpleCompiler(
        Scanner     scanner,
        ClassLoader classLoader
    ) throws IOException, Scanner.ScanException, Parser.ParseException, Java.CompileException {
        super(classLoader);

        // Parse the compilation unit.
        Java.CompilationUnit compilationUnit = new Parser(scanner).parseCompilationUnit();

        // Compile the classes and load them.
        this.classLoader = this.compileAndLoad(compilationUnit);
    }

    /**
     * Returns a {@link ClassLoader} object through which the previously
     * compiled classes can be accessed.
     */
    public ClassLoader getClassLoader() {
        return this.classLoader;
    }

    private final ClassLoader classLoader;
}
