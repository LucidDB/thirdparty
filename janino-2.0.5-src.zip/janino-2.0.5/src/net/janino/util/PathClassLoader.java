
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import net.janino.util.resource.PathResourceFinder;
import net.janino.util.resource.ResourceFinder;

/**
 * A {@link ClassLoader} that uses a "class path" to find ".class" files.
 */
public class PathClassLoader extends ClassLoader {
    private final ResourceFinder resourceFinder;

    public PathClassLoader(File[] entries, ClassLoader parent) {
        super(parent);
        this.resourceFinder = new PathResourceFinder(entries);
    }

    public PathClassLoader(ResourceFinder resourceFinder, ClassLoader parent) {
        super(parent);
        this.resourceFinder = resourceFinder;
    }

    public ResourceFinder getResourceFinder() {
        return this.resourceFinder;
    }

    /**
     * @throws ClassNotFoundException
     * @throws TunnelException Tunnels a {@link IOException}
     */
    protected Class findClass(String className) throws ClassNotFoundException {

        // Find the resource containing the class bytecode.
        InputStream is = this.resourceFinder.findResourceAsStream(className.replace('.', '/') + ".class");
        if (is == null) throw new ClassNotFoundException(className);

        // Read bytecode from the resource into a byte array.
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            byte[] buffer = new byte[4096];
            for (;;) {
                int bytesRead = is.read(buffer);
                if (bytesRead == -1) break;
                baos.write(buffer, 0, bytesRead);
            }
        } catch (IOException ex) {
            throw new TunnelException(ex);
        } finally {
            try { is.close(); } catch (IOException ex) {}
        }
        byte[] ba = baos.toByteArray();

        // Define the class in this ClassLoader.
        Class clazz = super.defineClass(null, ba, 0, ba.length);

        if (!clazz.getName().equals(className)) {

            // This is a really complicated case: We may find a class file on
            // the class path that seemingly defines the class we are looking
            // for, but doesn't. This is possible if the underlying file system
            // has case-insensitive file names and/or file names that are
            // limited in length (e.g. DOS 8.3).
            throw new ClassNotFoundException(className);
        }

        return clazz;
    }

    public URL findResource(String resourceName) {
        return this.resourceFinder.findResource(resourceName);
    }
}
