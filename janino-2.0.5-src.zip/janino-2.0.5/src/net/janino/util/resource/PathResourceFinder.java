
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util.resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipFile;

/**
 * A {@link net.janino.util.resource.ResourceFinder} that finds its resources along a "path" consisting
 * of ZIP file names and directory names.
 * @see net.janino.util.resource.ZipFileResourceFinder
 * @see net.janino.util.resource.DirectoryResourceFinder
 */
public class PathResourceFinder extends MultiResourceFinder {

    /**
     * @param entries The entries of the "path"
     */
    public PathResourceFinder(File[] entries) {
        super(new PathCollection(entries));
    }

    /**
     * @param entries The entries of the "path"
     */
    public PathResourceFinder(String path) {
        this(PathResourceFinder.parsePath(path));
    }

    /**
     * Break a given string up by a "separator" string. Empty components are
     * ignored.
     * <p>
     * Examples:
     * <dl>
     *   <dt>A*B*C          <dd>A, B, C
     *   <dt>**B*           <dd>B
     *   <dt>*A             <dd>A
     *   <dt>(Empty string) <dd>(Zero components)
     * </dl>
     */
    public static File[] parsePath(String s) {
        int from = 0;
        List l = new ArrayList(); // File
        for (;;) {
            int to = s.indexOf(File.pathSeparatorChar, from);
            if (to == -1) {
                if (from != s.length()) l.add(new File(s.substring(from)));
                break;
            }
            if (to != from) l.add(new File(s.substring(from, to)));
            from = to + 1;
        }
        return (File[]) l.toArray(new File[l.size()]);
    }

    /**
     * A collection that lazily creates {@link ResourceFinder}s for the path enties.
     */
    private static class PathCollection extends AbstractCollection {
        private final File[]           entries;
        private final ResourceFinder[] resourceFinders; // One for each entry

        private PathCollection(File[] entries) {
            this.entries = entries;
            this.resourceFinders = new ResourceFinder[entries.length];
        }

        public Iterator iterator() {
            return new Iterator() {
                private int index = 0;
                public boolean hasNext() { return this.index < PathCollection.this.entries.length; }
                public Object next() {
                    ResourceFinder resourceFinder = PathCollection.this.resourceFinders[this.index];
                    if (resourceFinder == null) {
                        resourceFinder = PathResourceFinder.createResourceFinder(PathCollection.this.entries[this.index]);
                        PathCollection.this.resourceFinders[this.index] = resourceFinder;
                    }
                    ++this.index;
                    return resourceFinder;
                }
                public void remove() { throw new UnsupportedOperationException(); }
            };
        }

        public int size() {
            int size = 0;
            for (Iterator it = this.iterator(); it.hasNext(); it.next()) ++size;
            return size;
        }
    }

    private static ResourceFinder createResourceFinder(final File entry) {
        if (
            (entry.getName().endsWith(".jar") || entry.getName().endsWith(".zip")) &&
            entry.isFile()
        ) {
            try {
                return new ZipFileResourceFinder(new ZipFile(entry));
            } catch (IOException e) {
                return null;
            }
        }

        if (entry.isDirectory()) {
            return new DirectoryResourceFinder(entry);
        }

        return new ResourceFinder() {
            public InputStream findResourceAsStream(String className) { return null; }
            public URL findResource(String resourceName) { return null; }
            public String toString() { return "inv:" + entry; }
        };
    }
}
