
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino.util;

import java.io.PrintStream;
import java.io.PrintWriter;


/**
 * Redirects all methods to the delegate {@link Throwable}.
 * <p>
 * This class is useful if you want to throw a non-{@link RuntimeException}-derived
 * Exception, but cannot declare it in the "throws" clause of your method, because your method
 * overrides a method of a base class. The classical example is
 * {@link ClassLoader#findClass(String)}, which allows only
 * {@link ClassNotFoundException} to be thrown, but you want to implement a more
 * elaborate exception handling.
 * <p>
 * To make clear which exceptions wrapped in {@link TunnelException} your method would throw, it
 * is recommended that you declare them with a "<code>throws </code>{@link TunnelException}" clause and that
 * you document them in JAVADOC with <code>@<b></b>throws</code> clauses like this:
 * <pre>
 * &#47;**
 *  * ...
 *  * &#64;throws TunnelException Wraps a {&#64;link FooException} - Problems writing a Foo
 *  * &#64;throws TunnelException Wraps a {&#64;link BarException} - The Bar could not be opened
 *  *&#47;
 * </pre>
 */
public class TunnelException extends RuntimeException {
    private final static String CLASS_NAME = TunnelException.class.getName(); // Fully qualified name of the class.

    private final Throwable delegate;

    public TunnelException(Throwable delegate) {
        this.delegate = delegate;
    }
    public Throwable getDelegate() {
        return this.delegate;
    }

    // Redirect all methods to delegate.
    // Only JDK 1.2.2 methods (for compatibility).
    public String    getLocalizedMessage()           { return TunnelException.CLASS_NAME + ": " + this.delegate.getLocalizedMessage(); }
    public String    getMessage()                    { return TunnelException.CLASS_NAME + ": " + this.delegate.getMessage(); }
    public void      printStackTrace()               { this.delegate.printStackTrace(); }
    public void      printStackTrace(PrintStream ps) { ps.println(TunnelException.CLASS_NAME + " caused by:"); this.delegate.printStackTrace(ps); }
    public void      printStackTrace(PrintWriter pw) { pw.println(TunnelException.CLASS_NAME + " caused by:"); this.delegate.printStackTrace(pw); }
    public String    toString()                      { return TunnelException.CLASS_NAME + ": " + this.delegate.toString(); }
}


