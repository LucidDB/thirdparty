
/*
 * Janino - An embedded Java[TM] compiler
 * Copyright (C) 2001-2004 Arno Unkrig
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Contact information:
 *   Arno Unkrig
 *   Ferdinand-Miller-Platz 10
 *   80335 Muenchen
 *   Germany
 *   http://www.janino.net
 *   maintainer@janino.net
 */

package net.janino;

import java.io.*;

import net.janino.Java.ClassDeclaration;
import net.janino.Java.CompilationUnit;

/**
 * Parses a class body and returns it as a <tt>java.lang.Class</tt> object
 * ready for use with <tt>java.lang.reflect</tt>.
 * <p>
 * Example:
 * <pre>
 *   import java.util.*;
 *
 *   static private int a = 1;
 *   private int b = 2;
 *
 *   public void func(int c, int d) {
 *       return func2(c, d);
 *   }
 *
 *   private static void func2(int e, int f) {
 *       return e * f;
 *   }
 * </pre>
 */

public class ClassBodyEvaluator extends EvaluatorBase {

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader classLoader)}.
     */
    public ClassBodyEvaluator(
        String script
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(null, new java.io.StringReader(script)), // scanner
            null                                                 // classLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader classLoader)}.
     */
    public ClassBodyEvaluator(
        String      fileName,
        InputStream is
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(fileName, is), // scanner
            null                       // classLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader classLoader)}.
     */
    public ClassBodyEvaluator(
        String   fileName,
        Reader   reader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            new Scanner(fileName, reader), // scanner
            null                           // classLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader classLoader)}.
     */
    public ClassBodyEvaluator(
        Scanner     scanner,
        ClassLoader classLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(
            scanner,      // scanner
            (Class) null, // optionalExtendedType
            new Class[0], // implementedTypes
            classLoader   // classLoader
        );
    }

    /**
     * See {@link #ClassBodyEvaluator(Scanner, String, Class, Class[], ClassLoader classLoader)}.
     */
    public ClassBodyEvaluator(
        Scanner     scanner,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        ClassLoader classLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        this(scanner, "SC", optionalExtendedType, implementedTypes, classLoader);
    }

    /**
     * Parse and compile a class body, i.e. a series of member definitions.
     * <p>
     * The "classLoader" serves two purposes:
     * <ul>
     *   <li>It is used to look for classes referenced by the script.
     *   <li>It is used to load the generated Java<sup>TM</sup> class
     *   into the JVM; directly if it is a subclass of {@link
     *   ByteArrayClassLoader}, or by creation of a temporary
     *   {@link ByteArrayClassLoader} if not.
     * </ul>
     * A number of constructors exist that provide useful default values for
     * the various parameters, or parse the class body from a
     * {@link String}, an {@link InputStream} or a {@link Reader}
     * instead of a {@link Scanner}.
     *
     * @param scanner source of tokens
     * @param className the name of the temporary class (uncritical)
     * @param optionalExtendedType class to extend or <tt>null</tt>
     * @param implementedTypes interfaces to implement
     * @param classLoader loads referenced classes and defines the generated class
     */
    public ClassBodyEvaluator(
        Scanner     scanner,
        String      className,
        Class       optionalExtendedType,
        Class[]     implementedTypes,
        ClassLoader classLoader
    ) throws Java.CompileException, Parser.ParseException, Scanner.ScanException, IOException {
        super(classLoader);
        CompilationUnit compilationUnit = new Java.CompilationUnit(scanner.peek().getLocation().getFileName());
        
        // Parse import declarations.
        Parser parser = new Parser(scanner);
        this.parseImportDeclarations(compilationUnit, scanner);
        
        // Add class declaration.
        ClassDeclaration cd = this.addPackageMemberClassDeclaration(
            scanner.peek().getLocation(),
            compilationUnit,
            className, optionalExtendedType, implementedTypes
        );
        
        // Parse class body declarations (member declarations) until EOF.
        while (!scanner.peek().isEOF()) {
            parser.parseClassBodyDeclaration(cd);
        }

        // Compile and load it.
        try {
            this.clazz = this.compileAndLoad(compilationUnit, className);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException();
        }
    }

    /**
     * Returns the <tt>java.lang.Class</tt> object compiled from the class
     * body.
     */
    public Class evaluate() {
        return this.clazz;
    }

    private final Class clazz;
}
