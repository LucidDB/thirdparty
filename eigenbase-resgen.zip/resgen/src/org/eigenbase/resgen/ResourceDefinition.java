/*
// $Id: //open/util/resgen/src/org/eigenbase/resgen/ResourceDefinition.java#2 $
// package org.eigenbase.resgen is an i18n resource generator
// Copyright (C) 2005-2005 The Eigenbase Project
// Copyright (C) 2005-2005 Disruptive Tech
// Copyright (C) 2005-2005 Red Square, Inc.
// Portions Copyright (C) 2002-2005 Kana Software, Inc. and others.
// All Rights Reserved.
//
// This library is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// This library is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
// or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
// License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this library; if not, write to the Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
//
// jhyde, 19 September, 2002
*/
package org.eigenbase.resgen;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public class ResourceDefinition {
    //int code;
    public String key;
    public String baseMessage;
    //int severity;

    public ResourceDefinition(String key, String baseMessage) {
        this.key = key;
        this.baseMessage = baseMessage;
    }
    /** Creates an instance of this definition with a set of parameters.
     * Derived classes can override this factory method. **/
    public ResourceInstance instantiate(ResourceBundle bundle, Object[] args) {
        return new Instance(bundle, this, args);
    }

    /** Default implementation of {@link ResourceInstance}. **/
    private static class Instance implements ResourceInstance {
        ResourceDefinition definition;
        ResourceBundle bundle;
        Object[] args;
        public Instance(ResourceBundle bundle, ResourceDefinition definition, Object[] args) {
            this.definition = definition;
            this.bundle = bundle;
            this.args = args;
        }
        public String toString() {
            String message = bundle.getString(definition.key);
            MessageFormat format = new MessageFormat(message);
            format.setLocale(bundle.getLocale());
            String formattedMessage = format.format(args);
            return formattedMessage;
        }
    }
}

// End ResourceDefinition.java
