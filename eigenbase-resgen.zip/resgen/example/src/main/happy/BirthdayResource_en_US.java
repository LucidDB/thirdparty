// This class is generated. Do NOT modify it, or
// add it to source control.

package happy;
import java.io.IOException;
import java.util.Locale;
import org.eigenbase.resgen.*;

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
 * from /home/jhyde/open/util/resgen/example/src/main/happy/BirthdayResource_en_US.java
 * on Mon Sep 19 19:00:33 PDT 2005.
 * It contains a list of messages, and methods to
 * retrieve and format those messages.
 **/

public class BirthdayResource_en_US extends BirthdayResource_en_US {
    public BirthdayResource_en_US() throws IOException {
    }
}

// End BirthdayResource_en_US.java
