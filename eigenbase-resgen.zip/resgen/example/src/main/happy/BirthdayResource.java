// This class is generated. Do NOT modify it, or
// add it to source control.

package happy;
import java.io.IOException;
import java.util.Locale;
import org.eigenbase.resgen.*;

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
