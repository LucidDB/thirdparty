// This class is generated. Do NOT modify it, or
// add it to source control.

package happy;
import java.io.IOException;
import java.util.Locale;
import org.eigenbase.resgen.*;

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
 * from /home/jhyde/open/util/resgen/example/src/main/happy/BirthdayResource_fr_FR.java
 * on Mon Sep 19 19:00:33 PDT 2005.
 * It contains a list of messages, and methods to
 * retrieve and format those messages.
 **/

public class BirthdayResource_fr_FR extends BirthdayResource_fr_FR {
    public BirthdayResource_fr_FR() throws IOException {
    }
}

// End BirthdayResource_fr_FR.java
