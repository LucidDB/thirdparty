// This class is generated. Do NOT modify it, or
// add it to source control.

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
 * from source/happy/BirthdayResource.h
 * on Tue Sep 20 00:03:05 PDT 2005.
 * It contains a list of messages, and methods to
 * retrieve and format those messages.
 */

#ifndef BirthdayResource_Included
#define BirthdayResource_Included

#include <ctime>
#include <string>

#include "Locale.h"
#include "ResourceDefinition.h"
#include "ResourceBundle.h"

// begin includes specified by source/happy/BirthdayResource.h
#include "exampleExcn.h"
// end includes specified by source/happy/BirthdayResource.h


class happy.BirthdayResource;
typedef map<Locale, happy.BirthdayResource*> happy.BirthdayResourceBundleCache;

class happy.BirthdayResource : ResourceBundle
{
    protected:
    explicit happy.BirthdayResource(Locale locale);

    public:
    virtual ~happy.BirthdayResource() { }

    static const happy.BirthdayResource &instance();
    static const happy.BirthdayResource &instance(const Locale &locale);

    static void setResourceFileLocation(const std::string &location);

    /**
     * <code>HappyBirthday</code> is 'Happy Birthday, {0}! You don''t look {1,number}.'
     */
    std::string HappyBirthday(const std::string &p0, int p1) const;

    /**
     * <code>TooYoung</code> is '{0} has not been born yet.'
     */
    std::string TooYoung(const std::string &p0) const;
    ExampleExcn* newTooYoung(const std::string &p0) const;

    private:
    ResourceDefinition _HappyBirthday;
    ResourceDefinition _TooYoung;

    template<class _GRB, class _BC, class _BC_ITER>
        friend _GRB *makeInstance(_BC &bundleCache, const Locale &locale);
};

#endif // BirthdayResource_Included
