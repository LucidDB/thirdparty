// This class is generated. Do NOT modify it, or
// add it to source control.

/**
 * This class was generated
 * by class org.eigenbase.resgen.ResourceGen
 * from source/happy/BirthdayResource.cpp
 * on Tue Sep 20 00:03:05 PDT 2005.
 * It contains a list of messages, and methods to
 * retrieve and format those messages.
 */

#include "BirthdayResource.h"
#include "ResourceBundle.h"
#include "Locale.h"

#include <map>
#include <string>

using namespace std;

#define BASENAME ("happy.BirthdayResource")

static happy.BirthdayResourceBundleCache bundleCache;
static string bundleLocation("");

const happy.BirthdayResource &happy.BirthdayResource::instance()
{
    return happy.BirthdayResource::instance(Locale::getDefault());
}

const happy.BirthdayResource &happy.BirthdayResource::instance(const Locale &locale)
{
    return *makeInstance<happy.BirthdayResource, happy.BirthdayResourceBundleCache, happy.BirthdayResourceBundleCache::iterator>(bundleCache, locale);
}

void happy.BirthdayResource::setResourceFileLocation(const string &location)
{
    bundleLocation = location;
}

happy.BirthdayResource::happy.BirthdayResource(Locale locale)
    : ResourceBundle(BASENAME, locale, bundleLocation),
      _HappyBirthday(this, "HappyBirthday"),
      _TooYoung(this, "TooYoung")
{ }

string happy.BirthdayResource::HappyBirthday(const std::string &p0, int p1) const
{
    return _HappyBirthday.format(p0, p1);
}
string happy.BirthdayResource::TooYoung(const std::string &p0) const
{
    return _TooYoung.format(p0);
}
ExampleExcn* happy.BirthdayResource::newTooYoung(const std::string &p0) const
{
    return new ExampleExcn(TooYoung(p0));
}

